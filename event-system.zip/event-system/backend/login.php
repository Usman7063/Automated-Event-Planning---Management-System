<?php

session_start();

error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


/*
|--------------------------------------------------------------------------
| Handle OPTIONS request
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);

    exit;
}


/*
|--------------------------------------------------------------------------
| Only POST allowed
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
*/

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed.",
        "details" => $conn->connect_error
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


/*
|--------------------------------------------------------------------------
| Read JSON
|--------------------------------------------------------------------------
*/

$rawInput = file_get_contents("php://input");

$data = json_decode(
    $rawInput,
    true
);


if (!is_array($data)) {

    echo json_encode([
        "success" => false,
        "error" => "Invalid request data."
    ]);

    $conn->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| Get login fields
|--------------------------------------------------------------------------
*/

$email = trim(
    $data['email'] ?? ''
);

$password =
    $data['password'] ?? '';


/*
|--------------------------------------------------------------------------
| Validate fields
|--------------------------------------------------------------------------
*/

if ($email === '' || $password === '') {

    echo json_encode([
        "success" => false,
        "error" => "Email and password are required."
    ]);

    $conn->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| Find user
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        full_name,
        email,
        phone,
        cnic,
        password,
        role,
        status
    FROM users
    WHERE email = ?
    LIMIT 1
");


if (!$stmt) {

    echo json_encode([
        "success" => false,
        "error" => "Database query preparation failed.",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param(
    "s",
    $email
);


if (!$stmt->execute()) {

    echo json_encode([
        "success" => false,
        "error" => "Database query failed.",
        "details" => $stmt->error
    ]);

    $stmt->close();

    $conn->close();

    exit;
}


$result = $stmt->get_result();


/*
|--------------------------------------------------------------------------
| User not found
|--------------------------------------------------------------------------
*/

if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "error" => "Invalid email or password."
    ]);

    $stmt->close();

    $conn->close();

    exit;
}


$user = $result->fetch_assoc();


/*
|--------------------------------------------------------------------------
| Check password
|--------------------------------------------------------------------------
*/

if (!password_verify(
    $password,
    $user['password']
)) {

    echo json_encode([
        "success" => false,
        "error" => "Invalid email or password."
    ]);

    $stmt->close();

    $conn->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| Check account status
|--------------------------------------------------------------------------
|
| IMPORTANT:
| New users do NOT need admin approval.
|
| Therefore, when we build signup.php, newly registered
| users should be created with an active/usable status.
|
| For now we prevent explicitly rejected/inactive accounts
| from logging in.
|
*/

if (
    $user['status'] === 'rejected' ||
    $user['status'] === 'inactive'
) {

    echo json_encode([
        "success" => false,
        "error" => "Your account is currently inactive or rejected."
    ]);

    $stmt->close();

    $conn->close();

    exit;
}


/*
|--------------------------------------------------------------------------
| Regenerate session ID
|--------------------------------------------------------------------------
*/

session_regenerate_id(true);


/*
|--------------------------------------------------------------------------
| Store authenticated user in PHP session
|--------------------------------------------------------------------------
*/

$_SESSION['user_id'] =
    (int)$user['id'];

$_SESSION['full_name'] =
    $user['full_name'];

$_SESSION['email'] =
    $user['email'];

$_SESSION['phone'] =
    $user['phone'];

$_SESSION['cnic'] =
    $user['cnic'];

$_SESSION['role'] =
    $user['role'];

$_SESSION['logged_in'] =
    true;


/*
|--------------------------------------------------------------------------
| Successful login
|--------------------------------------------------------------------------
*/

echo json_encode([

    "success" => true,

    "message" =>
        "Login successful.",

    "user" => [

        "id" =>
            (int)$user['id'],

        "full_name" =>
            $user['full_name'],

        "email" =>
            $user['email'],

        "phone" =>
            $user['phone'],

        "cnic" =>
            $user['cnic'],

        "role" =>
            $user['role']

    ]

]);


$stmt->close();

$conn->close();

?>