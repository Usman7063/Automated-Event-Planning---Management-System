<?php

// ================================================================
// CONTACT FORM BACKEND
// ================================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json; charset=UTF-8");

// ================================================================
// HANDLE PREFLIGHT REQUEST
// ================================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ================================================================
// ONLY ALLOW POST
// ================================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}

// ================================================================
// DATABASE CONNECTION
// ================================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);

if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed.",
        "details" => $conn->connect_error
    ]);

    exit;
}

$conn->set_charset("utf8mb4");

// ================================================================
// READ JSON DATA
// ================================================================

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);

// If JSON wasn't sent, also support normal POST data
if (!is_array($data)) {
    $data = $_POST;
}

// ================================================================
// GET FORM VALUES
// ================================================================

$name = trim($data['name'] ?? '');

$email = trim($data['email'] ?? '');

$phone = trim($data['phone'] ?? '');

$subject = trim($data['subject'] ?? '');

$message = trim($data['message'] ?? '');

// ================================================================
// REQUIRED FIELD VALIDATION
// ================================================================

if (
    $name === '' ||
    $email === '' ||
    $phone === '' ||
    $subject === '' ||
    $message === ''
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Please fill all required fields."
    ]);

    $conn->close();

    exit;
}

// ================================================================
// EMAIL VALIDATION
// ================================================================

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid email address."
    ]);

    $conn->close();

    exit;
}

// ================================================================
// PHONE VALIDATION
// ================================================================

// Allow numbers and + only
$cleanPhone = preg_replace('/[^0-9+]/', '', $phone);

if (strlen($cleanPhone) < 11) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid phone number."
    ]);

    $conn->close();

    exit;
}

// ================================================================
// INSERT CONTACT MESSAGE
// ================================================================

$stmt = $conn->prepare("
    INSERT INTO contact_messages
    (
        name,
        email,
        phone,
        subject,
        message
    )
    VALUES
    (
        ?,
        ?,
        ?,
        ?,
        ?
    )
");

if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to prepare database query.",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}

// ================================================================
// BIND PARAMETERS
// ================================================================

$stmt->bind_param(
    "sssss",
    $name,
    $email,
    $cleanPhone,
    $subject,
    $message
);

// ================================================================
// EXECUTE
// ================================================================

if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to save contact message.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();

    exit;
}

// ================================================================
// SUCCESS
// ================================================================

$contact_id = $stmt->insert_id;

$stmt->close();
$conn->close();

echo json_encode([
    "success" => true,
    "message" => "Your message has been submitted successfully.",
    "contact_id" => $contact_id
]);

?>