<?php

session_start();


// ==========================
// CORS HEADERS
// ==========================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// ==========================
// HANDLE PREFLIGHT
// ==========================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);

    exit;
}


// ==========================
// ONLY POST ALLOWED
// ==========================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}


// ==========================
// DATABASE CONNECTION
// ==========================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    echo json_encode([
        "success" => false,
        "error" => "DB connection failed",
        "details" => $conn->connect_error
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// ==========================
// LOGGED-IN USER
// ==========================

// Login is OPTIONAL.
//
// If the customer is logged in,
// their actual users.id will be attached
// to the booking.
//
// If the customer is not logged in,
// user_id remains NULL and the booking
// works as a guest booking.

$user_id = null;


if (
    !empty($_SESSION['logged_in']) &&
    !empty($_SESSION['user_id'])
) {

    $user_id = (int) $_SESSION['user_id'];
}


// ==========================
// READ INPUT
// ==========================

// Supports JSON requests from JavaScript.

$data = json_decode(
    file_get_contents("php://input"),
    true
);


// If JSON wasn't received,
// also support normal form POST.

if (!$data || empty($data)) {

    $data = $_POST;
}


// ==========================
// EXTRACT VALUES
// ==========================


// Required fields

$event_type = trim(
    $data['event_type'] ?? ''
);

$event_date = trim(
    $data['event_date'] ?? ''
);

$customer_name = trim(
    $data['customer_name'] ?? ''
);

$customer_phone = trim(
    $data['customer_phone'] ?? ''
);


// Optional fields

$location = trim(
    $data['location'] ?? 'Not provided'
);

$start_time = !empty($data['start_time'])
    ? trim($data['start_time'])
    : null;

$end_time = !empty($data['end_time'])
    ? trim($data['end_time'])
    : null;

$transport = trim(
    $data['transport'] ?? 'No'
);


// ==========================
// PAYMENT METHOD
// ==========================

$payment_method = 'Not selected';


// 1. Frontend explicitly sends
// payment method.

if (!empty($data['payment_method'])) {

    $payment_method =
        trim($data['payment_method']);

}


// 2. Detect cash payment
// through advance payment.

elseif (
    !empty($data['advancePayment']) &&
    $data['advancePayment'] > 0
) {

    $payment_method = 'cash';

}


// 3. Detect online payment
// through uploaded screenshot.

elseif (
    !empty($_FILES['payment_screenshot']['name'])
) {

    $payment_method = 'online';

}


// ==========================
// ADVANCE / REMAINING PAYMENT
// ==========================

$advance_payment = (float) (
    $data['advance_payment']
    ?? $data['advancePayment']
    ?? 0
);


$remaining_amount = (float) (
    $data['remaining_amount']
    ?? $data['remainingAmount']
    ?? 0
);


// ==========================
// VALIDATION
// ==========================

if (
    !$event_type ||
    !$event_date ||
    !$customer_name ||
    !$customer_phone
) {

    echo json_encode([
        "success" => false,
        "error" => "Missing required fields",
        "received" => $data
    ]);

    $conn->close();

    exit;
}


// ==========================
// 1. INSERT EVENT
// ==========================
//
// Logged-in customer:
//     user_id = actual users.id
//
// Guest customer:
//     user_id = NULL
//
// Therefore login remains optional.

$stmt = $conn->prepare("
    INSERT INTO events
    (
        user_id,
        title,
        event_date,
        location,
        budget
    )
    VALUES
    (
        ?,
        ?,
        ?,
        ?,
        0
    )
");


if (!$stmt) {

    echo json_encode([
        "success" => false,
        "error" => "Event prepare failed",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}


// user_id is nullable.
// mysqli can send NULL correctly when
// bound as an integer parameter.

$stmt->bind_param(
    "isss",
    $user_id,
    $event_type,
    $event_date,
    $location
);


if (!$stmt->execute()) {

    echo json_encode([
        "success" => false,
        "error" => "Event insert failed",
        "details" => $stmt->error
    ]);

    $stmt->close();

    $conn->close();

    exit;
}


// Get newly created event ID

$event_id = $stmt->insert_id;

$stmt->close();


// ==========================
// 2. GET VENDOR
// ==========================

$result = $conn->query("
    SELECT id
    FROM vendors
    WHERE status IN ('active', 'approved')
    LIMIT 1
");


if (!$result) {

    echo json_encode([
        "success" => false,
        "error" => "Vendor query failed",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}


if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "error" => "No vendor found"
    ]);

    $conn->close();

    exit;
}


$vendor = $result->fetch_assoc();

$vendor_id = (int) $vendor['id'];


// ==========================
// 3. INSERT BOOKING1
// ==========================

$stmt2 = $conn->prepare("
    INSERT INTO booking1
    (
        event_id,
        vendor_id,
        status,
        event_date,
        event_type,
        customer_name,
        customer_phone,
        start_time,
        end_time,
        transport,
        payment_method,
        advance_payment,
        remaining_amount
    )
    VALUES
    (
        ?,
        ?,
        'pending',
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?
    )
");


if (!$stmt2) {

    echo json_encode([
        "success" => false,
        "error" => "Booking prepare failed",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}


$stmt2->bind_param(
    "iissssssssdd",
    $event_id,
    $vendor_id,
    $event_date,
    $event_type,
    $customer_name,
    $customer_phone,
    $start_time,
    $end_time,
    $transport,
    $payment_method,
    $advance_payment,
    $remaining_amount
);


if (!$stmt2->execute()) {

    echo json_encode([
        "success" => false,
        "error" => "Booking insert failed",
        "details" => $stmt2->error
    ]);

    $stmt2->close();

    $conn->close();

    exit;
}


// ==========================
// SUCCESS RESPONSE
// ==========================

echo json_encode([

    "success" => true,

    "message" =>
        "Booking created successfully",

    "event_id" =>
        $event_id,

    "vendor_id" =>
        $vendor_id,

    "user_id" =>
        $user_id,

    "logged_in" =>
        ($user_id !== null),

    "payment_method_detected" =>
        $payment_method,

    "advance_payment" =>
        $advance_payment,

    "remaining_amount" =>
        $remaining_amount,

    "data_received" =>
        $data

]);


// ==========================
// CLOSE CONNECTION
// ==========================

$stmt2->close();

$conn->close();

?>

