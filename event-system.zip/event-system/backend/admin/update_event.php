<?php

// =========================================================
// UPDATE EVENT - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// GET FORM DATA
// =========================================================

$event_id = (int) (
    $_POST["event_id"] ?? 0
);

$user_id = (int) (
    $_POST["user_id"] ?? 0
);

$title = trim(
    $_POST["title"] ?? ""
);

$event_type = trim(
    $_POST["event_type"] ?? ""
);

$description = trim(
    $_POST["description"] ?? ""
);

$client_name = trim(
    $_POST["client_name"] ?? ""
);

$client_phone = trim(
    $_POST["client_phone"] ?? ""
);

$client_email = trim(
    $_POST["client_email"] ?? ""
);

$event_date = trim(
    $_POST["event_date"] ?? ""
);

$event_time = trim(
    $_POST["event_time"] ?? ""
);

$location = trim(
    $_POST["location"] ?? ""
);

$budget = $_POST["budget"] ?? "";

$status = trim(
    $_POST["status"] ?? "pending"
);


// =========================================================
// VALIDATE EVENT ID
// =========================================================

if ($event_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Valid event ID is required."
    ]);

    exit;
}


// =========================================================
// VALIDATE USER ID
// =========================================================

if ($user_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Valid user ID is required."
    ]);

    exit;
}


// =========================================================
// VALIDATE TITLE
// =========================================================

if ($title === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event title is required."
    ]);

    exit;
}


if (strlen($title) > 255) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event title is too long."
    ]);

    exit;
}


// =========================================================
// VALIDATE EVENT DATE
// =========================================================

if ($event_date === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event date is required."
    ]);

    exit;
}


$dateObject = DateTime::createFromFormat(
    "Y-m-d",
    $event_date
);


if (
    !$dateObject ||
    $dateObject->format("Y-m-d") !== $event_date
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid event date."
    ]);

    exit;
}


// =========================================================
// VALIDATE EVENT TIME
// =========================================================

if ($event_time !== "") {

    $timeObject = DateTime::createFromFormat(
        "H:i",
        $event_time
    );


    if (
        !$timeObject ||
        $timeObject->format("H:i") !== $event_time
    ) {

        http_response_code(400);

        echo json_encode([
            "success" => false,
            "error" => "Invalid event time."
        ]);

        exit;
    }

}


// =========================================================
// CONVERT EMPTY TIME TO NULL
// =========================================================

if ($event_time === "") {

    $event_time = null;

}


// =========================================================
// VALIDATE LOCATION
// =========================================================

if (strlen($location) > 255) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event location is too long."
    ]);

    exit;
}


// =========================================================
// VALIDATE EMAIL
// =========================================================

if (
    $client_email !== "" &&
    !filter_var(
        $client_email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid client email."
    ]);

    exit;
}


// =========================================================
// VALIDATE BUDGET
// =========================================================

if (
    $budget === "" ||
    !is_numeric($budget)
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid budget is required."
    ]);

    exit;
}


$budget = (float) $budget;


if ($budget < 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Budget cannot be negative."
    ]);

    exit;
}


// =========================================================
// VALIDATE STATUS
// =========================================================

$allowedStatuses = [
    "pending",
    "confirmed",
    "completed",
    "cancelled"
];


if (
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid event status."
    ]);

    exit;
}


// =========================================================
// UPDATE EVENT
// =========================================================

try {

    // =====================================================
    // CHECK EVENT
    // =====================================================

    $eventCheck = $conn->prepare(
        "SELECT id
         FROM events
         WHERE id = ?
         LIMIT 1"
    );


    if (!$eventCheck) {

        throw new Exception(
            $conn->error
        );

    }


    $eventCheck->bind_param(
        "i",
        $event_id
    );


    $eventCheck->execute();


    $eventResult =
        $eventCheck->get_result();


    if (!$eventResult->fetch_assoc()) {

        $eventCheck->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "Event not found."
        ]);

        exit;
    }


    $eventCheck->close();


    // =====================================================
    // CHECK USER
    // =====================================================

    $userCheck = $conn->prepare(
        "SELECT id
         FROM users
         WHERE id = ?
         LIMIT 1"
    );


    if (!$userCheck) {

        throw new Exception(
            $conn->error
        );

    }


    $userCheck->bind_param(
        "i",
        $user_id
    );


    $userCheck->execute();


    $userResult =
        $userCheck->get_result();


    if (!$userResult->fetch_assoc()) {

        $userCheck->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "User not found."
        ]);

        exit;
    }


    $userCheck->close();


    // =====================================================
    // UPDATE
    // =====================================================

    $stmt = $conn->prepare(
        "UPDATE events
         SET
            user_id = ?,
            title = ?,
            event_type = ?,
            description = ?,
            client_name = ?,
            client_phone = ?,
            client_email = ?,
            event_date = ?,
            event_time = ?,
            location = ?,
            budget = ?,
            status = ?,
            updated_at = CURRENT_TIMESTAMP
         WHERE id = ?"
    );


    if (!$stmt) {

        throw new Exception(
            $conn->error
        );

    }


    // =====================================================
    // IMPORTANT:
    // 1 integer
    // 9 strings
    // 1 decimal
    // 1 string
    // 1 integer
    //
    // Total = 13 parameters
    // =====================================================

    $stmt->bind_param(
        "isssssssssdsi",
        $user_id,
        $title,
        $event_type,
        $description,
        $client_name,
        $client_phone,
        $client_email,
        $event_date,
        $event_time,
        $location,
        $budget,
        $status,
        $event_id
    );


    if (!$stmt->execute()) {

        throw new Exception(
            $stmt->error
        );

    }


    $stmt->close();


    // =====================================================
    // SUCCESS
    // =====================================================

    echo json_encode([

        "success" => true,

        "message" =>
            "Event updated successfully.",

        "event_id" =>
            $event_id

    ]);

    exit;


} catch (Exception $error) {

    // =====================================================
    // LOG ACTUAL ERROR
    // =====================================================

    error_log(
        "UPDATE EVENT ERROR: " .
        $error->getMessage()
    );


    // =====================================================
    // ERROR RESPONSE
    // =====================================================

    http_response_code(500);

    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to update event.",

        "debug" =>
            $error->getMessage()

    ]);

    exit;

}

?>