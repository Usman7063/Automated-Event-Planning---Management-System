<?php

// =========================================================
// CREATE VENDOR - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST REQUESTS
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "POST request required."
    ]);

    exit;
}


// =========================================================
// READ JSON DATA
// =========================================================

$input = json_decode(
    file_get_contents("php://input"),
    true
);


if (!is_array($input)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request data."
    ]);

    exit;
}


// =========================================================
// INPUT
// =========================================================

$name =
    trim(
        $input["name"] ?? ""
    );

$service_type =
    trim(
        $input["service_type"] ?? ""
    );

$description =
    trim(
        $input["description"] ?? ""
    );

$phone =
    trim(
        $input["phone"] ?? ""
    );

$email =
    trim(
        $input["email"] ?? ""
    );

$price =
    $input["price"] ?? "";

$status =
    strtolower(
        trim(
            $input["status"] ?? "pending"
        )
    );


// =========================================================
// VALIDATION
// =========================================================

if ($name === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Vendor name is required."
    ]);

    exit;
}


if ($service_type === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Service type is required."
    ]);

    exit;
}


if ($price === "" || !is_numeric($price)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid vendor price is required."
    ]);

    exit;
}


$price = (float) $price;


if ($price < 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Vendor price cannot be negative."
    ]);

    exit;
}


// =========================================================
// EMAIL VALIDATION
// =========================================================

if (
    $email !== "" &&
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid email address."
    ]);

    exit;
}


// =========================================================
// STATUS VALIDATION
// =========================================================

$allowedStatuses = [
    "pending",
    "approved",
    "rejected",
    "inactive"
];


if (
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid vendor status."
    ]);

    exit;
}


// =========================================================
// INSERT VENDOR
// =========================================================

try {

    $query = "
        INSERT INTO vendors
        (
            name,
            service_type,
            description,
            phone,
            email,
            price,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ";


    $stmt =
        $conn->prepare($query);


    if (!$stmt) {

        throw new Exception(
            $conn->error
        );

    }


    $stmt->bind_param(
        "sssssds",
        $name,
        $service_type,
        $description,
        $phone,
        $email,
        $price,
        $status
    );


    if (!$stmt->execute()) {

        throw new Exception(
            $stmt->error
        );

    }


    $vendorId =
        $stmt->insert_id;


    $stmt->close();


    // =====================================================
    // SUCCESS
    // =====================================================

    echo json_encode([

        "success" => true,

        "message" =>
            "Vendor created successfully.",

        "vendor" => [

            "id" =>
                (int) $vendorId,

            "name" =>
                $name,

            "service_type" =>
                $service_type,

            "description" =>
                $description,

            "phone" =>
                $phone,

            "email" =>
                $email,

            "price" =>
                $price,

            "status" =>
                $status

        ]

    ]);


} catch (Exception $error) {

    error_log(
        "CREATE VENDOR ERROR: " .
        $error->getMessage()
    );


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to create vendor."

    ]);

}

?>