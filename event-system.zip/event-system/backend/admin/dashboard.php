<?php

// =====================================================
// ADMIN SECURITY
// =====================================================

require_once __DIR__ . "/admin_session.php";


// =====================================================
// DATABASE CONNECTION
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);

if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}

$conn->set_charset("utf8mb4");


// =====================================================
// HELPER FUNCTION
// =====================================================

function getCount($conn, $query)
{
    $result = $conn->query($query);

    if (!$result) {
        return 0;
    }

    $row = $result->fetch_assoc();

    return (int) ($row['total'] ?? 0);
}



// =====================================================
// USERS
// =====================================================


$totalUsers = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role != 'admin'
    "
);



$totalAdmins = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'admin'
    "
);



/*
 * In the users table, an approved account is considered
 * an active customer account.
 */

$activeUsers = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role != 'admin'
    AND status = 'approved'
    "
);



$inactiveUsers = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role != 'admin'
    AND status = 'inactive'
    "
);



$rejectedUsers = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role != 'admin'
    AND status = 'rejected'
    "
);




// =====================================================
// EVENTS
// =====================================================

$totalEvents = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM events
    "
);


// =====================================================
// VENDORS
// =====================================================

$totalVendors = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM vendors
    "
);


$activeVendors = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM vendors
    WHERE status = 'active'
    "
);


$approvedVendors = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM vendors
    WHERE status = 'approved'
    "
);


$pendingVendors = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM vendors
    WHERE status = 'pending'
    "
);


$rejectedVendors = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM vendors
    WHERE status = 'rejected'
    "
);


// =====================================================
// BOOKING TABLE COUNTS
// =====================================================

// -----------------------------------------------------
// booking
// -----------------------------------------------------

$totalBooking = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking
    "
);


$pendingBooking = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking
    WHERE status = 'pending'
    "
);


$approvedBooking = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking
    WHERE status IN ('approved', 'confirmed')
    "
);


$rejectedBooking = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking
    WHERE status IN ('rejected', 'cancelled')
    "
);


// -----------------------------------------------------
// booking1
// -----------------------------------------------------

$totalBooking1 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking1
    "
);


$pendingBooking1 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking1
    WHERE status = 'pending'
    "
);


$approvedBooking1 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking1
    WHERE status IN ('approved', 'confirmed')
    "
);


$rejectedBooking1 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking1
    WHERE status IN ('rejected', 'cancelled')
    "
);


// -----------------------------------------------------
// booking2
// -----------------------------------------------------

$totalBooking2 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking2
    "
);


$pendingBooking2 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking2
    WHERE status = 'pending'
    "
);


$approvedBooking2 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking2
    WHERE status IN ('approved', 'confirmed')
    "
);


$rejectedBooking2 = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM booking2
    WHERE status IN ('rejected', 'cancelled')
    "
);


// =====================================================
// COMBINED BOOKING COUNTS
// =====================================================

$totalBookings =
    $totalBooking +
    $totalBooking1 +
    $totalBooking2;


$pendingBookings =
    $pendingBooking +
    $pendingBooking1 +
    $pendingBooking2;


$approvedBookings =
    $approvedBooking +
    $approvedBooking1 +
    $approvedBooking2;


$rejectedBookings =
    $rejectedBooking +
    $rejectedBooking1 +
    $rejectedBooking2;


// =====================================================
// RESPONSE
// =====================================================

http_response_code(200);

echo json_encode([

    "success" => true,

    "admin" => getAdminSession(),

    "statistics" => [

        // -------------------------------------------------
        // USERS
        // -------------------------------------------------

        "users" => [

            "total" => $totalUsers,

            "active" => $activeUsers,

            "inactive" => $inactiveUsers,

            "rejected" => $rejectedUsers
        ],


        // -------------------------------------------------
        // ADMINS
        // -------------------------------------------------

        "admins" => [

            "total" => $totalAdmins
        ],


        // -------------------------------------------------
        // EVENTS
        // -------------------------------------------------

        "events" => [

            "total" => $totalEvents
        ],


        // -------------------------------------------------
        // VENDORS
        // -------------------------------------------------

        "vendors" => [

            "total" => $totalVendors,

            "active" => $activeVendors,

            "approved" => $approvedVendors,

            "pending" => $pendingVendors,

            "rejected" => $rejectedVendors
        ],


        // -------------------------------------------------
        // ALL BOOKINGS
        // -------------------------------------------------

        "bookings" => [

            "total" => $totalBookings,

            "pending" => $pendingBookings,

            "approved" => $approvedBookings,

            "rejected" => $rejectedBookings
        ],


        // -------------------------------------------------
        // INDIVIDUAL BOOKING SYSTEMS
        // -------------------------------------------------

        "booking" => [

            "total" => $totalBooking,

            "pending" => $pendingBooking,

            "approved" => $approvedBooking,

            "rejected" => $rejectedBooking
        ],

        "booking1" => [

            "total" => $totalBooking1,

            "pending" => $pendingBooking1,

            "approved" => $approvedBooking1,

            "rejected" => $rejectedBooking1
        ],

        "booking2" => [

            "total" => $totalBooking2,

            "pending" => $pendingBooking2,

            "approved" => $approvedBooking2,

            "rejected" => $rejectedBooking2
        ]
    ]
]);


$conn->close();

?>