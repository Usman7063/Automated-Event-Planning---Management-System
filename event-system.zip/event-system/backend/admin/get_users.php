<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// HANDLE OPTIONS
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


// =====================================================
// REQUEST METHOD
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =====================================================
// START SESSION
// =====================================================

session_start();


// =====================================================
// ADMIN AUTHORIZATION
// =====================================================

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;
}


// =====================================================
// DATABASE
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =====================================================
// GET CUSTOMER USERS
// =====================================================

$stmt = $conn->prepare("
    SELECT
        id,
        full_name,
        email,
        phone,
        cnic,
        role,
        status,
        created_at,
        updated_at
    FROM users
    WHERE role = 'user'
    ORDER BY created_at DESC
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to prepare users query."
    ]);

    $conn->close();

    exit;
}


$stmt->execute();

$result = $stmt->get_result();


// =====================================================
// BUILD USERS ARRAY
// =====================================================

$users = [];


while ($row = $result->fetch_assoc()) {

    $users[] = [
        "id" => (int)$row["id"],
        "full_name" => $row["full_name"],
        "email" => $row["email"],
        "phone" => $row["phone"],
        "cnic" => $row["cnic"],
        "role" => $row["role"],
        "status" => $row["status"],
        "created_at" => $row["created_at"],
        "updated_at" => $row["updated_at"]
    ];

}


// =====================================================
// SUCCESS RESPONSE
// =====================================================

echo json_encode([
    "success" => true,
    "admin_id" => (int)$_SESSION["user_id"],
    "count" => count($users),
    "users" => $users
], JSON_UNESCAPED_UNICODE);


// =====================================================
// CLOSE
// =====================================================

$stmt->close();

$conn->close();

?>

