<?php

// =====================================================
// ERROR REPORTING
// =====================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// SESSION
// =====================================================

session_start();


// =====================================================
// CORS + JSON
// =====================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// OPTIONS / PREFLIGHT
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;

}


// =====================================================
// ONLY GET ALLOWED
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only GET requests are allowed."
    ]);

    exit;

}


// =====================================================
// ADMIN AUTHENTICATION
// =====================================================

if (
    empty($_SESSION['user_id']) ||
    empty($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;

}


// =====================================================
// DATABASE
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;

}


$conn->set_charset("utf8mb4");


// =====================================================
// BOOKINGS ARRAY
// =====================================================

$bookings = [];


// =====================================================
// BOOKING TABLE
// =====================================================

$sql = "
    SELECT
        id,
        event_id,
        vendor_id,
        status,
        event_date,
        event_type,
        customer_name,
        customer_phone
    FROM booking
    ORDER BY id DESC
";


$result = $conn->query($sql);


if ($result) {

    while ($row = $result->fetch_assoc()) {

        $bookings[] = [

            "id" => (int) $row['id'],

            "event_id" => $row['event_id'],

            "vendor_id" => $row['vendor_id'],

            "status" => $row['status'],

            "event_date" => $row['event_date'],

            "event_type" => $row['event_type'],

            "customer_name" => $row['customer_name'],

            "customer_phone" => $row['customer_phone'],

            "source" => "booking"

        ];

    }

}


// =====================================================
// BOOKING1 TABLE
// =====================================================

$sql = "
    SELECT
        id,
        event_id,
        vendor_id,
        status,
        event_date,
        event_type,
        customer_name,
        customer_phone,
        start_time,
        end_time,
        transport,
        payment_method,
        advance_payment,
        remaining_amount
    FROM booking1
    ORDER BY id DESC
";


$result = $conn->query($sql);


if ($result) {

    while ($row = $result->fetch_assoc()) {

        $bookings[] = [

            "id" => (int) $row['id'],

            "event_id" => $row['event_id'],

            "vendor_id" => $row['vendor_id'],

            "status" => $row['status'],

            "event_date" => $row['event_date'],

            "event_type" => $row['event_type'],

            "customer_name" => $row['customer_name'],

            "customer_phone" => $row['customer_phone'],

            "start_time" => $row['start_time'],

            "end_time" => $row['end_time'],

            "transport" => $row['transport'],

            "payment_method" => $row['payment_method'],

            "advance_payment" => $row['advance_payment'],

            "remaining_amount" => $row['remaining_amount'],

            "source" => "booking1"

        ];

    }

}


// =====================================================
// BOOKING2 TABLE
// =====================================================

$sql = "
    SELECT *
    FROM booking2
    ORDER BY id DESC
";


$result = $conn->query($sql);


if ($result) {

    while ($row = $result->fetch_assoc()) {

        /*
         * booking2 may contain additional fields.
         * We preserve the common booking information
         * and also return the complete database row.
         */

        $booking = [

            "id" => (int) $row['id'],

            "event_id" => $row['event_id'] ?? null,

            "vendor_id" => $row['vendor_id'] ?? null,

            "status" => $row['status'] ?? null,

            "event_date" => $row['event_date'] ?? null,

            "event_type" => $row['event_type'] ?? null,

            "customer_name" => $row['customer_name'] ?? null,

            "customer_phone" => $row['customer_phone'] ?? null,

            "source" => "booking2"

        ];


        /*
         * Keep the complete booking2 row available
         * for the future View Booking feature.
         */

        $booking['details'] = $row;


        $bookings[] = $booking;

    }

}


// =====================================================
// SORT ALL BOOKINGS
// =====================================================

usort(
    $bookings,
    function ($a, $b) {

        return (int) $b['id'] <=> (int) $a['id'];

    }
);


// =====================================================
// SUCCESS
// =====================================================

echo json_encode([

    "success" => true,

    "admin_id" => (int) $_SESSION['user_id'],

    "count" => count($bookings),

    "bookings" => $bookings

], JSON_UNESCAPED_UNICODE);


// =====================================================
// CLOSE DATABASE
// =====================================================

$conn->close();

?>

