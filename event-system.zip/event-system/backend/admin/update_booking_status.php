<?php

// =====================================================
// ERROR REPORTING
// =====================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// SESSION
// =====================================================

session_start();


// =====================================================
// CORS + JSON
// =====================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// PREFLIGHT
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// =====================================================
// ONLY POST
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}


// =====================================================
// ADMIN AUTHENTICATION
// =====================================================

if (
    empty($_SESSION['user_id']) ||
    empty($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;
}


// =====================================================
// DATABASE CONNECTION
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =====================================================
// READ INPUT
// =====================================================

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);


if (!is_array($data)) {
    $data = $_POST;
}


$booking_id = isset($data['booking_id'])
    ? (int) $data['booking_id']
    : 0;


$source = trim(
    $data['source'] ?? ''
);


$status = trim(
    $data['status'] ?? ''
);


// =====================================================
// VALIDATION
// =====================================================

if ($booking_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid booking ID is required."
    ]);

    $conn->close();

    exit;
}


$allowedSources = [
    "booking",
    "booking1",
    "booking2"
];


if (!in_array($source, $allowedSources, true)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid booking source.",
        "allowed_sources" => $allowedSources
    ]);

    $conn->close();

    exit;
}


$allowedStatuses = [
    "approved",
    "rejected"
];


if (!in_array($status, $allowedStatuses, true)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid booking status.",
        "allowed_statuses" => $allowedStatuses
    ]);

    $conn->close();

    exit;
}


// =====================================================
// SELECT CORRECT TABLE
// =====================================================

$table = "";


switch ($source) {

    case "booking":

        $table = "booking";

        break;


    case "booking1":

        $table = "booking1";

        break;


    case "booking2":

        $table = "booking2";

        break;

}


// =====================================================
// CHECK BOOKING
// =====================================================

$stmt = $conn->prepare("
    SELECT
        id,
        customer_name,
        customer_phone,
        status
    FROM `$table`
    WHERE id = ?
    LIMIT 1
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare booking lookup."
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param(
    "i",
    $booking_id
);


$stmt->execute();


$result = $stmt->get_result();


if ($result->num_rows === 0) {

    http_response_code(404);

    echo json_encode([
        "success" => false,
        "error" => "Booking not found."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


$booking = $result->fetch_assoc();


$stmt->close();


// =====================================================
// PREVENT UNNECESSARY UPDATE
// =====================================================

if (
    strtolower(
        $booking['status'] ?? ''
    ) === $status
) {

    echo json_encode([
        "success" => true,
        "message" => "Booking is already marked as " . $status . ".",
        "booking" => [
            "id" => $booking_id,
            "source" => $source,
            "status" => $status
        ]
    ]);

    $conn->close();

    exit;
}


// =====================================================
// UPDATE STATUS
// =====================================================

$stmt = $conn->prepare("
    UPDATE `$table`
    SET status = ?
    WHERE id = ?
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare booking update."
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param(
    "si",
    $status,
    $booking_id
);


if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to update booking status.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =====================================================
// SUCCESS
// =====================================================

echo json_encode([

    "success" => true,

    "message" =>
        "Booking " . $status . " successfully.",

    "booking" => [

        "id" =>
            $booking_id,

        "source" =>
            $source,

        "customer_name" =>
            $booking['customer_name'],

        "customer_phone" =>
            $booking['customer_phone'],

        "status" =>
            $status

    ]

]);


$stmt->close();
$conn->close();

?>