<?php

// =====================================================
// ERROR REPORTING
// =====================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// START SESSION
// =====================================================

session_start();


// =====================================================
// JSON RESPONSE
// =====================================================

header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// CHECK LOGIN
// =====================================================

if (
    empty($_SESSION['user_id']) ||
    empty($_SESSION['role'])
) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "error" => "You must be logged in."
    ]);

    exit;
}


// =====================================================
// CHECK ADMIN ROLE
// =====================================================

if ($_SESSION['role'] !== 'admin') {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;
}


// =====================================================
// ADMIN AUTHENTICATED
// =====================================================

$admin_id = (int) $_SESSION['user_id'];

$admin_name = $_SESSION['full_name'] ?? '';

$admin_email = $_SESSION['email'] ?? '';


// =====================================================
// FUNCTION: ADMIN SESSION DATA
// =====================================================

function getAdminSession()
{
    global $admin_id;
    global $admin_name;
    global $admin_email;

    return [
        "admin_id" => $admin_id,
        "admin_name" => $admin_name,
        "admin_email" => $admin_email,
        "role" => "admin"
    ];
}

?>