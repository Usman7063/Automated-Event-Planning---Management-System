<?php

// =========================================================
// UPDATE VENDOR - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// ACTION
// =========================================================

$action = strtolower(
    trim(
        $_POST["action"] ?? ""
    )
);


// =========================================================
// VENDOR ID
// =========================================================

$vendor_id = (int) (
    $_POST["vendor_id"] ?? 0
);


if ($vendor_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid vendor ID."
    ]);

    exit;
}


// =========================================================
// ALLOWED ACTIONS
// =========================================================

$allowedActions = [
    "approve",
    "reject",
    "inactive",
    "edit"
];


if (!in_array($action, $allowedActions, true)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid vendor action."
    ]);

    exit;
}


// =========================================================
// CHECK VENDOR
// =========================================================

try {

    $check = $conn->prepare(
        "SELECT id
         FROM vendors
         WHERE id = ?
         LIMIT 1"
    );


    if (!$check) {

        throw new Exception(
            $conn->error
        );

    }


    $check->bind_param(
        "i",
        $vendor_id
    );


    $check->execute();


    $result = $check->get_result();


    if (!$result->fetch_assoc()) {

        $check->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "Vendor not found."
        ]);

        exit;
    }


    $check->close();


    // =====================================================
    // APPROVE
    // =====================================================

    if ($action === "approve") {

        $stmt = $conn->prepare(
            "UPDATE vendors
             SET status = 'approved'
             WHERE id = ?"
        );


        if (!$stmt) {

            throw new Exception(
                $conn->error
            );

        }


        $stmt->bind_param(
            "i",
            $vendor_id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                $stmt->error
            );

        }


        $stmt->close();


        echo json_encode([
            "success" => true,
            "message" => "Vendor approved successfully.",
            "vendor_id" => $vendor_id,
            "status" => "approved"
        ]);

        exit;
    }


    // =====================================================
    // REJECT
    // =====================================================

    if ($action === "reject") {

        $stmt = $conn->prepare(
            "UPDATE vendors
             SET status = 'rejected'
             WHERE id = ?"
        );


        if (!$stmt) {

            throw new Exception(
                $conn->error
            );

        }


        $stmt->bind_param(
            "i",
            $vendor_id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                $stmt->error
            );

        }


        $stmt->close();


        echo json_encode([
            "success" => true,
            "message" => "Vendor rejected successfully.",
            "vendor_id" => $vendor_id,
            "status" => "rejected"
        ]);

        exit;
    }


    // =====================================================
    // INACTIVE
    // =====================================================

    if ($action === "inactive") {

        $stmt = $conn->prepare(
            "UPDATE vendors
             SET status = 'inactive'
             WHERE id = ?"
        );


        if (!$stmt) {

            throw new Exception(
                $conn->error
            );

        }


        $stmt->bind_param(
            "i",
            $vendor_id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                $stmt->error
            );

        }


        $stmt->close();


        echo json_encode([
            "success" => true,
            "message" => "Vendor marked as inactive.",
            "vendor_id" => $vendor_id,
            "status" => "inactive"
        ]);

        exit;
    }


    // =====================================================
    // EDIT VENDOR
    // =====================================================

    if ($action === "edit") {


        // -------------------------------------------------
        // GET FORM DATA
        // -------------------------------------------------

        $name = trim(
            $_POST["name"] ?? ""
        );


        $service_type = trim(
            $_POST["service_type"] ?? ""
        );


        $description = trim(
            $_POST["description"] ?? ""
        );


        $phone = trim(
            $_POST["phone"] ?? ""
        );


        $email = trim(
            $_POST["email"] ?? ""
        );


        $price = $_POST["price"] ?? "";


        $status = strtolower(
            trim(
                $_POST["status"] ?? ""
            )
        );


        // -------------------------------------------------
        // VALIDATE NAME
        // -------------------------------------------------

        if ($name === "") {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "Vendor name is required."
            ]);

            exit;
        }


        // -------------------------------------------------
        // VALIDATE SERVICE TYPE
        // -------------------------------------------------

        if ($service_type === "") {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "Service type is required."
            ]);

            exit;
        }


        // -------------------------------------------------
        // VALIDATE PRICE
        // -------------------------------------------------

        if (
            $price === "" ||
            !is_numeric($price)
        ) {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "A valid price is required."
            ]);

            exit;
        }


        $price = (float) $price;


        if ($price < 0) {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "Price cannot be negative."
            ]);

            exit;
        }


        // -------------------------------------------------
        // VALIDATE EMAIL
        // -------------------------------------------------

        if (
            $email !== "" &&
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "Invalid email address."
            ]);

            exit;
        }


        // -------------------------------------------------
        // VALIDATE STATUS
        // -------------------------------------------------

        $allowedStatuses = [
            "pending",
            "approved",
            "rejected",
            "inactive"
        ];


        if ($status === "") {

            $status = "pending";

        }


        if (
            !in_array(
                $status,
                $allowedStatuses,
                true
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "error" => "Invalid vendor status."
            ]);

            exit;
        }


        // -------------------------------------------------
        // UPDATE VENDOR
        // -------------------------------------------------

        $stmt = $conn->prepare(
            "UPDATE vendors
             SET
                name = ?,
                service_type = ?,
                description = ?,
                phone = ?,
                email = ?,
                price = ?,
                status = ?
             WHERE id = ?"
        );


        if (!$stmt) {

            throw new Exception(
                $conn->error
            );

        }


        $stmt->bind_param(
            "sssssdsi",
            $name,
            $service_type,
            $description,
            $phone,
            $email,
            $price,
            $status,
            $vendor_id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                $stmt->error
            );

        }


        $stmt->close();


        // -------------------------------------------------
        // SUCCESS
        // -------------------------------------------------

        echo json_encode([
            "success" => true,
            "message" => "Vendor updated successfully.",
            "vendor_id" => $vendor_id,
            "status" => $status
        ]);

        exit;
    }


} catch (Exception $error) {


    // =====================================================
    // ERROR LOG
    // =====================================================

    error_log(
        "UPDATE VENDOR ERROR: " .
        $error->getMessage()
    );


    // =====================================================
    // ERROR RESPONSE
    // =====================================================

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to update vendor."
    ]);

    exit;
}

?>