<?php

// =========================================================
// GET EVENTS - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY GET
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// FETCH EVENTS
// =========================================================

try {

    $sql = "
        SELECT
            id,
            user_id,
            title,
            event_type,
            description,
            client_name,
            client_phone,
            client_email,
            event_date,
            event_time,
            location,
            budget,
            status,
            created_at,
            updated_at
        FROM events
        ORDER BY event_date ASC, id DESC
    ";


    $result =
        $conn->query($sql);


    if (!$result) {

        throw new Exception(
            $conn->error
        );

    }


    $events = [];


    while (
        $row =
        $result->fetch_assoc()
    ) {

        $events[] = [

            "id" =>
                (int) $row["id"],

            "user_id" =>
                $row["user_id"] !== null
                    ? (int) $row["user_id"]
                    : null,

            "title" =>
                $row["title"],

            "event_type" =>
                $row["event_type"],

            "description" =>
                $row["description"],

            "client_name" =>
                $row["client_name"],

            "client_phone" =>
                $row["client_phone"],

            "client_email" =>
                $row["client_email"],

            "event_date" =>
                $row["event_date"],

            "event_time" =>
                $row["event_time"],

            "location" =>
                $row["location"],

            "budget" =>
                $row["budget"] !== null
                    ? (float) $row["budget"]
                    : 0,

            "status" =>
                $row["status"],

            "created_at" =>
                $row["created_at"],

            "updated_at" =>
                $row["updated_at"]

        ];

    }


    // =====================================================
    // STATISTICS
    // =====================================================

    $totalEvents =
        count($events);


    $upcomingEvents =
        0;


    $completedEvents =
        0;


    $cancelledEvents =
        0;


    $totalBudget =
        0;


    $today =
        date("Y-m-d");


    foreach (
        $events as $event
    ) {

        // -------------------------------------------------
        // UPCOMING
        // -------------------------------------------------

        if (
            !empty($event["event_date"]) &&
            $event["event_date"] >= $today &&
            $event["status"] !== "cancelled"
        ) {

            $upcomingEvents++;

        }


        // -------------------------------------------------
        // COMPLETED
        // -------------------------------------------------

        if (
            $event["status"] ===
            "completed"
        ) {

            $completedEvents++;

        }


        // -------------------------------------------------
        // CANCELLED
        // -------------------------------------------------

        if (
            $event["status"] ===
            "cancelled"
        ) {

            $cancelledEvents++;

        }


        // -------------------------------------------------
        // TOTAL BUDGET
        // -------------------------------------------------

        $totalBudget +=
            (float) $event["budget"];

    }


    // =====================================================
    // RESPONSE
    // =====================================================

    echo json_encode([

        "success" =>
            true,

        "events" =>
            $events,

        "statistics" => [

            "total" =>
                $totalEvents,

            "upcoming" =>
                $upcomingEvents,

            "completed" =>
                $completedEvents,

            "cancelled" =>
                $cancelledEvents,

            "total_budget" =>
                $totalBudget

        ]

    ]);

    exit;


} catch (
    Exception $error
) {

    // =====================================================
    // ERROR LOG
    // =====================================================

    error_log(
        "GET EVENTS ERROR: " .
        $error->getMessage()
    );


    // =====================================================
    // ERROR RESPONSE
    // =====================================================

    http_response_code(500);


    echo json_encode([

        "success" =>
            false,

        "error" =>
            "Unable to load events."

    ]);

    exit;

}

?>

