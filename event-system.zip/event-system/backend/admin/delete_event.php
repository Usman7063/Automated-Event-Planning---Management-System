<?php

// =========================================================
// DELETE EVENT - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// GET EVENT ID
// =========================================================

$event_id = (int) (
    $_POST["event_id"] ?? 0
);


// =========================================================
// VALIDATE EVENT ID
// =========================================================

if ($event_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Valid event ID is required."
    ]);

    exit;
}


// =========================================================
// DELETE EVENT
// =========================================================

try {

    // -----------------------------------------------------
    // CHECK EVENT EXISTS
    // -----------------------------------------------------

    $check = $conn->prepare(
        "SELECT id
         FROM events
         WHERE id = ?
         LIMIT 1"
    );


    if (!$check) {

        throw new Exception(
            $conn->error
        );

    }


    $check->bind_param(
        "i",
        $event_id
    );


    $check->execute();


    $result =
        $check->get_result();


    if (!$result->fetch_assoc()) {

        $check->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "Event not found."
        ]);

        exit;

    }


    $check->close();


    // -----------------------------------------------------
    // DELETE
    // -----------------------------------------------------

    $stmt = $conn->prepare(
        "DELETE FROM events
         WHERE id = ?"
    );


    if (!$stmt) {

        throw new Exception(
            $conn->error
        );

    }


    $stmt->bind_param(
        "i",
        $event_id
    );


    if (!$stmt->execute()) {

        throw new Exception(
            $stmt->error
        );

    }


    $stmt->close();


    // -----------------------------------------------------
    // SUCCESS
    // -----------------------------------------------------

    echo json_encode([

        "success" => true,

        "message" =>
            "Event deleted successfully.",

        "event_id" =>
            $event_id

    ]);

    exit;


} catch (Exception $error) {

    error_log(
        "DELETE EVENT ERROR: " .
        $error->getMessage()
    );


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to delete event."

    ]);

    exit;

}

?>

