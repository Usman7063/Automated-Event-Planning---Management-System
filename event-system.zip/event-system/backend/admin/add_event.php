<?php

// =========================================================
// ADD EVENT - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// GET FORM DATA
// =========================================================

$user_id = (int) (
    $_POST["user_id"] ?? 0
);

$title = trim(
    $_POST["name"] ?? ""
);

$event_type = trim(
    $_POST["event_type"] ?? ""
);

$description = trim(
    $_POST["description"] ?? ""
);

$client_name = trim(
    $_POST["client_name"] ?? ""
);

$client_phone = trim(
    $_POST["client_phone"] ?? ""
);

$client_email = trim(
    $_POST["client_email"] ?? ""
);

$event_date = trim(
    $_POST["event_date"] ?? ""
);

$event_time = trim(
    $_POST["event_time"] ?? ""
);

$location = trim(
    $_POST["location"] ?? ""
);

$budget = $_POST["price"] ?? "";

$status = trim(
    $_POST["status"] ?? "pending"
);


// =========================================================
// VALIDATE USER ID
// =========================================================

if ($user_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Valid user ID is required."
    ]);

    exit;
}


// =========================================================
// VALIDATE TITLE
// =========================================================

if ($title === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event name is required."
    ]);

    exit;
}


if (strlen($title) > 255) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event name is too long."
    ]);

    exit;
}


// =========================================================
// VALIDATE EVENT TYPE
// =========================================================

if ($event_type === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event type is required."
    ]);

    exit;
}


// =========================================================
// VALIDATE CLIENT NAME
// =========================================================

if ($client_name === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Client name is required."
    ]);

    exit;
}


// =========================================================
// VALIDATE CLIENT EMAIL
// =========================================================

if (
    $client_email !== "" &&
    !filter_var(
        $client_email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid client email address."
    ]);

    exit;
}


// =========================================================
// VALIDATE EVENT DATE
// =========================================================

if ($event_date === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event date is required."
    ]);

    exit;
}


$dateObject = DateTime::createFromFormat(
    "Y-m-d",
    $event_date
);


if (
    !$dateObject ||
    $dateObject->format("Y-m-d") !== $event_date
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid event date."
    ]);

    exit;
}


// =========================================================
// VALIDATE EVENT TIME
// =========================================================

if ($event_time !== "") {

    $timeObject = DateTime::createFromFormat(
        "H:i",
        $event_time
    );

    if (
        !$timeObject ||
        $timeObject->format("H:i") !== $event_time
    ) {

        http_response_code(400);

        echo json_encode([
            "success" => false,
            "error" => "Invalid event time."
        ]);

        exit;
    }
}


// =========================================================
// VALIDATE LOCATION
// =========================================================

if ($location === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event location is required."
    ]);

    exit;
}


if (strlen($location) > 255) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Event location is too long."
    ]);

    exit;
}


// =========================================================
// VALIDATE PRICE
// =========================================================

if (
    $budget === "" ||
    !is_numeric($budget)
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid price is required."
    ]);

    exit;
}


$budget = (float) $budget;


if ($budget < 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Price cannot be negative."
    ]);

    exit;
}


// =========================================================
// VALIDATE STATUS
// =========================================================

$allowedStatuses = [
    "pending",
    "confirmed",
    "completed",
    "cancelled"
];


if (
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid event status."
    ]);

    exit;
}


// =========================================================
// INSERT EVENT
// =========================================================

try {

    // -----------------------------------------------------
    // CHECK USER
    // -----------------------------------------------------

    $userCheck = $conn->prepare(
        "SELECT id
         FROM users
         WHERE id = ?
         LIMIT 1"
    );


    if (!$userCheck) {

        throw new Exception(
            $conn->error
        );

    }


    $userCheck->bind_param(
        "i",
        $user_id
    );


    $userCheck->execute();


    $userResult =
        $userCheck->get_result();


    if (!$userResult->fetch_assoc()) {

        $userCheck->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "User not found."
        ]);

        exit;

    }


    $userCheck->close();


    // -----------------------------------------------------
    // INSERT
    // -----------------------------------------------------

    $stmt = $conn->prepare(
        "INSERT INTO events
        (
            user_id,
            title,
            event_type,
            description,
            client_name,
            client_phone,
            client_email,
            event_date,
            event_time,
            location,
            budget,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )"
    );


    if (!$stmt) {

        throw new Exception(
            $conn->error
        );

    }


    $stmt->bind_param(
        "issssssssdss",
        $user_id,
        $title,
        $event_type,
        $description,
        $client_name,
        $client_phone,
        $client_email,
        $event_date,
        $event_time,
        $location,
        $budget,
        $status
    );


    if (!$stmt->execute()) {

        throw new Exception(
            $stmt->error
        );

    }


    $event_id =
        $stmt->insert_id;


    $stmt->close();


    // =====================================================
    // SUCCESS
    // =====================================================

    echo json_encode([

        "success" => true,

        "message" =>
            "Event added successfully.",

        "event_id" =>
            (int) $event_id

    ]);

    exit;


} catch (Exception $error) {

    error_log(
        "ADD EVENT ERROR: " .
        $error->getMessage()
    );


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to add event."

    ]);

    exit;

}

?>