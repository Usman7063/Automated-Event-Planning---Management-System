<?php

// =====================================================
// ERROR REPORTING
// =====================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// SESSION
// =====================================================

session_start();


// =====================================================
// CORS + JSON
// =====================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// OPTIONS / PREFLIGHT
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// =====================================================
// ONLY GET ALLOWED
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only GET requests are allowed."
    ]);

    exit;
}


// =====================================================
// ADMIN AUTHENTICATION
// =====================================================

if (
    empty($_SESSION['user_id']) ||
    empty($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;
}


// =====================================================
// DATABASE CONNECTION
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =====================================================
// GET USERS
// =====================================================

$result = $conn->query("
    SELECT
        id,
        full_name,
        email,
        phone,
        cnic,
        role,
        status,
        created_at,
        updated_at
    FROM users
    ORDER BY id DESC
");


// =====================================================
// QUERY ERROR
// =====================================================

if (!$result) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to retrieve users.",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;
}


// =====================================================
// BUILD USERS ARRAY
// =====================================================

$users = [];

while ($row = $result->fetch_assoc()) {

    $users[] = [

        "id" =>
            (int) $row['id'],

        "full_name" =>
            $row['full_name'],

        "email" =>
            $row['email'],

        "phone" =>
            $row['phone'],

        "cnic" =>
            $row['cnic'],

        "role" =>
            $row['role'],

        "status" =>
            $row['status'],

        "created_at" =>
            $row['created_at'],

        "updated_at" =>
            $row['updated_at']
    ];
}


// =====================================================
// CLOSE DATABASE
// =====================================================

$conn->close();


// =====================================================
// SUCCESS
// =====================================================

http_response_code(200);

echo json_encode([

    "success" => true,

    "admin_id" =>
        (int) $_SESSION['user_id'],

    "count" =>
        count($users),

    "users" =>
        $users
]);

?>