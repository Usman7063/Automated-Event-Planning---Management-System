<?php

// =========================================================
// DELETE VENDOR - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . "/admin_session.php";
require_once __DIR__ . "/../db.php";

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// VENDOR ID
// =========================================================

$vendor_id =
    (int) ($_POST["vendor_id"] ?? 0);


if ($vendor_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid vendor ID."
    ]);

    exit;
}


try {

    // -----------------------------------------------------
    // CHECK VENDOR
    // -----------------------------------------------------

    $check =
        $conn->prepare(
            "SELECT id FROM vendors WHERE id = ? LIMIT 1"
        );

    $check->bind_param(
        "i",
        $vendor_id
    );

    $check->execute();

    $result =
        $check->get_result();


    if (!$result->fetch_assoc()) {

        $check->close();

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "error" => "Vendor not found."
        ]);

        exit;
    }

    $check->close();


    // -----------------------------------------------------
    // DELETE
    // -----------------------------------------------------

    $stmt =
        $conn->prepare(
            "DELETE FROM vendors WHERE id = ?"
        );

    $stmt->bind_param(
        "i",
        $vendor_id
    );

    $stmt->execute();

    $stmt->close();


    echo json_encode([
        "success" => true,
        "message" => "Vendor deleted successfully."
    ]);


} catch (Exception $error) {

    error_log(
        "DELETE VENDOR ERROR: " .
        $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to delete vendor."
    ]);
}

?>