<?php

// =========================================================
// GET VENDORS - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// FETCH VENDORS
// =========================================================

try {

    $query = "
        SELECT
            id,
            name,
            service_type,
            description,
            phone,
            email,
            price,
            status,
            created_at
        FROM vendors
        ORDER BY id DESC
    ";


    $result = $conn->query($query);


    if (!$result) {

        throw new Exception(
            $conn->error
        );

    }


    // -----------------------------------------------------
    // VENDOR LIST
    // -----------------------------------------------------

    $vendors = [];


    while ($row = $result->fetch_assoc()) {

        $vendors[] = [

            "id" =>
                (int) $row["id"],

            "name" =>
                $row["name"],

            "service_type" =>
                $row["service_type"],

            "description" =>
                $row["description"],

            "phone" =>
                $row["phone"],

            "email" =>
                $row["email"],

            "price" =>
                (float) $row["price"],

            "status" =>
                $row["status"],

            "created_at" =>
                $row["created_at"]

        ];

    }


    // =====================================================
    // STATISTICS
    // =====================================================

    $total = count($vendors);

    $approved = 0;

    $pending = 0;

    $rejected = 0;

    $inactive = 0;


    foreach ($vendors as $vendor) {

        $status =
            strtolower(
                trim(
                    $vendor["status"] ?? ""
                )
            );


        switch ($status) {

            case "approved":

                $approved++;

                break;


            case "pending":

                $pending++;

                break;


            case "rejected":

                $rejected++;

                break;


            case "inactive":

                $inactive++;

                break;

        }

    }


    // =====================================================
    // SUCCESS RESPONSE
    // =====================================================

    echo json_encode([

        "success" => true,

        "vendors" => $vendors,

        "statistics" => [

            "total" =>
                $total,

            "approved" =>
                $approved,

            "pending" =>
                $pending,

            "rejected" =>
                $rejected,

            "inactive" =>
                $inactive

        ]

    ]);


} catch (Exception $error) {

    error_log(
        "GET VENDORS ERROR: " .
        $error->getMessage()
    );


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to load vendors."

    ]);

}

?>