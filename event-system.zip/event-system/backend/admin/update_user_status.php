<?php

// =====================================================
// ERROR REPORTING
// =====================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// SESSION
// =====================================================

session_start();


// =====================================================
// CORS + JSON
// =====================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// OPTIONS / PREFLIGHT
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// =====================================================
// ONLY POST ALLOWED
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}


// =====================================================
// ADMIN AUTHENTICATION
// =====================================================

if (
    empty($_SESSION['user_id']) ||
    empty($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Access denied. Administrator privileges are required."
    ]);

    exit;
}


// =====================================================
// DATABASE CONNECTION
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =====================================================
// READ INPUT
// =====================================================

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);

if (!is_array($data)) {
    $data = $_POST;
}


$user_id = isset($data['user_id'])
    ? (int) $data['user_id']
    : 0;

$status = trim($data['status'] ?? '');


// =====================================================
// VALIDATION
// =====================================================

if ($user_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid user ID is required."
    ]);

    $conn->close();

    exit;
}


$allowedStatuses = [
    "approved",
    "inactive",
    "rejected"
];


if (!in_array($status, $allowedStatuses, true)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Invalid status.",
        "allowed_statuses" => $allowedStatuses
    ]);

    $conn->close();

    exit;
}


// =====================================================
// PREVENT ADMIN FROM CHANGING ADMIN ACCOUNT
// =====================================================

$stmt = $conn->prepare("
    SELECT
        id,
        role,
        full_name
    FROM users
    WHERE id = ?
    LIMIT 1
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare user lookup."
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();


if ($result->num_rows === 0) {

    http_response_code(404);

    echo json_encode([
        "success" => false,
        "error" => "User not found."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


$user = $result->fetch_assoc();

$stmt->close();


// =====================================================
// CHECK TARGET ROLE
// =====================================================

if ($user['role'] === 'admin') {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "error" => "Admin accounts cannot be modified through user management."
    ]);

    $conn->close();

    exit;
}


// =====================================================
// UPDATE STATUS
// =====================================================

$stmt = $conn->prepare("
    UPDATE users
    SET
        status = ?,
        updated_at = NOW()
    WHERE id = ?
      AND role != 'admin'
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare status update."
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param(
    "si",
    $status,
    $user_id
);


if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to update user status.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =====================================================
// SUCCESS
// =====================================================

echo json_encode([

    "success" => true,

    "message" => "User status updated successfully.",

    "user" => [
        "id" => $user_id,
        "full_name" => $user['full_name'],
        "status" => $status
    ]

]);


$stmt->close();
$conn->close();

?>