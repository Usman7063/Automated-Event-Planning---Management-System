<?php

// =========================================================
// ADD VENDOR - ADMIN API
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// ADMIN SESSION
// =========================================================

require_once __DIR__ . "/admin_session.php";


// =========================================================
// DATABASE
// =========================================================

require_once __DIR__ . "/../db.php";


// =========================================================
// JSON RESPONSE
// =========================================================

header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// ONLY POST
// =========================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =========================================================
// GET INPUT
// =========================================================

$name =
    trim($_POST["name"] ?? "");

$service_type =
    trim($_POST["service_type"] ?? "");

$description =
    trim($_POST["description"] ?? "");

$phone =
    trim($_POST["phone"] ?? "");

$email =
    trim($_POST["email"] ?? "");

$price =
    $_POST["price"] ?? "";

$status =
    strtolower(
        trim(
            $_POST["status"] ?? "pending"
        )
    );


// =========================================================
// VALIDATE REQUIRED FIELDS
// =========================================================

if ($name === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Vendor name is required."
    ]);

    exit;
}


if ($service_type === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Service type is required."
    ]);

    exit;
}


if ($price === "" || !is_numeric($price)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "A valid vendor price is required."
    ]);

    exit;
}


$price = (float) $price;


if ($price < 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Price cannot be negative."
    ]);

    exit;
}


// =========================================================
// VALIDATE EMAIL
// =========================================================

if (
    $email !== "" &&
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Please enter a valid email address."
    ]);

    exit;
}


// =========================================================
// VALIDATE STATUS
// =========================================================

$allowedStatuses = [
    "pending",
    "approved",
    "rejected",
    "inactive"
];


if (
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {

    $status = "pending";

}


// =========================================================
// INSERT VENDOR
// =========================================================

try {

    $query = "
        INSERT INTO vendors
        (
            name,
            service_type,
            description,
            phone,
            email,
            price,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ";


    $stmt =
        $conn->prepare(
            $query
        );


    if (!$stmt) {

        throw new Exception(
            $conn->error
        );

    }


    $stmt->bind_param(
        "sssssds",
        $name,
        $service_type,
        $description,
        $phone,
        $email,
        $price,
        $status
    );


    if (!$stmt->execute()) {

        throw new Exception(
            $stmt->error
        );

    }


    $vendorId =
        $stmt->insert_id;


    $stmt->close();


    // =====================================================
    // SUCCESS
    // =====================================================

    echo json_encode([

        "success" => true,

        "message" =>
            "Vendor added successfully.",

        "vendor_id" =>
            (int) $vendorId

    ]);


} catch (Exception $error) {

    error_log(
        "ADD VENDOR ERROR: " .
        $error->getMessage()
    );


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            "Unable to add vendor."

    ]);

}

?>
