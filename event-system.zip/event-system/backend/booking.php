<?php

// ======================================================
// ERROR REPORTING
// ======================================================
error_reporting(E_ALL);
ini_set('display_errors', 0);


// ======================================================
// START PHP SESSION
// ======================================================
session_start();


// ======================================================
// CORS HEADERS
// ======================================================
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// ======================================================
// HANDLE PREFLIGHT
// ======================================================
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// ======================================================
// ONLY POST ALLOWED
// ======================================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;
}


// ======================================================
// CHECK LOGIN SESSION
// ======================================================
if (
    empty($_SESSION['logged_in']) ||
    empty($_SESSION['user_id'])
) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "error" => "You must be logged in to create a booking."
    ]);

    exit;
}


// ======================================================
// GET LOGGED-IN USER ID
// ======================================================
$user_id = (int) $_SESSION['user_id'];


// ======================================================
// DATABASE CONNECTION
// ======================================================
$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// ======================================================
// READ JSON OR FORM DATA
// ======================================================
$rawInput = file_get_contents("php://input");

$data = json_decode(
    $rawInput,
    true
);


// If JSON wasn't received, try normal POST
if (!is_array($data) || empty($data)) {

    $data = $_POST;
}


// ======================================================
// EXTRACT BOOKING VALUES
// ======================================================

$event_type =
    trim($data['event_type'] ?? '');

$event_date =
    trim($data['event_date'] ?? '');

$customer_name =
    trim($data['customer_name'] ?? '');

$customer_phone =
    trim($data['customer_phone'] ?? '');

$start_time =
    trim($data['start_time'] ?? '');

$end_time =
    trim($data['end_time'] ?? '');

$transport =
    trim($data['transport'] ?? '');

$payment_method =
    trim($data['payment_method'] ?? '');

$advance_payment =
    (float) ($data['advance_payment'] ?? 0);

$remaining_amount =
    (float) ($data['remaining_amount'] ?? 0);


// ======================================================
// VALIDATION
// ======================================================

if (
    $event_type === '' ||
    $event_date === '' ||
    $customer_name === '' ||
    $customer_phone === ''
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Missing required fields.",
        "received" => $data
    ]);

    $conn->close();

    exit;
}


// ======================================================
// START DATABASE TRANSACTION
// ======================================================
$conn->begin_transaction();


try {

    // ==================================================
    // 1. INSERT EVENT
    // ==================================================
    //
    // IMPORTANT:
    // Use the currently logged-in user's ID.
    //
    // This allows my_bookings.php to find
    // this event using:
    //
    // WHERE events.user_id = ?
    //
    // ==================================================

    $stmt = $conn->prepare("
        INSERT INTO events
        (
            user_id,
            title,
            event_type,
            client_name,
            client_phone,
            event_date,
            location,
            budget
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            'Not provided',
            0
        )
    ");


    if (!$stmt) {

        throw new Exception(
            "Event prepare failed: " . $conn->error
        );
    }


    $stmt->bind_param(
        "isssss",
        $user_id,
        $event_type,
        $event_type,
        $customer_name,
        $customer_phone,
        $event_date
    );


    if (!$stmt->execute()) {

        throw new Exception(
            "Event insert failed: " . $stmt->error
        );
    }


    $event_id =
        $stmt->insert_id;


    $stmt->close();


    // ==================================================
    // 2. FIND AVAILABLE VENDOR
    // ==================================================

    $result = $conn->query("
        SELECT id
        FROM vendors
        WHERE status IN ('active', 'approved')
        ORDER BY id ASC
        LIMIT 1
    ");


    if (!$result) {

        throw new Exception(
            "Vendor query failed: " . $conn->error
        );
    }


    if ($result->num_rows === 0) {

        throw new Exception(
            "No vendor found. Vendor status must be active or approved."
        );
    }


    $vendor =
        $result->fetch_assoc();


    if (!isset($vendor['id'])) {

        throw new Exception(
            "Vendor ID missing."
        );
    }


    $vendor_id =
        (int) $vendor['id'];


    // ==================================================
    // 3. INSERT INTO BOOKING TABLE
    // ==================================================

    $stmt2 = $conn->prepare("
        INSERT INTO booking
        (
            event_id,
            vendor_id,
            status,
            event_date,
            event_type,
            customer_name,
            customer_phone,
            start_time,
            end_time,
            transport,
            payment_method,
            advance_payment,
            remaining_amount
        )
        VALUES
        (
            ?,
            ?,
            'pending',
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");


    if (!$stmt2) {

        throw new Exception(
            "Booking prepare failed: " . $conn->error
        );
    }


    $stmt2->bind_param(
        "iissssssssdd",
        $event_id,
        $vendor_id,
        $event_date,
        $event_type,
        $customer_name,
        $customer_phone,
        $start_time,
        $end_time,
        $transport,
        $payment_method,
        $advance_payment,
        $remaining_amount
    );


    if (!$stmt2->execute()) {

        throw new Exception(
            "Booking insert failed: " . $stmt2->error
        );
    }


    $booking_id =
        $stmt2->insert_id;


    $stmt2->close();


    // ==================================================
    // 4. COMMIT TRANSACTION
    // ==================================================

    $conn->commit();


    // ==================================================
    // 5. SUCCESS RESPONSE
    // ==================================================

    http_response_code(200);

    echo json_encode([

        "success" => true,

        "message" =>
            "Booking created successfully.",

        "booking_id" =>
            $booking_id,

        "event_id" =>
            $event_id,

        "vendor_id" =>
            $vendor_id,

        "user_id" =>
            $user_id

    ]);


} catch (Throwable $e) {

    // ==================================================
    // ROLLBACK
    // ==================================================

    $conn->rollback();


    http_response_code(500);

    echo json_encode([

        "success" => false,

        "error" =>
            $e->getMessage()

    ]);
}


// ======================================================
// CLOSE CONNECTION
// ======================================================
$conn->close();

?>

