<?php

// ================================================================
// HASSAN TENT SERVICE
// PAYMENT BACKEND
// ================================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// ================================================================
// RESPONSE HEADERS
// ================================================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json; charset=UTF-8");


// ================================================================
// HANDLE OPTIONS REQUEST
// ================================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;

}


// ================================================================
// ONLY POST ALLOWED
// ================================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;

}


// ================================================================
// DATABASE CONNECTION
// ================================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed.",
        "details" => $conn->connect_error
    ]);

    exit;

}


$conn->set_charset("utf8mb4");


// ================================================================
// READ JSON INPUT
// ================================================================

$rawInput =
    file_get_contents("php://input");


$data =
    json_decode($rawInput, true);


// ================================================================
// FALLBACK TO POST DATA
// ================================================================

if (!is_array($data)) {

    $data = $_POST;

}


// ================================================================
// GET PAYMENT DATA
// ================================================================

// Optional booking ID.
// We do not require this because the current payment.js
// does not guarantee that one is stored in localStorage.

$booking_id =
    isset($data['booking_id']) &&
    $data['booking_id'] !== ''
        ? (int)$data['booking_id']
        : null;


// Customer information

$customer_phone =
    trim(
        $data['customer_phone'] ?? ''
    );


$customer_email =
    trim(
        $data['customer_email'] ?? ''
    );


// Payment totals

$booking_total =
    (float)(
        $data['booking_total'] ?? 0
    );


$vehicle_price =
    (float)(
        $data['vehicle_price'] ?? 0
    );


$final_total =
    (float)(
        $data['final_total'] ?? 0
    );


$advance_amount =
    (float)(
        $data['advance_amount'] ?? 0
    );


$remaining_amount =
    (float)(
        $data['remaining_amount'] ?? 0
    );


// Payment method

$payment_method =
    trim(
        $data['payment_method'] ?? ''
    );


// Contact method

$contact_method =
    trim(
        $data['contact_method'] ?? ''
    );


// Transaction ID

$transaction_id =
    trim(
        $data['transaction_id'] ?? ''
    );


// ================================================================
// NORMALIZE AMOUNTS
// ================================================================

if ($booking_total < 0) {
    $booking_total = 0;
}

if ($vehicle_price < 0) {
    $vehicle_price = 0;
}

if ($final_total < 0) {
    $final_total = 0;
}

if ($advance_amount < 0) {
    $advance_amount = 0;
}

if ($remaining_amount < 0) {
    $remaining_amount = 0;
}


// ================================================================
// VALIDATION
// ================================================================

$errors = [];


// Payment method

if ($payment_method === '') {

    $errors[] =
        "Payment method is required.";

}


// Contact method

if ($contact_method === '') {

    $errors[] =
        "Contact method is required.";

}


// Total

if ($final_total <= 0) {

    $errors[] =
        "Final payment total is invalid.";

}


// Advance cannot exceed total

if ($advance_amount > $final_total) {

    $errors[] =
        "Advance amount cannot exceed the final total.";

}


// ================================================================
// PAYMENT METHOD VALIDATION
// ================================================================

$allowedPaymentMethods = [
    "Cash",
    "JazzCash",
    "Easypaisa",
    "Bank"
];


if (
    $payment_method !== '' &&
    !in_array(
        $payment_method,
        $allowedPaymentMethods,
        true
    )
) {

    $errors[] =
        "Invalid payment method.";

}


// ================================================================
// CONTACT METHOD VALIDATION
// ================================================================

$allowedContactMethods = [
    "SMS",
    "Email"
];


if (
    $contact_method !== '' &&
    !in_array(
        $contact_method,
        $allowedContactMethods,
        true
    )
) {

    $errors[] =
        "Invalid contact method.";

}


// ================================================================
// TRANSACTION ID
// ================================================================

// Cash payments do not necessarily need a transaction ID.
//
// Online payments should normally provide one.

if (
    $payment_method !== "Cash" &&
    $transaction_id === ''
) {

    $errors[] =
        "Transaction ID is required for online payments.";

}


// ================================================================
// RETURN VALIDATION ERRORS
// ================================================================

if (!empty($errors)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Payment validation failed.",
        "details" => $errors
    ]);

    $conn->close();

    exit;

}


// ================================================================
// INSERT PAYMENT
// ================================================================

$stmt = $conn->prepare("
    INSERT INTO payments
    (
        booking_id,
        customer_phone,
        customer_email,

        booking_total,
        vehicle_price,
        final_total,

        advance_amount,
        remaining_amount,

        payment_method,
        contact_method,

        transaction_id,
        payment_status
    )
    VALUES
    (
        ?,
        ?,
        ?,

        ?,
        ?,
        ?,

        ?,
        ?,

        ?,
        ?,

        NULLIF(?, ''),
        'pending'
    )
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to prepare payment query.",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;

}


// ================================================================
// BIND PARAMETERS
// ================================================================

$stmt->bind_param(
    "issdddddsss",
    $booking_id,
    $customer_phone,
    $customer_email,

    $booking_total,
    $vehicle_price,
    $final_total,

    $advance_amount,
    $remaining_amount,

    $payment_method,
    $contact_method,
    $transaction_id
);


// ================================================================
// EXECUTE
// ================================================================

if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to save payment.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();

    exit;

}


// ================================================================
// PAYMENT ID
// ================================================================

$payment_id =
    $stmt->insert_id;


// ================================================================
// SUCCESS
// ================================================================

echo json_encode([
    "success" => true,

    "message" =>
        "Payment details submitted successfully.",

    "payment_id" =>
        $payment_id,

    "booking_id" =>
        $booking_id,

    "payment_method" =>
        $payment_method,

    "contact_method" =>
        $contact_method,

    "final_total" =>
        $final_total,

    "advance_amount" =>
        $advance_amount,

    "remaining_amount" =>
        $remaining_amount,

    "payment_status" =>
        "pending"
]);


// ================================================================
// CLOSE
// ================================================================

$stmt->close();
$conn->close();

?>

