<?php

// =========================================================
// ERROR REPORTING
// =========================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =========================================================
// START SESSION
// =========================================================

session_start();


// =========================================================
// CORS + JSON
// =========================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =========================================================
// OPTIONS
// =========================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// =========================================================
// ONLY GET
// =========================================================

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only GET requests are allowed."
    ]);

    exit;
}


// =========================================================
// CHECK LOGIN
// =========================================================

if (
    empty($_SESSION['logged_in']) ||
    empty($_SESSION['user_id'])
) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "error" => "You must be logged in to view your bookings."
    ]);

    exit;
}


$user_id = (int) $_SESSION['user_id'];


// =========================================================
// DATABASE
// =========================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =========================================================
// FETCH ALL THREE BOOKING TYPES
//
// booking
// booking1
// booking2
//
// All three are connected to:
//
// booking.event_id
//        ↓
// events.id
//        ↓
// events.user_id
//
// Therefore only bookings belonging to the
// currently logged-in user are returned.
// =========================================================


// =========================================================
// 1. BOOKING TABLE
// =========================================================

$bookingSql = "
    SELECT

        booking.id AS booking_id,
        booking.event_id,
        booking.vendor_id,
        booking.status,
        booking.event_date,
        booking.event_type,
        booking.customer_name,
        booking.customer_phone,

        events.title AS event_title,
        events.location AS event_location,
        events.budget AS event_budget

    FROM booking

    INNER JOIN events
        ON booking.event_id = events.id

    WHERE events.user_id = ?

    ORDER BY booking.id DESC
";


$stmt = $conn->prepare($bookingSql);


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare booking query.",
        "details" => $conn->error
    ]);

    $conn->close();
    exit;
}


$stmt->bind_param(
    "i",
    $user_id
);


if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to retrieve booking records.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();
    exit;
}


$result = $stmt->get_result();


$bookings = [];

while ($row = $result->fetch_assoc()) {

    $bookings[] = [

        "booking_id" =>
            (int) $row['booking_id'],

        "event_id" =>
            (int) $row['event_id'],

        "vendor_id" =>
            (int) $row['vendor_id'],

        "booking_type" =>
            "booking",

        "service_type" =>
            "General Event Booking",

        "status" =>
            $row['status'],

        "customer_name" =>
            $row['customer_name'],

        "customer_phone" =>
            $row['customer_phone'],

        "email" =>
            null,

        "cnic" =>
            null,

        "event_title" =>
            $row['event_title'],

        "event_type" =>
            $row['event_type'],

        "event_date" =>
            $row['event_date'],

        "start_time" =>
            null,

        "end_time" =>
            null,

        "guests" =>
            null,

        "city" =>
            null,

        "area" =>
            null,

        "address" =>
            null,

        "event_location" =>
            $row['event_location'],

        "package_name" =>
            null,

        "package_price" =>
            0,

        "extra_price" =>
            0,

        "vehicle" =>
            null,

        "vehicle_price" =>
            0,

        "generator" =>
            null,

        "generator_price" =>
            0,

        "grand_total" =>
            (float) $row['event_budget'],

        "advance_payment" =>
            0,

        "remaining_amount" =>
            (float) $row['event_budget'],

        "payment_method" =>
            null,

        "confirm_via" =>
            null,

        "notes" =>
            null
    ];
}


$stmt->close();


// =========================================================
// 2. BOOKING1 TABLE
// =========================================================

$booking1Sql = "
    SELECT

        booking1.id AS booking_id,
        booking1.event_id,
        booking1.vendor_id,
        booking1.status,
        booking1.event_date,
        booking1.event_type,
        booking1.customer_name,
        booking1.customer_phone,
        booking1.start_time,
        booking1.end_time,
        booking1.transport,
        booking1.payment_method,

        events.title AS event_title,
        events.location AS event_location,
        events.budget AS event_budget

    FROM booking1

    INNER JOIN events
        ON booking1.event_id = events.id

    WHERE events.user_id = ?

    ORDER BY booking1.id DESC
";


$stmt = $conn->prepare($booking1Sql);


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare booking1 query.",
        "details" => $conn->error
    ]);

    $conn->close();
    exit;
}


$stmt->bind_param(
    "i",
    $user_id
);


if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to retrieve booking1 records.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();
    exit;
}


$result = $stmt->get_result();


while ($row = $result->fetch_assoc()) {

    $bookings[] = [

        "booking_id" =>
            (int) $row['booking_id'],

        "event_id" =>
            (int) $row['event_id'],

        "vendor_id" =>
            (int) $row['vendor_id'],

        "booking_type" =>
            "booking1",

        "service_type" =>
            "Transport",

        "status" =>
            $row['status'],

        "customer_name" =>
            $row['customer_name'],

        "customer_phone" =>
            $row['customer_phone'],

        "email" =>
            null,

        "cnic" =>
            null,

        "event_title" =>
            $row['event_title'],

        "event_type" =>
            $row['event_type'],

        "event_date" =>
            $row['event_date'],

        "start_time" =>
            $row['start_time'],

        "end_time" =>
            $row['end_time'],

        "guests" =>
            null,

        "city" =>
            null,

        "area" =>
            null,

        "address" =>
            null,

        "event_location" =>
            $row['event_location'],

        "package_name" =>
            null,

        "package_price" =>
            0,

        "extra_price" =>
            0,

        "vehicle" =>
            $row['transport'],

        "vehicle_price" =>
            0,

        "generator" =>
            null,

        "generator_price" =>
            0,

        "grand_total" =>
            (float) $row['event_budget'],

        "advance_payment" =>
            0,

        "remaining_amount" =>
            (float) $row['event_budget'],

        "payment_method" =>
            $row['payment_method'],

        "confirm_via" =>
            null,

        "notes" =>
            null
    ];
}


$stmt->close();


// =========================================================
// 3. BOOKING2 TABLE
// =========================================================

$booking2Sql = "
    SELECT

        booking2.id AS booking_id,
        booking2.event_id,
        booking2.vendor_id,
        booking2.status,
        booking2.service_type,

        booking2.customer_name,
        booking2.customer_phone,
        booking2.email,
        booking2.cnic,

        booking2.event_type,
        booking2.event_date,
        booking2.start_time,
        booking2.end_time,
        booking2.guests,

        booking2.city,
        booking2.area,
        booking2.address,

        booking2.package_name,
        booking2.package_price,
        booking2.extra_price,

        booking2.vehicle,
        booking2.vehicle_price,

        booking2.generator,
        booking2.generator_price,

        booking2.grand_total,
        booking2.advance_payment,
        booking2.remaining_amount,

        booking2.payment_method,
        booking2.confirm_via,
        booking2.notes,

        events.title AS event_title,
        events.location AS event_location,
        events.budget AS event_budget

    FROM booking2

    INNER JOIN events
        ON booking2.event_id = events.id

    WHERE events.user_id = ?

    ORDER BY booking2.id DESC
";


$stmt = $conn->prepare($booking2Sql);


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to prepare booking2 query.",
        "details" => $conn->error
    ]);

    $conn->close();
    exit;
}


$stmt->bind_param(
    "i",
    $user_id
);


if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Unable to retrieve booking2 records.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();
    exit;
}


$result = $stmt->get_result();


while ($row = $result->fetch_assoc()) {

    $bookings[] = [

        "booking_id" =>
            (int) $row['booking_id'],

        "event_id" =>
            (int) $row['event_id'],

        "vendor_id" =>
            (int) $row['vendor_id'],

        "booking_type" =>
            "booking2",

        "service_type" =>
            $row['service_type'],

        "status" =>
            $row['status'],

        "customer_name" =>
            $row['customer_name'],

        "customer_phone" =>
            $row['customer_phone'],

        "email" =>
            $row['email'],

        "cnic" =>
            $row['cnic'],

        "event_title" =>
            $row['event_title'],

        "event_type" =>
            $row['event_type'],

        "event_date" =>
            $row['event_date'],

        "start_time" =>
            $row['start_time'],

        "end_time" =>
            $row['end_time'],

        "guests" =>
            $row['guests'] !== null
                ? (int) $row['guests']
                : null,

        "city" =>
            $row['city'],

        "area" =>
            $row['area'],

        "address" =>
            $row['address'],

        "event_location" =>
            $row['event_location'],

        "package_name" =>
            $row['package_name'],

        "package_price" =>
            (float) $row['package_price'],

        "extra_price" =>
            (float) $row['extra_price'],

        "vehicle" =>
            $row['vehicle'],

        "vehicle_price" =>
            (float) $row['vehicle_price'],

        "generator" =>
            $row['generator'],

        "generator_price" =>
            (float) $row['generator_price'],

        "grand_total" =>
            (float) $row['grand_total'],

        "advance_payment" =>
            (float) $row['advance_payment'],

        "remaining_amount" =>
            (float) $row['remaining_amount'],

        "payment_method" =>
            $row['payment_method'],

        "confirm_via" =>
            $row['confirm_via'],

        "notes" =>
            $row['notes']
    ];
}


$stmt->close();


// =========================================================
// SORT ALL BOOKINGS BY EVENT ID
// =========================================================

usort(
    $bookings,
    function ($a, $b) {

        return $b['event_id'] <=> $a['event_id'];

    }
);


// =========================================================
// CLOSE DATABASE
// =========================================================

$conn->close();


// =========================================================
// SUCCESS RESPONSE
// =========================================================

http_response_code(200);

echo json_encode([

    "success" => true,

    "user_id" =>
        $user_id,

    "count" =>
        count($bookings),

    "bookings" =>
        $bookings

]);

?>

