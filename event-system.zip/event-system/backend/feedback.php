<?php

// ================================================================
// FEEDBACK BACKEND
// ================================================================

error_reporting(E_ALL);
ini_set('display_errors', 0);


// ================================================================
// RESPONSE HEADERS
// ================================================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json; charset=UTF-8");


// ================================================================
// HANDLE PREFLIGHT REQUEST
// ================================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;

}


// ================================================================
// ONLY ALLOW POST
// ================================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "error" => "Only POST requests are allowed."
    ]);

    exit;

}


// ================================================================
// DATABASE CONNECTION
// ================================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed.",
        "details" => $conn->connect_error
    ]);

    exit;

}


$conn->set_charset("utf8mb4");


// ================================================================
// READ JSON INPUT
// ================================================================

$rawInput =
    file_get_contents("php://input");


$data =
    json_decode($rawInput, true);


// ================================================================
// FALLBACK TO FORM DATA
// ================================================================

if (!is_array($data)) {

    $data = $_POST;

}


// ================================================================
// GET FORM VALUES
// ================================================================

$name =
    trim($data['name'] ?? $data['fullName'] ?? '');

$event_type =
    trim($data['event_type'] ?? $data['eventType'] ?? '');

$rating =
    (int)($data['rating'] ?? 0);

$message =
    trim($data['message'] ?? $data['feedbackMessage'] ?? '');


// ================================================================
// VALIDATION
// ================================================================

$errors = [];


// Name
if ($name === '') {

    $errors[] = "Name is required.";

}


// Event type
if ($event_type === '') {

    $errors[] = "Event type is required.";

}


// Rating
if ($rating < 1 || $rating > 5) {

    $errors[] =
        "Rating must be between 1 and 5.";

}


// Message
if ($message === '') {

    $errors[] = "Feedback message is required.";

}


// ================================================================
// RETURN VALIDATION ERRORS
// ================================================================

if (!empty($errors)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Validation failed.",
        "details" => $errors
    ]);

    $conn->close();

    exit;

}


// ================================================================
// INSERT FEEDBACK
// ================================================================

$stmt = $conn->prepare("
    INSERT INTO feedback
    (
        name,
        event_type,
        rating,
        message
    )
    VALUES
    (
        ?,
        ?,
        ?,
        ?
    )
");


if (!$stmt) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to prepare feedback query.",
        "details" => $conn->error
    ]);

    $conn->close();

    exit;

}


// ================================================================
// BIND PARAMETERS
// ================================================================

$stmt->bind_param(
    "ssis",
    $name,
    $event_type,
    $rating,
    $message
);


// ================================================================
// EXECUTE
// ================================================================

if (!$stmt->execute()) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Failed to save feedback.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();

    exit;

}


// ================================================================
// GET NEW FEEDBACK ID
// ================================================================

$feedback_id =
    $stmt->insert_id;


// ================================================================
// SUCCESS RESPONSE
// ================================================================

echo json_encode([
    "success" => true,
    "message" => "Feedback submitted successfully.",
    "feedback_id" => $feedback_id,

    "feedback" => [
        "name" => $name,
        "event_type" => $event_type,
        "rating" => $rating,
        "message" => $message
    ]
]);


// ================================================================
// CLOSE CONNECTION
// ================================================================

$stmt->close();
$conn->close();

?>

