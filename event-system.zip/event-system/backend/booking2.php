<?php


/* =========================================================
   ERROR REPORTING
   ========================================================= */

error_reporting(E_ALL);
ini_set('display_errors', 1);


/* =========================================================
   START PHP SESSION
   ========================================================= */

session_start();


/* =========================================================
   CORS + JSON HEADERS
   ========================================================= */

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


/* =========================================================
   HANDLE OPTIONS / PREFLIGHT REQUEST
   ========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);

    exit;
}


/* =========================================================
   CHECK LOGIN SESSION
   ========================================================= */

if (
    empty($_SESSION['logged_in']) ||
    empty($_SESSION['user_id'])
) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "error" => "You must be logged in to create a booking."
    ]);

    exit;
}


$user_id = (int)$_SESSION['user_id'];


/* =========================================================
   DATABASE CONNECTION
   ========================================================= */

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed",
        "details" => $conn->connect_error
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


/* =========================================================
   READ INPUT
   ========================================================= */

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);


/*
 * If JSON was not supplied, try normal POST data.
 */

if (!is_array($data) || empty($data)) {

    $data = $_POST;
}


/* =========================================================
   BASIC CUSTOMER INFORMATION
   ========================================================= */

$customer_name = trim(
    $data['customer_name'] ?? ''
);

$customer_phone = trim(
    $data['customer_phone'] ?? ''
);

$email = trim(
    $data['email'] ?? ''
);

$cnic = trim(
    $data['cnic'] ?? ''
);


/* =========================================================
   EVENT INFORMATION
   ========================================================= */

$event_type = trim(
    $data['event_type'] ?? ''
);

$event_date = trim(
    $data['event_date'] ?? ''
);

$start_time = trim(
    $data['start_time'] ?? ''
);

$end_time = trim(
    $data['end_time'] ?? ''
);

$guests = (int)(
    $data['guests'] ?? 0
);


/* =========================================================
   LOCATION INFORMATION
   ========================================================= */

$city = trim(
    $data['city'] ?? ''
);

$area = trim(
    $data['area'] ?? ''
);

$address = trim(
    $data['address'] ?? ''
);


/* =========================================================
   SERVICE INFORMATION
   ========================================================= */

$service_type = trim(
    $data['service_type'] ?? ''
);


/*
 * Compatibility with older frontend field names.
 */

if ($service_type === '') {

    if (!empty($data['service'])) {

        $service_type = trim(
            $data['service']
        );

    } elseif (!empty($data['catalog'])) {

        $service_type = trim(
            $data['catalog']
        );
    }
}


$package_name = trim(
    $data['package_name'] ?? ''
);

$package_price = (float)(
    $data['package_price'] ?? 0
);

$extra_price = (float)(
    $data['extra_price'] ?? 0
);


/* =========================================================
   VEHICLE
   ========================================================= */

$vehicle = trim(
    $data['vehicle'] ?? 'None'
);

$vehicle_price = (float)(
    $data['vehicle_price'] ?? 0
);


/*
 * Default vehicle prices.
 */

if ($vehicle_price <= 0) {

    if ($vehicle === 'Suzuki Pickup') {

        $vehicle_price = 3000;

    } elseif ($vehicle === 'Jeep') {

        $vehicle_price = 5000;

    } else {

        $vehicle_price = 0;
    }
}


/* =========================================================
   GENERATOR
   ========================================================= */

$generator = trim(
    $data['generator'] ?? 'No'
);

$generator_price = (float)(
    $data['generator_price'] ?? 0
);


/*
 * Default generator price.
 */

if (
    $generator_price <= 0 &&
    $generator === 'Yes'
) {

    $generator_price = 4000;
}


/* =========================================================
   PAYMENT INFORMATION
   ========================================================= */

$advance_payment = (float)(
    $data['advance_payment'] ?? 0
);


if ($advance_payment < 0) {

    $advance_payment = 0;
}


$payment_method = trim(
    $data['payment_method'] ?? 'Not selected'
);


$confirm_via = trim(
    $data['confirm_via'] ?? ''
);


/* =========================================================
   NOTES
   ========================================================= */

$notes = trim(
    $data['notes'] ?? ''
);


/* =========================================================
   CALCULATE TOTAL
   ========================================================= */

$grand_total =
    $package_price +
    $extra_price +
    $vehicle_price +
    $generator_price;


$remaining_amount =
    max(
        0,
        $grand_total - $advance_payment
    );


/* =========================================================
   REQUIRED FIELD VALIDATION
   ========================================================= */

if (
    $customer_name === '' ||
    $customer_phone === '' ||
    $event_type === '' ||
    $event_date === '' ||
    $package_name === '' ||
    $payment_method === '' ||
    $confirm_via === ''
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "error" => "Missing required fields",
        "received" => $data
    ]);

    $conn->close();

    exit;
}


/* =========================================================
   START DATABASE TRANSACTION
   ========================================================= */

$conn->begin_transaction();


try {


    /* =====================================================
       CREATE EVENT
       ===================================================== */

    $stmt = $conn->prepare("
        INSERT INTO events
        (
            user_id,
            title,
            event_date,
            location,
            budget
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");


    if (!$stmt) {

        throw new Exception(
            "Event prepare failed: " . $conn->error
        );
    }


    /*
     * Build event location.
     */

    $event_location = $city;


    if ($area !== '') {

        $event_location .=
            ($event_location !== '' ? ', ' : '') .
            $area;
    }


    $event_budget = $grand_total;


    /*
     * Event parameters:
     *
     * user_id     = integer
     * title       = string
     * event_date  = string
     * location    = string
     * budget      = double
     */

    $stmt->bind_param(
        "isssd",
        $user_id,
        $event_type,
        $event_date,
        $event_location,
        $event_budget
    );


    if (!$stmt->execute()) {

        throw new Exception(
            "Event insert failed: " .
            $stmt->error
        );
    }


    $event_id = $stmt->insert_id;


    $stmt->close();


    /* =====================================================
       FIND ACTIVE / APPROVED VENDOR
       ===================================================== */

    $result = $conn->query("
        SELECT id
        FROM vendors
        WHERE status IN ('active', 'approved')
        ORDER BY id ASC
        LIMIT 1
    ");


    if (!$result) {

        throw new Exception(
            "Vendor query failed: " .
            $conn->error
        );
    }


    if ($result->num_rows === 0) {

        throw new Exception(
            "No active or approved vendor found."
        );
    }


    $vendor = $result->fetch_assoc();


    if (!isset($vendor['id'])) {

        throw new Exception(
            "Vendor ID not found."
        );
    }


    $vendor_id = (int)$vendor['id'];


    /* =====================================================
       INSERT BOOKING2
       ===================================================== */

    $stmt2 = $conn->prepare("
        INSERT INTO booking2
        (
            event_id,
            vendor_id,
            status,
            service_type,

            customer_name,
            customer_phone,
            email,
            cnic,

            event_type,
            event_date,
            start_time,
            end_time,
            guests,

            city,
            area,
            address,

            package_name,
            package_price,
            extra_price,

            vehicle,
            vehicle_price,

            generator,
            generator_price,

            grand_total,
            advance_payment,
            remaining_amount,

            payment_method,
            confirm_via,

            notes
        )
        VALUES
        (
            ?,
            ?,
            'pending',
            ?,

            ?,
            ?,
            ?,
            ?,

            ?,
            ?,
            NULLIF(?, ''),
            NULLIF(?, ''),
            ?,

            ?,
            ?,
            ?,

            ?,
            ?,
            ?,

            ?,
            ?,

            ?,
            ?,

            ?,
            ?,
            ?,

            ?,
            ?,

            ?
        )
    ");


    if (!$stmt2) {

        throw new Exception(
            "Booking2 prepare failed: " .
            $conn->error
        );
    }


    /*
     * 28 parameters:
     *
     * 1  event_id
     * 2  vendor_id
     * 3  service_type
     * 4  customer_name
     * 5  customer_phone
     * 6  email
     * 7  cnic
     * 8  event_type
     * 9  event_date
     * 10 start_time
     * 11 end_time
     * 12 guests
     * 13 city
     * 14 area
     * 15 address
     * 16 package_name
     * 17 package_price
     * 18 extra_price
     * 19 vehicle
     * 20 vehicle_price
     * 21 generator
     * 22 generator_price
     * 23 grand_total
     * 24 advance_payment
     * 25 remaining_amount
     * 26 payment_method
     * 27 confirm_via
     * 28 notes
     */

    $stmt2->bind_param(
        "iisssssssssissssddsdsddddsss",

        $event_id,
        $vendor_id,
        $service_type,

        $customer_name,
        $customer_phone,
        $email,
        $cnic,

        $event_type,
        $event_date,
        $start_time,
        $end_time,
        $guests,

        $city,
        $area,
        $address,

        $package_name,
        $package_price,
        $extra_price,

        $vehicle,
        $vehicle_price,

        $generator,
        $generator_price,

        $grand_total,
        $advance_payment,
        $remaining_amount,

        $payment_method,
        $confirm_via,

        $notes
    );


    /* =====================================================
       EXECUTE BOOKING INSERT
       ===================================================== */

    if (!$stmt2->execute()) {

        throw new Exception(
            "Booking2 insert failed: " .
            $stmt2->error
        );
    }


    $booking2_id =
        $stmt2->insert_id;


    $stmt2->close();


    /* =====================================================
       COMMIT TRANSACTION
       ===================================================== */

    $conn->commit();


    /* =====================================================
       SUCCESS RESPONSE
       ===================================================== */

    http_response_code(200);


    echo json_encode([

        "success" => true,

        "message" =>
            "Sound/Lighting booking created successfully",

        "booking2_id" =>
            $booking2_id,

        "event_id" =>
            $event_id,

        "vendor_id" =>
            $vendor_id,

        "user_id" =>
            $user_id,

        "service_type" =>
            $service_type,

        "package_name" =>
            $package_name,

        "package_price" =>
            $package_price,

        "extra_price" =>
            $extra_price,

        "vehicle_price" =>
            $vehicle_price,

        "generator_price" =>
            $generator_price,

        "grand_total" =>
            $grand_total,

        "advance_payment" =>
            $advance_payment,

        "remaining_amount" =>
            $remaining_amount
    ]);


} catch (Throwable $e) {


    /* =====================================================
       ROLLBACK
       ===================================================== */

    $conn->rollback();


    http_response_code(500);


    echo json_encode([

        "success" => false,

        "error" =>
            $e->getMessage(),

        "file" =>
            basename($e->getFile()),

        "line" =>
            $e->getLine()
    ]);
}


/* =========================================================
   CLOSE CONNECTION
   ========================================================= */

$conn->close();

?>