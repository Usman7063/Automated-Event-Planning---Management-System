<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);


// =====================================================
// START PHP SESSION
// =====================================================

session_start();


// =====================================================
// CORS
// =====================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// OPTIONS
// =====================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);
    exit;
}


// =====================================================
// ONLY POST
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);

    exit;
}


// =====================================================
// DATABASE
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// =====================================================
// INPUT
// =====================================================

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);


if (!is_array($data)) {
    $data = $_POST;
}


$email = trim(
    $data['email'] ?? ''
);

$password =
    $data['password'] ?? '';


// =====================================================
// VALIDATION
// =====================================================

if ($email === '' || $password === '') {

    echo json_encode([
        "success" => false,
        "error" => "Email and password are required."
    ]);

    $conn->close();

    exit;
}


// =====================================================
// FIND USER
// =====================================================

$stmt = $conn->prepare("
    SELECT
        id,
        full_name,
        email,
        phone,
        cnic,
        password,
        role,
        status
    FROM users
    WHERE email = ?
    LIMIT 1
");


if (!$stmt) {

    echo json_encode([
        "success" => false,
        "error" => "Database query preparation failed."
    ]);

    $conn->close();

    exit;
}


$stmt->bind_param(
    "s",
    $email
);


if (!$stmt->execute()) {

    echo json_encode([
        "success" => false,
        "error" => "Database query failed."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


$result = $stmt->get_result();


// =====================================================
// USER NOT FOUND
// =====================================================

if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "error" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


$user = $result->fetch_assoc();


// =====================================================
// CHECK PASSWORD
// =====================================================

if (!password_verify(
    $password,
    $user['password']
)) {

    echo json_encode([
        "success" => false,
        "error" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =====================================================
// CHECK ACCOUNT STATUS
// =====================================================

if (
    $user['status'] === 'rejected' ||
    $user['status'] === 'inactive'
) {

    echo json_encode([
        "success" => false,
        "error" => "Your account is currently inactive or rejected."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


// =====================================================
// REGENERATE SESSION ID
// =====================================================

session_regenerate_id(true);


// =====================================================
// STORE USER IN PHP SESSION
// =====================================================

$_SESSION['user_id'] =
    (int) $user['id'];

$_SESSION['full_name'] =
    $user['full_name'];

$_SESSION['email'] =
    $user['email'];

$_SESSION['phone'] =
    $user['phone'];

$_SESSION['cnic'] =
    $user['cnic'];

$_SESSION['role'] =
    $user['role'];

$_SESSION['logged_in'] =
    true;


// =====================================================
// REMOVE PASSWORD FROM RESPONSE
// =====================================================

unset(
    $user['password']
);


// =====================================================
// SUCCESS
// =====================================================

echo json_encode([

    "success" => true,

    "message" =>
        "Login successful.",

    "user" => [

        "id" =>
            (int) $user['id'],

        "full_name" =>
            $user['full_name'],

        "email" =>
            $user['email'],

        "phone" =>
            $user['phone'],

        "cnic" =>
            $user['cnic'],

        "role" =>
            $user['role']

    ]

]);


$stmt->close();

$conn->close();

?>