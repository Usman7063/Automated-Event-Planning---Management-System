<?php

session_start();


// ============================================================
// CORS
// ============================================================

header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


// ============================================================
// OPTIONS
// ============================================================

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {

    http_response_code(200);

    exit;
}


// ============================================================
// CHECK LOGIN
// ============================================================

if (
    empty($_SESSION['logged_in']) ||
    empty($_SESSION['user_id'])
) {

    echo json_encode([
        "success" => false,
        "error" => "You must be logged in."
    ]);

    exit;
}


$user_id = (int) $_SESSION['user_id'];


// ============================================================
// DATABASE
// ============================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);


if ($conn->connect_error) {

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed."
    ]);

    exit;
}


$conn->set_charset("utf8mb4");


// ============================================================
// GET PROFILE
// ============================================================

if ($_SERVER['REQUEST_METHOD'] === 'GET') {


    $stmt = $conn->prepare("
        SELECT
            id,
            full_name,
            email,
            phone,
            cnic,
            role,
            status,
            created_at
        FROM users
        WHERE id = ?
        LIMIT 1
    ");


    if (!$stmt) {

        echo json_encode([
            "success" => false,
            "error" => "Database query failed."
        ]);

        $conn->close();

        exit;
    }


    $stmt->bind_param(
        "i",
        $user_id
    );


    $stmt->execute();


    $result = $stmt->get_result();


    if ($result->num_rows === 0) {

        echo json_encode([
            "success" => false,
            "error" => "User account not found."
        ]);

        $stmt->close();

        $conn->close();

        exit;
    }


    $user = $result->fetch_assoc();


    echo json_encode([

        "success" => true,

        "user" => [

            "id" =>
                (int) $user['id'],

            "full_name" =>
                $user['full_name'],

            "email" =>
                $user['email'],

            "phone" =>
                $user['phone'],

            "cnic" =>
                $user['cnic'],

            "role" =>
                $user['role'],

            "status" =>
                $user['status'],

            "created_at" =>
                $user['created_at']

        ]

    ]);


    $stmt->close();

    $conn->close();

    exit;
}


// ============================================================
// UPDATE PROFILE
// ============================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    $data = json_decode(
        file_get_contents("php://input"),
        true
    );


    if (!is_array($data)) {

        echo json_encode([
            "success" => false,
            "error" => "Invalid request data."
        ]);

        $conn->close();

        exit;
    }


    $full_name =
        trim($data['full_name'] ?? '');

    $email =
        trim($data['email'] ?? '');

    $phone =
        trim($data['phone'] ?? '');

    $cnic =
        trim($data['cnic'] ?? '');


    // --------------------------------------------------------
    // Validation
    // --------------------------------------------------------

    if (
        $full_name === '' ||
        $email === '' ||
        $phone === ''
    ) {

        echo json_encode([
            "success" => false,
            "error" => "Name, email and phone are required."
        ]);

        $conn->close();

        exit;
    }


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        echo json_encode([
            "success" => false,
            "error" => "Please enter a valid email address."
        ]);

        $conn->close();

        exit;
    }


    // --------------------------------------------------------
    // Check if email belongs to another account
    // --------------------------------------------------------

    $emailCheck = $conn->prepare("
        SELECT id
        FROM users
        WHERE email = ?
        AND id != ?
        LIMIT 1
    ");


    $emailCheck->bind_param(
        "si",
        $email,
        $user_id
    );


    $emailCheck->execute();


    $emailResult =
        $emailCheck->get_result();


    if ($emailResult->num_rows > 0) {

        echo json_encode([
            "success" => false,
            "error" => "This email address is already being used."
        ]);

        $emailCheck->close();

        $conn->close();

        exit;
    }


    $emailCheck->close();


    // --------------------------------------------------------
    // Update user
    // --------------------------------------------------------

    $stmt = $conn->prepare("
        UPDATE users
        SET
            full_name = ?,
            email = ?,
            phone = ?,
            cnic = ?
        WHERE id = ?
    ");


    if (!$stmt) {

        echo json_encode([
            "success" => false,
            "error" => "Unable to prepare profile update."
        ]);

        $conn->close();

        exit;
    }


    $stmt->bind_param(
        "ssssi",
        $full_name,
        $email,
        $phone,
        $cnic,
        $user_id
    );


    if (!$stmt->execute()) {

        echo json_encode([
            "success" => false,
            "error" => "Profile update failed.",
            "details" => $stmt->error
        ]);

        $stmt->close();

        $conn->close();

        exit;
    }


    // --------------------------------------------------------
    // Update PHP session
    // --------------------------------------------------------

    $_SESSION['full_name'] =
        $full_name;

    $_SESSION['email'] =
        $email;

    $_SESSION['phone'] =
        $phone;

    $_SESSION['cnic'] =
        $cnic;


    // --------------------------------------------------------
    // Return updated user
    // --------------------------------------------------------

    echo json_encode([

        "success" => true,

        "message" =>
            "Profile updated successfully.",

        "user" => [

            "id" =>
                $user_id,

            "full_name" =>
                $full_name,

            "email" =>
                $email,

            "phone" =>
                $phone,

            "cnic" =>
                $cnic,

            "role" =>
                $_SESSION['role'] ?? 'user'

        ]

    ]);


    $stmt->close();

    $conn->close();

    exit;
}


// ============================================================
// INVALID METHOD
// ============================================================

echo json_encode([
    "success" => false,
    "error" => "Invalid request method."
]);


$conn->close();

?>