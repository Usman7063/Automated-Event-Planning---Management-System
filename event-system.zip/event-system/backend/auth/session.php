<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

if (isset($_SESSION['user_id'])) {

    echo json_encode([
        "logged_in" => true,

        "user" => [
            "id" => $_SESSION['user_id'],
            "full_name" => $_SESSION['full_name'],
            "email" => $_SESSION['email'],
            "phone" => $_SESSION['phone'],
            "cnic" => $_SESSION['cnic'],
            "role" => $_SESSION['role']
        ]
    ]);

} else {

    echo json_encode([
        "logged_in" => false
    ]);
}

?>