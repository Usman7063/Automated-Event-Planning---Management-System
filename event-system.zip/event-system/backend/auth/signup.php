<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Accept");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);
    exit;
}


// =====================================================
// DATABASE
// =====================================================

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "event_system"
);

if ($conn->connect_error) {

    echo json_encode([
        "success" => false,
        "error" => "Database connection failed.",
        "details" => $conn->connect_error
    ]);

    exit;
}

$conn->set_charset("utf8mb4");


// =====================================================
// READ INPUT
// =====================================================

$rawInput = file_get_contents("php://input");

$data = json_decode($rawInput, true);

if (!is_array($data)) {
    $data = $_POST;
}


// =====================================================
// GET VALUES
// =====================================================

$full_name = trim($data['full_name'] ?? '');
$email     = trim($data['email'] ?? '');
$phone     = trim($data['phone'] ?? '');
$cnic      = trim($data['cnic'] ?? '');
$password  = $data['password'] ?? '';


// =====================================================
// VALIDATION
// =====================================================

if (
    $full_name === '' ||
    $email === '' ||
    $phone === '' ||
    $password === ''
) {

    echo json_encode([
        "success" => false,
        "error" => "Please fill all required fields."
    ]);

    $conn->close();
    exit;
}


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    echo json_encode([
        "success" => false,
        "error" => "Please enter a valid email address."
    ]);

    $conn->close();
    exit;
}


if (strlen($password) < 6) {

    echo json_encode([
        "success" => false,
        "error" => "Password must contain at least 6 characters."
    ]);

    $conn->close();
    exit;
}


// =====================================================
// CHECK EXISTING EMAIL
// =====================================================

$check = $conn->prepare("
    SELECT id
    FROM users
    WHERE email = ?
    LIMIT 1
");

$check->bind_param("s", $email);
$check->execute();

$result = $check->get_result();

if ($result->num_rows > 0) {

    $check->close();
    $conn->close();

    echo json_encode([
        "success" => false,
        "error" => "An account with this email already exists."
    ]);

    exit;
}

$check->close();


// =====================================================
// HASH PASSWORD
// =====================================================

$password_hash = password_hash(
    $password,
    PASSWORD_DEFAULT
);


// =====================================================
// CREATE USER
// =====================================================

$stmt = $conn->prepare("
    INSERT INTO users
    (
        full_name,
        email,
        phone,
        cnic,
        password,
        role,
        status
    )
    VALUES
    (
        ?,
        ?,
        ?,
        ?,
        ?,
        'user',
        'approved'
    )
");

if (!$stmt) {

    echo json_encode([
        "success" => false,
        "error" => "Failed to prepare signup query.",
        "details" => $conn->error
    ]);

    $conn->close();
    exit;
}


$stmt->bind_param(
    "sssss",
    $full_name,
    $email,
    $phone,
    $cnic,
    $password_hash
);


if (!$stmt->execute()) {

    echo json_encode([
        "success" => false,
        "error" => "Account creation failed.",
        "details" => $stmt->error
    ]);

    $stmt->close();
    $conn->close();
    exit;
}


$user_id = $stmt->insert_id;


// =====================================================
// SUCCESS
// =====================================================

echo json_encode([
    "success" => true,
    "message" => "Account created successfully.",
    "user" => [
        "id" => $user_id,
        "full_name" => $full_name,
        "email" => $email,
        "phone" => $phone,
        "cnic" => $cnic,
        "role" => "user",
        "status" => "approved"
    ]
]);


$stmt->close();
$conn->close();

?>