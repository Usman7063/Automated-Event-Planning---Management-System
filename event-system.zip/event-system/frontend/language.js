/* =====================================================================
   language.js -- Hassan Tent Service (site-wide language switcher)
   ---------------------------------------------------------------------
   Include this AFTER translation.js on every page:

       <script src="translation.js"></script>
       <script src="language.js"></script>

   This file does two things:

     1. Injects a small floating "EN / اردو" toggle button in the
        corner of the page. It is built entirely with JavaScript using
        its own brand-new CSS classes (lang-switcher-*) -- it never
        touches or renames any class that already exists on your site,
        so your existing design/layout is 100% safe.

     2. Applies the chosen language to every element on the page that
        has a data-translate="key" or data-translate-ph="key"
        attribute, using the TRANSLATIONS dictionary from
        translation.js. The choice is saved in localStorage, so it
        stays the same as the visitor moves from page to page
        (index.html -> booking.html -> payment.html -> ...).
   ===================================================================== */

(function () {

  var STORAGE_KEY = "siteLang";

  /* ---------- 1. Apply a language to the current page ---------- */
  function applyLanguage(lang) {
    if (lang !== "ur") lang = "en"; // only two languages supported, default to English

    var textCount = 0, phCount = 0, missingKeys = [];

    // plain text content (headings, paragraphs, buttons, options, etc.)
    document.querySelectorAll("[data-translate]").forEach(function (el) {
      var key = el.getAttribute("data-translate");
      var entry = window.TRANSLATIONS && window.TRANSLATIONS[key];
      if (!entry) { missingKeys.push(key); return; } // no translation on file for this key -- leave text as-is
      el.textContent = entry[lang] || entry.en;
      textCount++;
    });

    // input / textarea placeholders
    document.querySelectorAll("[data-translate-ph]").forEach(function (el) {
      var key = el.getAttribute("data-translate-ph");
      var entry = window.TRANSLATIONS && window.TRANSLATIONS[key];
      if (!entry) { missingKeys.push(key); return; }
      el.setAttribute("placeholder", entry[lang] || entry.en);
      phCount++;
    });

    console.log("[language.js] applyLanguage('" + lang + "') updated " + textCount +
      " text elements and " + phCount + " placeholders." +
      (missingKeys.length ? " (" + missingKeys.length + " keys had no translation entry.)" : ""));

    document.documentElement.setAttribute("lang", lang);
    // a harmless new class -- lets you add optional Urdu-only CSS later
    // (e.g. a nastaliq font) without touching any existing class.
    document.body.classList.toggle("lang-ur-active", lang === "ur");

    localStorage.setItem(STORAGE_KEY, lang);
    updateToggleWidget(lang);

    // FIX: pages like gallery.html / comparison.html build some of their
    // text (titles, tables, "Why Choose Us" lists, etc.) dynamically with
    // JavaScript instead of plain data-translate spans, so this loop can't
    // reach that text. Firing a "languagechange" event lets those pages'
    // own scripts (gallery.js / comparison.js) listen and re-render
    // themselves in the newly selected language. Pages that don't care
    // simply never listen for it, so this is 100% backward compatible.
    document.dispatchEvent(new CustomEvent("languagechange", { detail: { lang: lang } }));
  }

  /* Small helper so other pages/scripts can ask "what language is active
     right now?" without duplicating the localStorage key/logic. */
  function getCurrentLang() {
    var lang = localStorage.getItem(STORAGE_KEY) || "en";
    return lang === "ur" ? "ur" : "en";
  }
  window.getCurrentLang = getCurrentLang;

  /* ---------- 2. Floating EN / اردو toggle widget ---------- */
  var widgetButtons = {};

  function buildToggleWidget() {
    // brand-new, self-contained styles -- scoped to our own class names only
    var style = document.createElement("style");
    style.textContent =
      ".lang-switcher-widget{position:fixed;bottom:18px;right:18px;z-index:99999;" +
      "display:flex;background:#fff;border:1px solid #ddd;border-radius:30px;" +
      "box-shadow:0 6px 20px rgba(0,0,0,.15);padding:4px;font-family:sans-serif;}" +
      ".lang-switcher-btn{border:none;background:transparent;cursor:pointer;" +
      "padding:8px 16px;border-radius:24px;font-size:14px;font-weight:600;color:#555;}" +
      ".lang-switcher-btn.lang-switcher-active{background:#ffc107;color:#111;}" +
      "@media(max-width:480px){.lang-switcher-widget{bottom:12px;right:12px;}" +
      ".lang-switcher-btn{padding:7px 12px;font-size:13px;}}";
    document.head.appendChild(style);

    var wrap = document.createElement("div");
    wrap.className = "lang-switcher-widget";

    var btnEn = document.createElement("button");
    btnEn.type = "button";
    btnEn.className = "lang-switcher-btn";
    btnEn.textContent = "EN";
    btnEn.addEventListener("click", function () { applyLanguage("en"); });

    var btnUr = document.createElement("button");
    btnUr.type = "button";
    btnUr.className = "lang-switcher-btn";
    btnUr.textContent = "اردو";
    btnUr.addEventListener("click", function () { applyLanguage("ur"); });

    wrap.appendChild(btnEn);
    wrap.appendChild(btnUr);
    document.body.appendChild(wrap);

    widgetButtons.en = btnEn;
    widgetButtons.ur = btnUr;
  }

  function updateToggleWidget(lang) {
    if (!widgetButtons.en) return;
    widgetButtons.en.classList.toggle("lang-switcher-active", lang === "en");
    widgetButtons.ur.classList.toggle("lang-switcher-active", lang === "ur");
  }

  /* ---------- 3. Start up ---------- */
  function init() {
    buildToggleWidget();

    // Safety net: if translation.js has not finished loading yet for any
    // reason (slow network, wrong file, wrong order), wait for it instead
    // of silently giving up. Retries for up to ~5 seconds.
    var attempts = 0;
    function waitForTranslations() {
      attempts++;
      if (window.TRANSLATIONS) {
        console.log("[language.js] TRANSLATIONS loaded OK -- " + Object.keys(window.TRANSLATIONS).length + " keys found.");
        var savedLang = localStorage.getItem(STORAGE_KEY) || "en";
        applyLanguage(savedLang);
      } else if (attempts < 50) {
        setTimeout(waitForTranslations, 100);
      } else {
        console.error("[language.js] window.TRANSLATIONS was never found. " +
          "Check that translation.js is in the same folder as this page, " +
          "that its <script> tag loads BEFORE language.js, and that it " +
          "starts with 'window.TRANSLATIONS = {' (not 'const TRANSLATIONS').");
      }
    }
    waitForTranslations();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init(); // script is at the bottom of <body>, DOM is already ready
  }

  // exposed globally in case a page wants to trigger a switch itself
  window.applyLanguage = applyLanguage;

})();