console.log("🔥 THIS IS THE CORRECT FRONTEND APP.JS");
// =====================================================================
// APP.JS
// Global JavaScript for Event Management System
// =====================================================================
// This file is loaded on multiple pages.
//
// IMPORTANT:
// Every page does NOT contain every element.
// Therefore, every page-specific element is checked before use.
//
// This prevents errors such as:
//   Cannot read properties of null (reading 'style')
//   Cannot read properties of null (reading 'addEventListener')
// =====================================================================


document.addEventListener("DOMContentLoaded", function () {


    // =================================================================
    // HERO SLIDER
    // =================================================================

    const heroSlider =
        document.getElementById("heroSlider");

    if (
        heroSlider &&
        typeof bootstrap !== "undefined" &&
        bootstrap.Carousel
    ) {

        try {

            const carousel =
                new bootstrap.Carousel(
                    heroSlider,
                    {
                        interval: 3000,
                        ride: "carousel",
                        pause: false,
                        wrap: true,
                        touch: true
                    }
                );

            carousel.cycle();

            console.log(
                "✅ Hero slider initialized."
            );

        } catch (error) {

            console.error(
                "❌ Hero slider initialization failed:",
                error
            );

        }

    }


    // =================================================================
    // CONTACT FORM
    // =================================================================

    const contactForm =
        document.getElementById("contactForm");

    const successPopup =
        document.getElementById("successPopup");

    const closePopup =
        document.getElementById("closePopup");


    // =================================================================
    // CONTACT BACKEND
    // =================================================================

    const CONTACT_BACKEND_URL =
        "http://localhost/event-system/backend/contact.php";


    // =================================================================
    // CONTACT FORM SUBMISSION
    // =================================================================

    if (contactForm) {

        contactForm.addEventListener(
            "submit",
            async function (e) {

                e.preventDefault();


                // -----------------------------------------------------
                // GET INPUTS
                // -----------------------------------------------------

                const name =
                    document.getElementById("name");

                const email =
                    document.getElementById("email");

                const phone =
                    document.getElementById("phone");

                const subject =
                    document.getElementById("subject");

                const message =
                    document.getElementById("message");


                // -----------------------------------------------------
                // CHECK INPUT ELEMENTS
                // -----------------------------------------------------

                if (
                    !name ||
                    !email ||
                    !phone ||
                    !subject ||
                    !message
                ) {

                    console.error(
                        "❌ Contact form elements are missing."
                    );

                    alert(
                        "❌ Contact form could not be loaded correctly."
                    );

                    return;

                }


                // -----------------------------------------------------
                // EMPTY FIELD VALIDATION
                // -----------------------------------------------------

                if (
                    name.value.trim() === "" ||
                    email.value.trim() === "" ||
                    phone.value.trim() === "" ||
                    subject.value.trim() === "" ||
                    message.value.trim() === ""
                ) {

                    alert(
                        "Please fill all fields."
                    );

                    return;

                }


                // -----------------------------------------------------
                // EMAIL VALIDATION
                // -----------------------------------------------------

                const emailPattern =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (
                    !emailPattern.test(
                        email.value.trim()
                    )
                ) {

                    alert(
                        "Please enter a valid email address."
                    );

                    email.focus();

                    return;

                }


                // -----------------------------------------------------
                // PHONE VALIDATION
                // -----------------------------------------------------

                const phoneValue =
                    phone.value.trim();

                if (
                    phoneValue.length < 11
                ) {

                    alert(
                        "Please enter a valid phone number."
                    );

                    phone.focus();

                    return;

                }


                // -----------------------------------------------------
                // PREPARE DATA
                // -----------------------------------------------------

                const data = {

                    name:
                        name.value.trim(),

                    email:
                        email.value.trim(),

                    phone:
                        phone.value.trim(),

                    subject:
                        subject.value.trim(),

                    message:
                        message.value.trim()

                };


                // -----------------------------------------------------
                // DEBUG
                // -----------------------------------------------------

                console.log(
                    "========================================"
                );

                console.log(
                    "CONTACT FORM DATA BEING SENT:"
                );

                console.log(data);

                console.log(
                    "========================================"
                );


                // -----------------------------------------------------
                // SEND DATA TO PHP
                // -----------------------------------------------------

                try {

                    const response =
                        await fetch(
                            CONTACT_BACKEND_URL,
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json",

                                    "Accept":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify(data)
                            }
                        );


                    // -------------------------------------------------
                    // GET RAW SERVER RESPONSE
                    // -------------------------------------------------

                    const rawResponse =
                        await response.text();

                    console.log(
                        "contact.php RAW RESPONSE:"
                    );

                    console.log(
                        rawResponse
                    );


                    // -------------------------------------------------
                    // HTTP STATUS CHECK
                    // -------------------------------------------------

                    if (!response.ok) {

                        console.error(
                            "❌ Contact server returned HTTP status:",
                            response.status
                        );

                        alert(
                            "❌ Server error (" +
                            response.status +
                            "). Please try again."
                        );

                        return;

                    }


                    // -------------------------------------------------
                    // PARSE JSON
                    // -------------------------------------------------

                    let result;

                    try {

                        result =
                            JSON.parse(
                                rawResponse
                            );

                    } catch (jsonError) {

                        console.error(
                            "❌ Invalid JSON from contact.php:",
                            rawResponse
                        );

                        alert(
                            "❌ contact.php returned an invalid response."
                        );

                        return;

                    }


                    // -------------------------------------------------
                    // BACKEND ERROR
                    // -------------------------------------------------

                    if (
                        !result ||
                        !result.success
                    ) {

                        console.error(
                            "❌ Contact backend error:",
                            result
                        );

                        alert(
                            "❌ Message could not be submitted.\n\n" +
                            (
                                result &&
                                result.error
                                    ? result.error
                                    : "Unknown server error."
                            )
                        );

                        return;

                    }


                    // -------------------------------------------------
                    // SUCCESS
                    // -------------------------------------------------

                    console.log(
                        "✅ CONTACT MESSAGE SAVED SUCCESSFULLY"
                    );

                    console.log(
                        "Contact ID:",
                        result.contact_id
                    );


                    // -------------------------------------------------
                    // SHOW SUCCESS POPUP
                    // -------------------------------------------------

                    if (successPopup) {

                        successPopup.style.display =
                            "flex";

                    } else {

                        // Fallback if popup doesn't exist

                        alert(
                            "✅ Your message has been submitted successfully."
                        );

                    }


                    // -------------------------------------------------
                    // RESET FORM
                    // -------------------------------------------------

                    contactForm.reset();

                } catch (error) {

                    console.error(
                        "❌ Contact connection error:",
                        error
                    );

                    alert(
                        "❌ Unable to connect to the contact server.\n\n" +
                        error.message
                    );

                }

            }
        );

    }


    // =================================================================
    // CLOSE SUCCESS POPUP
    // =================================================================

    if (
        closePopup &&
        successPopup
    ) {

        closePopup.addEventListener(
            "click",
            function () {

                successPopup.style.display =
                    "none";

            }
        );

    }


    // =================================================================
    // CLICK OUTSIDE SUCCESS POPUP
    // =================================================================

    if (successPopup) {

        successPopup.addEventListener(
            "click",
            function (e) {

                if (
                    e.target === successPopup
                ) {

                    successPopup.style.display =
                        "none";

                }

            }
        );

    }


    // =================================================================
    // SMOOTH SCROLL
    // =================================================================

    const smoothScrollLinks =
        document.querySelectorAll(
            'a[href^="#"]'
        );

    if (
        smoothScrollLinks &&
        smoothScrollLinks.length > 0
    ) {

        smoothScrollLinks.forEach(
            function (link) {

                link.addEventListener(
                    "click",
                    function (e) {

                        const targetSelector =
                            this.getAttribute("href");


                        // Ignore empty "#"

                        if (
                            !targetSelector ||
                            targetSelector === "#"
                        ) {

                            return;

                        }


                        let target = null;

                        try {

                            target =
                                document.querySelector(
                                    targetSelector
                                );

                        } catch (error) {

                            console.warn(
                                "Invalid smooth-scroll selector:",
                                targetSelector
                            );

                            return;

                        }


                        if (target) {

                            e.preventDefault();

                            target.scrollIntoView({
                                behavior: "smooth",
                                block: "start"
                            });

                        }

                    }
                );

            }
        );

    }


    // =================================================================
    // PHONE INPUT
    // =================================================================

    const phoneInput =
        document.getElementById("phone");

    if (phoneInput) {

        phoneInput.addEventListener(
            "input",
            function () {

                this.value =
                    this.value.replace(
                        /[^0-9+]/g,
                        ""
                    );

            }
        );

    }


    // =================================================================
    // CONTACT CARD HOVER EFFECT
    // =================================================================

    const contactCards =
        document.querySelectorAll(
            ".contact-card"
        );

    if (
        contactCards &&
        contactCards.length > 0
    ) {

        contactCards.forEach(
            function (card) {

                if (!card) {
                    return;
                }


                card.addEventListener(
                    "mouseenter",
                    function () {

                        this.style.transform =
                            "translateY(-8px)";

                    }
                );


                card.addEventListener(
                    "mouseleave",
                    function () {

                        this.style.transform =
                            "translateY(0)";

                    }
                );

            }
        );

    }


    // =================================================================
    // SOCIAL ICON HOVER EFFECT
    // =================================================================

    const socialIcons =
        document.querySelectorAll(
            ".social-icons a"
        );

    if (
        socialIcons &&
        socialIcons.length > 0
    ) {

        socialIcons.forEach(
            function (icon) {

                if (!icon) {
                    return;
                }


                icon.addEventListener(
                    "mouseenter",
                    function () {

                        this.style.transform =
                            "translateY(-8px) scale(1.1)";

                    }
                );


                icon.addEventListener(
                    "mouseleave",
                    function () {

                        this.style.transform =
                            "translateY(0) scale(1)";

                    }
                );

            }
        );

    }


    // =================================================================
    // PAGE LOADED
    // =================================================================

    window.addEventListener(
        "load",
        function () {

            if (document.body) {

                document.body.style.opacity =
                    "1";

            }

        }
    );


    // =================================================================
    // SCROLL TO TOP BUTTON
    // =================================================================

    const scrollBtn =
        document.getElementById(
            "scrollTopBtn"
        );


    // IMPORTANT:
    // Only attach events if the button exists.

    if (scrollBtn) {


        // -------------------------------------------------------------
        // SHOW / HIDE BUTTON
        // -------------------------------------------------------------

        window.addEventListener(
            "scroll",
            function () {

                if (
                    window.scrollY > 300
                ) {

                    scrollBtn.style.display =
                        "block";

                } else {

                    scrollBtn.style.display =
                        "none";

                }

            }
        );


        // -------------------------------------------------------------
        // SCROLL TO TOP
        // -------------------------------------------------------------

        scrollBtn.addEventListener(
            "click",
            function () {

                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });

            }
        );

    }


    // =================================================================
    // GLOBAL INITIALIZATION COMPLETE
    // =================================================================

    console.log(
        "✅ app.js initialized successfully."
    );


});
// ============================================================
// USER LOGIN / ACCOUNT DROPDOWN
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

    const loginBtn =
        document.getElementById("loginBtn");

    const loginBtnText =
        document.getElementById("loginBtnText");

    const loginMenuItem =
        document.getElementById("loginMenuItem");

    const profileMenuItem =
        document.getElementById("profileMenuItem");

    const bookingsMenuItem =
        document.getElementById("bookingsMenuItem");

    const logoutMenuItem =
        document.getElementById("logoutMenuItem");

    const logoutBtn =
        document.getElementById("logoutBtn");


    // --------------------------------------------------------
    // Stop if this page has no account button
    // --------------------------------------------------------

    if (!loginBtn) {
        return;
    }


    // --------------------------------------------------------
    // Function to display logged-in user
    // --------------------------------------------------------

    function updateUserButton() {

        const storedUser =
            localStorage.getItem("loggedInUser");


        // ====================================================
        // NOT LOGGED IN
        // ====================================================

        if (!storedUser) {

            if (loginBtnText) {

                loginBtnText.removeAttribute(
                    "data-translate"
                );

                loginBtnText.textContent =
                    "Login";

            }

            if (loginMenuItem) {
                loginMenuItem.classList.remove("d-none");
            }

            if (profileMenuItem) {
                profileMenuItem.classList.add("d-none");
            }

            if (bookingsMenuItem) {
                bookingsMenuItem.classList.add("d-none");
            }

            if (logoutMenuItem) {
                logoutMenuItem.classList.add("d-none");
            }

            return;
        }


        // ====================================================
        // READ USER
        // ====================================================

        let user;

        try {

            user =
                JSON.parse(storedUser);

        } catch (error) {

            console.error(
                "Invalid logged-in user:",
                error
            );

            localStorage.removeItem(
                "loggedInUser"
            );

            return;
        }


        // ====================================================
        // CHECK USER
        // ====================================================

        if (
            !user ||
            !user.full_name
        ) {

            console.error(
                "Invalid user information:",
                user
            );

            localStorage.removeItem(
                "loggedInUser"
            );

            return;
        }


        // ====================================================
        // USER IS LOGGED IN
        // ====================================================

        console.log(
            "Logged-in user:",
            user.full_name
        );


        // ----------------------------------------------------
        // IMPORTANT:
        // Remove data-translate so language.js cannot
        // replace the user's name with "Login".
        // ----------------------------------------------------

        if (loginBtnText) {

            loginBtnText.removeAttribute(
                "data-translate"
            );

            loginBtnText.textContent =
                user.full_name;

        }


        // ----------------------------------------------------
        // Hide Login
        // ----------------------------------------------------

        if (loginMenuItem) {

            loginMenuItem.classList.add(
                "d-none"
            );

        }


        // ----------------------------------------------------
        // Show Profile
        // ----------------------------------------------------

        if (profileMenuItem) {

            profileMenuItem.classList.remove(
                "d-none"
            );

        }


        // ----------------------------------------------------
        // Show Bookings
        // ----------------------------------------------------

        if (bookingsMenuItem) {

            bookingsMenuItem.classList.remove(
                "d-none"
            );

        }


        // ----------------------------------------------------
        // Show Logout
        // ----------------------------------------------------

        if (logoutMenuItem) {

            logoutMenuItem.classList.remove(
                "d-none"
            );

        }

    }


    // --------------------------------------------------------
    // Initial check
    // --------------------------------------------------------

    updateUserButton();


    // --------------------------------------------------------
    // IMPORTANT:
    // language.js may run after app.js.
    //
    // Re-apply the logged-in user after language changes.
    // --------------------------------------------------------

    document.addEventListener(
        "languagechange",
        function () {

            updateUserButton();

        }
    );


    // ========================================================
    // LOGOUT
    // ========================================================

    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            async function () {

                console.log(
                    "Logging out..."
                );


                // ------------------------------------------------
                // Remove local login
                // ------------------------------------------------

                localStorage.removeItem(
                    "loggedInUser"
                );


                // ------------------------------------------------
                // Destroy PHP session
                // ------------------------------------------------

                try {

                    const response =
                        await fetch(
                            "http://localhost/event-system/backend/auth/logout.php",
                            {
                                method: "POST",
                                credentials: "include",
                                headers: {
                                    "Accept":
                                        "application/json"
                                }
                            }
                        );


                    const rawResponse =
                        await response.text();


                    console.log(
                        "LOGOUT RESPONSE:",
                        rawResponse
                    );

                } catch (error) {

                    console.error(
                        "Logout request failed:",
                        error
                    );

                }


                // ------------------------------------------------
                // Go to homepage
                // ------------------------------------------------

                window.location.href =
                    "index.html";

            }
        );

    }

});