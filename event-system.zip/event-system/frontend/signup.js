// ============================================================
// SIGNUP.JS
// User Registration Frontend
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

    const signupForm =
        document.getElementById("signupForm");

    const signupBtn =
        document.getElementById("signupBtn");

    const signupBtnText =
        document.getElementById("signupBtnText");

    const signupSpinner =
        document.getElementById("signupSpinner");

    const signupMessage =
        document.getElementById("signupMessage");

    const password =
        document.getElementById("password");

    const confirmPassword =
        document.getElementById("confirmPassword");

    const togglePassword =
        document.getElementById("togglePassword");

    const passwordIcon =
        document.getElementById("passwordIcon");


    // ========================================================
    // SHOW MESSAGE
    // ========================================================

    function showMessage(message, type) {

        signupMessage.textContent = message;

        signupMessage.className =
            "alert alert-" + type;

        signupMessage.classList.remove("d-none");

    }


    // ========================================================
    // HIDE MESSAGE
    // ========================================================

    function hideMessage() {

        signupMessage.classList.add("d-none");

    }


    // ========================================================
    // BUTTON LOADING STATE
    // ========================================================

    function setLoading(isLoading) {

        signupBtn.disabled = isLoading;

        if (isLoading) {

            signupBtnText.classList.add("d-none");

            signupSpinner.classList.remove("d-none");

        } else {

            signupBtnText.classList.remove("d-none");

            signupSpinner.classList.add("d-none");

        }

    }


    // ========================================================
    // PASSWORD VISIBILITY
    // ========================================================

    if (togglePassword) {

        togglePassword.addEventListener(
            "click",
            function () {

                if (password.type === "password") {

                    password.type = "text";

                    passwordIcon.classList.remove(
                        "bi-eye"
                    );

                    passwordIcon.classList.add(
                        "bi-eye-slash"
                    );

                } else {

                    password.type = "password";

                    passwordIcon.classList.remove(
                        "bi-eye-slash"
                    );

                    passwordIcon.classList.add(
                        "bi-eye"
                    );

                }

            }
        );

    }


    // ========================================================
    // PHONE INPUT
    // ========================================================

    const phone =
        document.getElementById("phone");

    if (phone) {

        phone.addEventListener(
            "input",
            function () {

                this.value =
                    this.value.replace(/[^0-9]/g, "");

            }
        );

    }


    // ========================================================
    // CNIC INPUT
    // ========================================================

    const cnic =
        document.getElementById("cnic");

    if (cnic) {

    cnic.addEventListener("input", function () {

        let digits =
            this.value.replace(/[^0-9]/g, "");

        digits = digits.substring(0, 13);

        let value = digits;

        if (digits.length > 5) {

            value =
                digits.substring(0, 5) +
                "-" +
                digits.substring(5);

        }

        if (digits.length > 12) {

            value =
                digits.substring(0, 5) +
                "-" +
                digits.substring(5, 12) +
                "-" +
                digits.substring(12);

        }

        this.value = value;

    });

}


    // ========================================================
    // VALIDATION
    // ========================================================

    function validateForm() {

        let valid = true;


        const fullName =
            document.getElementById("fullName");

        const email =
            document.getElementById("email");


        // Reset validation

        document
            .querySelectorAll(
                "#signupForm .form-control"
            )
            .forEach(function (field) {

                field.classList.remove(
                    "is-invalid"
                );

                field.classList.remove(
                    "is-valid"
                );

            });


        // ----------------------------------------------------
        // NAME
        // ----------------------------------------------------

        if (
            fullName.value.trim() === "" ||
            fullName.value.trim().length < 2
        ) {

            fullName.classList.add(
                "is-invalid"
            );

            valid = false;

        } else {

            fullName.classList.add(
                "is-valid"
            );

        }


        // ----------------------------------------------------
        // EMAIL
        // ----------------------------------------------------

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (
            !emailPattern.test(
                email.value.trim()
            )
        ) {

            email.classList.add(
                "is-invalid"
            );

            valid = false;

        } else {

            email.classList.add(
                "is-valid"
            );

        }


        // ----------------------------------------------------
        // PHONE
        // ----------------------------------------------------

        const phonePattern =
            /^03[0-9]{9}$/;


        if (
            !phonePattern.test(
                phone.value.trim()
            )
        ) {

            phone.classList.add(
                "is-invalid"
            );

            valid = false;

        } else {

            phone.classList.add(
                "is-valid"
            );

        }


        // ----------------------------------------------------
        // CNIC
        // ----------------------------------------------------

        if (
            cnic.value.trim() !== ""
        ) {

            const cnicPattern =
                /^[0-9]{5}-[0-9]{7}-[0-9]{1}$/;


            if (
                !cnicPattern.test(
                    cnic.value.trim()
                )
            ) {

                cnic.classList.add(
                    "is-invalid"
                );

                valid = false;

            } else {

                cnic.classList.add(
                    "is-valid"
                );

            }

        }


        // ----------------------------------------------------
        // PASSWORD
        // ----------------------------------------------------

        if (password.value.length < 8) {

            password.classList.add(
                "is-invalid"
            );

            valid = false;

        } else {

            password.classList.add(
                "is-valid"
            );

        }


        // ----------------------------------------------------
        // CONFIRM PASSWORD
        // ----------------------------------------------------

        if (
            confirmPassword.value !==
            password.value ||
            confirmPassword.value === ""
        ) {

            confirmPassword.classList.add(
                "is-invalid"
            );

            valid = false;

        } else {

            confirmPassword.classList.add(
                "is-valid"
            );

        }


        return valid;

    }


    // ========================================================
    // SUBMIT
    // ========================================================

    if (signupForm) {

        signupForm.addEventListener(
            "submit",
            async function (e) {

                e.preventDefault();

                hideMessage();


                // ------------------------------------------------
                // VALIDATE
                // ------------------------------------------------

                if (!validateForm()) {

                    showMessage(
                        "Please correct the highlighted fields.",
                        "danger"
                    );

                    return;

                }


                // ------------------------------------------------
                // COLLECT DATA
                // ------------------------------------------------

                const data = {

                    full_name:
                        document
                            .getElementById("fullName")
                            .value
                            .trim(),

                    email:
                        document
                            .getElementById("email")
                            .value
                            .trim(),

                    phone:
                        document
                            .getElementById("phone")
                            .value
                            .trim(),

                    cnic:
                        document
                            .getElementById("cnic")
                            .value
                            .trim(),

                    password:
                        password.value,

                    confirm_password:
                        confirmPassword.value

                };


                console.log(
                    "================================="
                );

                console.log(
                    "SIGNUP DATA BEING SENT:"
                );

                // Don't log the password
                console.log({
                    full_name: data.full_name,
                    email: data.email,
                    phone: data.phone,
                    cnic: data.cnic
                });

                console.log(
                    "================================="
                );


                // ------------------------------------------------
                // START LOADING
                // ------------------------------------------------

                setLoading(true);


                try {

                    const response =
                        await fetch(
                            "../backend/auth/signup.php",
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json",

                                    "Accept":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify(data)
                            }
                        );


                    const rawResponse =
                        await response.text();


                    console.log(
                        "SIGNUP RAW RESPONSE:"
                    );

                    console.log(
                        rawResponse
                    );


                    // ------------------------------------------------
                    // HTTP ERROR
                    // ------------------------------------------------

                    if (!response.ok) {

                        showMessage(
                            "Server error (" +
                            response.status +
                            "). Please try again.",
                            "danger"
                        );

                        return;

                    }


                    // ------------------------------------------------
                    // JSON
                    // ------------------------------------------------

                    let result;


                    try {

                        result =
                            JSON.parse(
                                rawResponse
                            );

                    } catch (error) {

                        console.error(
                            "Invalid JSON:",
                            rawResponse
                        );

                        showMessage(
                            "The server returned an invalid response.",
                            "danger"
                        );

                        return;

                    }


                    // ------------------------------------------------
                    // BACKEND ERROR
                    // ------------------------------------------------

                    if (!result.success) {

                        showMessage(
                            result.error ||
                            "Unable to create account.",
                            "danger"
                        );

                        return;

                    }


                    // ------------------------------------------------
                    // SUCCESS
                    // ------------------------------------------------

                    console.log(
                        "ACCOUNT CREATED:",
                        result.user_id
                    );


                    showMessage(
                        "✅ " +
                        result.message,
                        "success"
                    );


                    // Reset form

                    signupForm.reset();


                    document
                        .querySelectorAll(
                            "#signupForm .form-control"
                        )
                        .forEach(function (field) {

                            field.classList.remove(
                                "is-valid"
                            );

                            field.classList.remove(
                                "is-invalid"
                            );

                        });


                    // ------------------------------------------------
                    // REDIRECT TO LOGIN
                    // ------------------------------------------------

                    setTimeout(
                        function () {

                            window.location.href =
                                "login.html";

                        },
                        1800
                    );


                } catch (error) {

                    console.error(
                        "Signup connection error:",
                        error
                    );


                    showMessage(
                        "❌ Unable to connect to the server. " +
                        "Make sure XAMPP Apache and MySQL are running.",
                        "danger"
                    );


                } finally {

                    setLoading(false);

                }

            }
        );

    }

});