document.addEventListener("DOMContentLoaded", async function () {

    try {

        const response = await fetch(
            "http://localhost/event-system/backend/auth/session.php",
            {
                method: "GET",
                credentials: "include",
                headers: {
                    "Accept": "application/json"
                }
            }
        );

        const data = await response.json();

        console.log("SESSION RESPONSE:", data);

        // ------------------------------------------------
        // User is not logged in
        // ------------------------------------------------

        if (!data.logged_in || !data.user) {
            console.log("No logged-in user. Booking fields remain empty.");
            return;
        }

        const user = data.user;

        // ------------------------------------------------
        // booking.html
        // ------------------------------------------------

        const customerName =
            document.getElementById("customerName");

        const customerPhone =
            document.getElementById("customerPhone");

        const customerEmail =
            document.getElementById("customerEmail");


        if (customerName) {
            customerName.value = user.full_name || "";
        }

        if (customerPhone) {
            customerPhone.value = user.phone || "";
        }

        if (customerEmail) {
            customerEmail.value = user.email || "";
        }


        // ------------------------------------------------
        // booking1.html
        // ------------------------------------------------

        const custName =
            document.getElementById("custName");

        const custPhone =
            document.getElementById("custPhone");


        if (custName) {
            custName.value = user.full_name || "";
        }

        if (custPhone) {
            custPhone.value = user.phone || "";
        }


        // ------------------------------------------------
        // booking2.html
        // ------------------------------------------------

        const fullName =
            document.getElementById("fullName");

        const mobile =
            document.getElementById("mobile");

        const email =
            document.getElementById("email");

        const cnic =
            document.getElementById("cnic");


        if (fullName) {
            fullName.value = user.full_name || "";
        }

        if (mobile) {
            mobile.value = user.phone || "";
        }

        if (email) {
            email.value = user.email || "";
        }

        if (cnic) {
            cnic.value = user.cnic || "";
        }


        console.log(
            "Booking customer information autofilled successfully."
        );

    } catch (error) {

        console.error(
            "Unable to load logged-in user information:",
            error
        );

    }

});