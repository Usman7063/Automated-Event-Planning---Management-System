/* =====================================================================
   booking1.js -- Dream Event Decoration Booking
   =====================================================================
   HOW THIS FILE IS ORGANISED (read top to bottom):*/
/* =====================================================================
   LOGGED-IN USER AUTOFILL
   ===================================================================== */

function autofillLoggedInUser() {

    const storedUser = localStorage.getItem("loggedInUser");

    if (!storedUser) {
        return;
    }

    try {

        const user = JSON.parse(storedUser);

        if (!user) {
            return;
        }

        // Full Name
        const fullName = document.getElementById("fullName");

        if (fullName && user.full_name) {
            fullName.value = user.full_name;
        }

        // Mobile
        const mobile = document.getElementById("mobile");

        if (mobile && user.phone) {
            mobile.value = user.phone;
        }

        // Email
        const email = document.getElementById("email");

        if (email && user.email) {
            email.value = user.email;
        }

        // CNIC
        const cnic = document.getElementById("cnic");

        if (cnic && user.cnic) {
            cnic.value = user.cnic;
        }

    } catch (error) {

        console.error(
            "Unable to load logged-in user:",
            error
        );

    }
}

// Run when booking1.js loads

   /*  1.  DATA           -- all prices / package details / accounts live
                            here as plain arrays & objects. Change prices
                            or wording here; you should never need to
                            touch the HTML to update a price.
     2.  STATE           -- a handful of variables that remember what the
                            visitor has clicked so far (selected package,
                            selected vehicle, etc). Nothing here is saved
                            to a server -- it only lives in the browser
                            while the page is open.
     3.  EVENT TYPE       -- step 2 of the form (Wedding / Mehndi / ...)
     4.  PACKAGES         -- step 3a: ready-made packages for the chosen
                            event type
     5.  CUSTOM ITEMS      -- step 3b: pick-your-own decoration items
     6.  CHAIR QUANTITY    -- step 4: qty x price line item
     7.  TRANSPORT         -- step 5: yes/no + vehicle choice
     8.  PAYMENT           -- step 6: method + QR code + screenshot
     9.  DELIVERY          -- step 7: how to send the confirmation
     10. TOTALS & SUMMARY  -- keeps the sidebar + payment box numbers
                            in sync every time something changes
     11. PROGRESS BAR      -- the "Form completion %" indicator
     12. VALIDATION        -- checked once, when Submit is pressed
     13. SUBMIT            -- builds the booking + shows the Thank-You
                            screen
     14. PDF DOWNLOAD
     15. RESET / BACK
     16. STARTUP           -- wires everything together once the page
                            has loaded
   ===================================================================== */


/* =====================================================================
   1. DATA -- edit prices, package contents, or payment accounts here
   ===================================================================== */

// The four event type cards shown first. `img` must point at a real
// file in your /image folder. `translateKey` links each name to its
// entry in translation.js so the language switch can translate it too.
const EVENT_TYPES = [
  { id: 'wedding',  name: 'Wedding',  img: 'image/wedding.jpg',  translateKey: 'b1_evt_wedding'  },
  { id: 'mehndi',   name: 'Mehndi',   img: 'image/mehndi.jpg',   translateKey: 'b1_evt_mehndi'   },
  { id: 'birthday', name: 'Birthday', img: 'image/birthday.jpg', translateKey: 'b1_evt_birthday' },
  { id: 'function', name: 'Function', img: 'image/function.jpg', translateKey: 'b1_evt_function' }
];

// Ready-made packages, grouped by event type id (must match EVENT_TYPES
// ids above). Each package needs a unique `id` within its own group.
const PACKAGES = {
  wedding: [
    {
      id: 'silver', name: 'Silver Wedding Package', price: 50000, img: 'image/silver.jpg',
      features: ['Simple Stage Decoration', 'Artificial Flowers', 'Basic Lighting', 'Entrance Gate', '10 Chairs Decoration']
    },
    {
      id: 'gold', name: 'Gold Wedding Package', price: 100000, img: 'image/gold.jpg',
      features: ['Luxury Stage', 'Fresh Flowers', 'LED Backdrop', 'Royal Sofa Setup', 'Premium Lighting', 'Entry Gate Decoration']
    },
    {
      id: 'platinum', name: 'Platinum Wedding Package', price: 200000, img: 'image/platinum.jpg',
      features: ['Complete Venue Decoration', 'Fresh Flower Theme', 'Luxury Stage', 'Ceiling Decoration', 'Photo Booth', 'Dance Floor']
    }
  ],
  mehndi: [
    {
      id: 'simple', name: 'Simple Mehndi', price: 40000, img: 'image/simple-mehndi.jpg',
      features: ['Green Theme', 'Simple Stage', 'Fairy Lights', 'Flower Decoration']
    },
    {
      id: 'royal', name: 'Royal Mehndi', price: 90000, img: 'image/royal-mehndi.jpg',
      features: ['Premium Stage', 'Fresh Flowers', 'Jhoola Decoration', 'Lighting', 'Entrance Setup']
    }
  ],
  // Birthday & Function share the same generic 3-tier packages
  birthday: [
    { id: 'basic',   name: 'Basic Package',   price: 50000,  img: 'image/basic.jpg',   features: ['Simple Stage', 'Artificial Flowers', 'Basic Lights'] },
    { id: 'premium', name: 'Premium Package', price: 100000, img: 'image/premium.jpg', features: ['Luxury Stage', 'Fresh Flowers', 'LED Lights', 'Entrance Decoration'] },
    { id: 'luxury',  name: 'Luxury Package',  price: 200000, img: 'image/luxury.jpg',  features: ['Complete Venue Decor', 'Royal Stage', 'Photo Booth'] }
  ]
};
PACKAGES.function = PACKAGES.birthday; // Function events reuse the same generic tiers

// "Customize My Own Decoration" checkbox items, grouped by category.
const CUSTOM_ITEMS = {
  'Stage':    [ { name: 'Simple Stage', price: 20000 }, { name: 'Royal Stage', price: 50000 }, { name: 'LED Stage', price: 70000 } ],
  'Flowers':  [ { name: 'Fresh Flowers', price: 30000 }, { name: 'Artificial Flowers', price: 15000 } ],
  'Lighting': [ { name: 'Fairy Lights', price: 10000 }, { name: 'LED Lights', price: 20000 }, { name: 'Moving Lights', price: 30000 } ],
  'Extra':    [ { name: 'Photo Booth', price: 15000 }, { name: 'Dance Floor', price: 20000 }, { name: 'Entrance Gate', price: 25000 } ]
};

const CHAIR_PRICE = 500; // PKR per chair (Step 4: "Chair Decoration" quantity item)

// Transport vehicles offered in Step 5.
const VEHICLES = [
  { id: 'jeep',   name: 'Jeep',   price: 8000, features: ['Pickup', 'Drop', 'Decoration transport'] },
  { id: 'suzuki', name: 'Suzuki', price: 5000, features: ['Decoration material transport'] }
];

// Where JazzCash / Easypaisa / Bank QR codes point to. Replace with your
// real business account details.
const PAYMENT_ACCOUNTS = {
  jazzcash:  '0300-1234567',
  easypaisa: '0300-7654321',
  bank:      'Meezan Bank | Title: Dream Events | IBAN: PK00MEZN0000000000000000'
};


/* =====================================================================
   2. STATE -- what the visitor has selected so far
   ===================================================================== */
let selectedEventType     = '';               // e.g. 'wedding'
let decorationMode        = 'package';        // 'package' or 'custom'
let selectedPackage       = null;              // { name, price }
let selectedCustomItems   = [];               // [{ category, name, price }, ...]
let chairQty               = 0;
let transportRequired      = null;             // null = not yet chosen, true = Yes, false = No
let selectedVehicle       = null;              // { name, price }
let selectedPaymentMethod  = '';               // 'cash' | 'bank' | 'jazzcash' | 'easypaisa'
let screenshotUploaded     = false;
let selectedDeliveryMethods = new Set();       // holds 'sms' and/or 'email'
let lastBookingId          = '';


/* =====================================================================
   3. EVENT TYPE (Step 2)
   ===================================================================== */

// Builds the 4 event-type cards from the EVENT_TYPES list above.
function renderEventTypes(){
  const row = document.getElementById('eventTypeRow');
  row.innerHTML = EVENT_TYPES.map(eventType => `
    <div class="col-md-3 col-6">
      <div class="option-card" data-id="${eventType.id}" onclick="selectEventType('${eventType.id}')">
        <img src="${eventType.img}" alt="${eventType.name}">
        <h5 data-translate="${eventType.translateKey}">${eventType.name}</h5>
      </div>
    </div>`
  ).join('');
}

// Called when a visitor clicks one of the event-type cards.
function selectEventType(eventTypeId){
  selectedEventType = eventTypeId;

  // highlight only the clicked card
  document.querySelectorAll('#eventTypeRow .option-card').forEach(card => {
    card.classList.toggle('active', card.dataset.id === eventTypeId);
  });
  document.getElementById('eventTypeError').style.display = 'none';

  // a different event type means the old package choice no longer applies
  selectedPackage = null;
  renderPackages();

  refreshEverything();
}


/* =====================================================================
   4. PACKAGES (Step 3a -- shown when decorationMode === 'package')
   ===================================================================== */

// Small helper: look a package up by its id within the currently
// selected event type. Using an id + lookup (instead of stuffing the
// whole package object into the HTML) keeps the generated HTML simple
// and avoids any quoting/escaping problems.
function findPackage(packageId){
  const list = PACKAGES[selectedEventType] || [];
  return list.find(pkg => pkg.id === packageId);
}

// Rebuilds the package cards to match whichever event type is selected.
function renderPackages(){
  const row = document.getElementById('packageRow');
  const list = PACKAGES[selectedEventType] || [];

  row.innerHTML = list.map(pkg => `
    <div class="col-md-4">
      <div class="package-card" data-id="${pkg.id}" onclick="selectPackage('${pkg.id}')">
        <img src="${pkg.img}" alt="${pkg.name}">
        <h4>${pkg.name}</h4>
        <ul>${pkg.features.map(feature => `<li>${feature}</li>`).join('')}</ul>
        <div class="price-tag">Rs. ${pkg.price.toLocaleString()}</div>
      </div>
    </div>`
  ).join('');
}

// Called when a visitor clicks a package card.
function selectPackage(packageId){
  const pkg = findPackage(packageId);
  if (!pkg) return;

  selectedPackage = { name: pkg.name, price: pkg.price };

  document.querySelectorAll('#packageRow .package-card').forEach(card => {
    card.classList.toggle('active', card.dataset.id === packageId);
  });
  document.getElementById('packageError').style.display = 'none';

  refreshEverything();
}

// Switches between "Choose a Ready Package" and "Customize My Own".
// Only one mode counts toward the total at a time.
function setDecorationMode(mode){
  decorationMode = mode;

  document.getElementById('modeBtnPackage').classList.toggle('active', mode === 'package');
  document.getElementById('modeBtnCustom').classList.toggle('active', mode === 'custom');
  document.getElementById('packageSection').style.display = (mode === 'package') ? 'block' : 'none';
  document.getElementById('customSection').style.display  = (mode === 'custom')  ? 'block' : 'none';

  if (mode === 'custom') selectedPackage = null;
  else selectedCustomItems = [];

  refreshEverything();
}


/* =====================================================================
   5. CUSTOM ITEMS (Step 3b -- shown when decorationMode === 'custom')
   ===================================================================== */

// Builds the checkbox list, grouped by category (Stage / Flowers / ...).
function renderCustomItems(){
  const container = document.getElementById('customItemsContainer');

  container.innerHTML = Object.keys(CUSTOM_ITEMS).map(category => `
    <div class="custom-category">
      <h6>${category}</h6>
      ${CUSTOM_ITEMS[category].map((item, index) => {
        const checkboxId = `custom_${category}_${index}`;
        return `
          <div class="custom-check" onclick="document.getElementById('${checkboxId}').click()">
            <input type="checkbox" id="${checkboxId}"
                   onclick="event.stopPropagation(); toggleCustomItem('${category}', '${item.name}', ${item.price})">
            <label onclick="event.stopPropagation()">${item.name}</label>
            <span class="item-price">Rs. ${item.price.toLocaleString()}</span>
          </div>`;
      }).join('')}
    </div>`
  ).join('');
}

// Adds or removes one custom item from the selection.
function toggleCustomItem(category, name, price){
  const existingIndex = selectedCustomItems.findIndex(item => item.name === name);
  if (existingIndex > -1) selectedCustomItems.splice(existingIndex, 1);
  else selectedCustomItems.push({ category, name, price });

  refreshEverything();
}


/* =====================================================================
   6. CHAIR QUANTITY (Step 4)
   ===================================================================== */

// Called on every keystroke in the "Chair Decoration" quantity box.
function updateChairQty(value){
  chairQty = Math.max(parseInt(value) || 0, 0);
  document.getElementById('chairAmount').textContent = 'Rs. ' + (chairQty * CHAIR_PRICE).toLocaleString();
  refreshEverything();
}


/* =====================================================================
   7. TRANSPORT (Step 5)
   ===================================================================== */

// Toggled by the "Transport Required?" Yes/No buttons. The visitor must
// click one of these -- there is no default, so this always reflects a
// real choice (see the progress bar / validation checks below).
function setTransportRequired(required){
  transportRequired = required; // true or false -- never left as null again

  document.getElementById('transportYesBtn').classList.toggle('active', required === true);
  document.getElementById('transportNoBtn').classList.toggle('active', required === false);
  document.getElementById('vehicleRow').style.display = required ? 'flex' : 'none';
  document.getElementById('transportRequiredError').style.display = 'none';

  if (!required) {
    selectedVehicle = null;
    document.querySelectorAll('#vehicleRow .transport-card').forEach(card => card.classList.remove('active'));
  }
  document.getElementById('vehicleError').style.display = 'none';

  refreshEverything();
}

// Builds the Jeep / Suzuki vehicle cards.
function renderVehicles(){
  const row = document.getElementById('vehicleRow');
  row.innerHTML = VEHICLES.map(vehicle => `
    <div class="col-md-6">
      <div class="transport-card" data-id="${vehicle.id}" onclick="selectVehicle('${vehicle.id}')">
        <h5>${vehicle.id === 'jeep' ? '🚙' : '🚗'} ${vehicle.name}</h5>
        <div class="price-tag">Rs. ${vehicle.price.toLocaleString()}</div>
        <ul>${vehicle.features.map(feature => `<li>${feature}</li>`).join('')}</ul>
      </div>
    </div>`
  ).join('');
}

// Called when a visitor clicks a vehicle card.
function selectVehicle(vehicleId){
  const vehicle = VEHICLES.find(v => v.id === vehicleId);
  if (!vehicle) return;

  selectedVehicle = { name: vehicle.name, price: vehicle.price };

  document.querySelectorAll('#vehicleRow .transport-card').forEach(card => {
    card.classList.toggle('active', card.dataset.id === vehicleId);
  });
  document.getElementById('vehicleError').style.display = 'none';

  refreshEverything();
}


/* =====================================================================
   8. PAYMENT (Step 6)
   ===================================================================== */

// Called when a visitor clicks Cash / Bank / JazzCash / Easypaisa.
function selectPaymentMethod(method){
  selectedPaymentMethod = method;

  document.querySelectorAll('#paymentRow .payment-pill').forEach(pill => {
    pill.classList.toggle('active', pill.dataset.method === method);
  });
  document.getElementById('paymentError').style.display = 'none';

  renderPaymentDetailPanel(method);
  refreshEverything();
}

// Shows either a "pay in cash" note, or a QR code + mandatory screenshot
// upload box for JazzCash / Easypaisa / Bank.
function renderPaymentDetailPanel(method){
  const panel = document.getElementById('paymentDetailPanel');

  if (method === 'cash') {
    screenshotUploaded = true; // cash needs no proof of payment
    panel.innerHTML = `
      <div class="upload-box">
        <i class="fa fa-circle-check text-success"></i>
        You can pay the advance / full amount in cash at the event. No screenshot needed.
      </div>`;
    return;
  }

  screenshotUploaded = false;
  const accountText = PAYMENT_ACCOUNTS[method];
  const qrText = method === 'bank' ? accountText : `${method === 'jazzcash' ? 'JazzCash' : 'Easypaisa'}: ${accountText}`;

  panel.innerHTML = `
    <div class="row g-4 align-items-start">
      <div class="col-md-5 text-center">
        <div class="qr-box"><div id="qrCodeContainer"></div><small>Scan to pay</small></div>
        <div class="mt-2"><strong>${method === 'bank' ? 'Account Details' : 'Account'}:</strong><br>${accountText}</div>
      </div>
      <div class="col-md-7">
        <label class="form-label fw-bold">Upload Payment Screenshot <span class="text-danger">*</span></label>
        <div class="upload-box">
          <input type="file" class="form-control" id="paymentScreenshot" accept="image/*">
          <img id="screenshotPreview" alt="preview">
        </div>
        <small class="error-text" id="screenshotError" style="display:none;">Please upload your payment screenshot.</small>
      </div>
    </div>`;

  // draws a real, scannable QR code entirely in the browser
  new QRCode(document.getElementById('qrCodeContainer'), { text: qrText, width: 140, height: 140 });

  // watches the file input so we know a screenshot has actually been chosen
  document.getElementById('paymentScreenshot').addEventListener('change', function(){
    const file = this.files && this.files[0];
    screenshotUploaded = !!file;

    if (file) {
      document.getElementById('screenshotError').style.display = 'none';
      const reader = new FileReader();
      reader.onload = event => {
        const previewImg = document.getElementById('screenshotPreview');
        previewImg.src = event.target.result;
        previewImg.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
    refreshEverything();
  });
}


/* =====================================================================
   9. CONFIRMATION DELIVERY -- SMS / Email (Step 7)
   ===================================================================== */

// Multi-select: clicking again removes it. At least one is required.
function toggleDelivery(method){
  if (selectedDeliveryMethods.has(method)) selectedDeliveryMethods.delete(method);
  else selectedDeliveryMethods.add(method);

  document.querySelector(`.delivery-pill[data-method="${method}"]`).classList.toggle('active');
  document.getElementById('deliveryError').style.display = 'none';

  refreshEverything();
}


/* =====================================================================
   10. TOTALS & SUMMARY -- keeps every number on the page in sync
   ===================================================================== */

// This is the single "recalculate everything" function. Every click
// handler above calls this at the end instead of duplicating the
// totals/summary/progress-bar logic in each one.
function refreshEverything(){
  updateGrandTotal();
  updateRemainingAmount();
  updateProgress();
}

function updateGrandTotal(){
  const packagePrice = (decorationMode === 'package' && selectedPackage) ? selectedPackage.price : 0;
  const customTotal  = decorationMode === 'custom' ? selectedCustomItems.reduce((sum, item) => sum + item.price, 0) : 0;
  const chairTotal    = chairQty * CHAIR_PRICE;
  const vehiclePrice  = (transportRequired === true && selectedVehicle) ? selectedVehicle.price : 0;

  const grandTotal = packagePrice + customTotal + chairTotal + vehiclePrice;

  // ----- sidebar summary text -----
  document.getElementById('sumEventType').textContent = selectedEventType
    ? EVENT_TYPES.find(e => e.id === selectedEventType).name
    : '—';

  document.getElementById('sumPackage').textContent = packagePrice
    ? `${selectedPackage.name} - Rs. ${packagePrice.toLocaleString()}`
    : '—';

  document.getElementById('sumCustomList').innerHTML = decorationMode === 'custom'
    ? (selectedCustomItems.length
        ? selectedCustomItems.map(item => `<div class="summary-row"><span>${item.name}</span><span>Rs. ${item.price.toLocaleString()}</span></div>`).join('')
        : `<div class="summary-row"><span>None</span><span>—</span></div>`)
    : '';

  document.getElementById('sumChair').textContent = chairQty
    ? `${chairQty} chairs - Rs. ${chairTotal.toLocaleString()}`
    : '—';

  document.getElementById('sumTransport').textContent = (transportRequired === true && selectedVehicle)
    ? `${selectedVehicle.name} - Rs. ${vehiclePrice.toLocaleString()}`
    : transportRequired === true ? 'Not selected yet'
    : transportRequired === false ? 'Not required'
    : '—';

  document.getElementById('grandTotal').textContent = `Rs. ${grandTotal.toLocaleString()}`;
  document.getElementById('paymentGrandTotal').textContent = `Rs. ${grandTotal.toLocaleString()}`;
}

// Keeps "Remaining Balance" (Grand Total - Advance) in sync, in both the
// Payment box and the sidebar. Also flags an error if the advance is
// somehow more than the total.
function updateRemainingAmount(){
  const grandTotal = parseInt(document.getElementById('grandTotal').textContent.replace(/[^\d]/g, '')) || 0;
  const advance = parseInt(document.getElementById('advancePayment').value) || 0;
  const remaining = Math.max(grandTotal - advance, 0);

  document.getElementById('remainingAmount').textContent = `Rs. ${remaining.toLocaleString()}`;
  document.getElementById('sumAdvance').textContent = `Rs. ${advance.toLocaleString()}`;
  document.getElementById('sumRemaining').textContent = `Rs. ${remaining.toLocaleString()}`;

  const advanceTooHigh = advance > grandTotal && grandTotal > 0;
  document.getElementById('advancePayment').classList.toggle('is-invalid', advanceTooHigh);
  document.getElementById('advanceError').style.display = advanceTooHigh ? 'block' : 'none';
}


/* =====================================================================
   11. PROGRESS BAR -- "Form completion %"
   ===================================================================== */

// One boolean per meaningful step. The percentage is simply
// (how many are true) / (how many there are). Add or remove an item
// from this list to change what counts toward completion.
function updateProgress(){
  const stepsCompleted = [
    document.getElementById('custName').value.trim() !== '',
    /^03[0-9]{9}$/.test(document.getElementById('custPhone').value.trim()),
    document.getElementById('custLocation').value.trim() !== '',
    document.getElementById('eventDate').value !== '',
    selectedEventType !== '',
    (decorationMode === 'package' && !!selectedPackage) || (decorationMode === 'custom' && selectedCustomItems.length > 0),
    transportRequired === false || (transportRequired === true && !!selectedVehicle),
    selectedPaymentMethod !== '' && (selectedPaymentMethod === 'cash' || screenshotUploaded),
    selectedDeliveryMethods.size > 0
  ];

  const doneCount = stepsCompleted.filter(Boolean).length;
  const percent = Math.round((doneCount / stepsCompleted.length) * 100);

  document.getElementById('progressBar').style.width = percent + '%';
  document.getElementById('progressPercent').textContent = percent + '%';
}


/* =====================================================================
   12. VALIDATION -- runs once, when "Submit Booking" is pressed
   ===================================================================== */

function showFieldError(inputEl, errorEl, isInvalid, message){
  inputEl.classList.toggle('is-invalid', isInvalid);
  inputEl.classList.toggle('is-valid', !isInvalid);
  if (errorEl) {
    errorEl.textContent = isInvalid ? message : '';
    errorEl.style.display = isInvalid ? 'block' : 'none';
  }
}

function validateForm(){
  let isFormValid = true;

  const nameField = document.getElementById('custName');
  const phoneField = document.getElementById('custPhone');
  const locationField = document.getElementById('custLocation');
  const eventDateField = document.getElementById('eventDate');
  const startTimeField = document.getElementById('startTime');
  const endTimeField = document.getElementById('endTime');

  showFieldError(nameField, document.getElementById('custNameError'), nameField.value.trim() === '', 'Please enter your name.');
  if (nameField.value.trim() === '') isFormValid = false;

  const isPhoneInvalid = !/^03[0-9]{9}$/.test(phoneField.value.trim());
  showFieldError(phoneField, document.getElementById('custPhoneError'), isPhoneInvalid, 'Enter a valid 11-digit number (03XXXXXXXXX).');
  if (isPhoneInvalid) isFormValid = false;

  showFieldError(locationField, document.getElementById('custLocationError'), locationField.value.trim() === '', 'Please enter the event location.');
  if (locationField.value.trim() === '') isFormValid = false;

  // event date: required, and cannot be in the past
  let isDateInvalid = eventDateField.value === '';
  if (!isDateInvalid) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const chosenDate = new Date(eventDateField.value); chosenDate.setHours(0, 0, 0, 0);
    isDateInvalid = chosenDate < today;
  }
  showFieldError(eventDateField, document.getElementById('eventDateError'), isDateInvalid, 'Please select a valid event date (not in the past).');
  if (isDateInvalid) isFormValid = false;

  // end time must be after start time (only checked if both are filled in)
  if (startTimeField.value && endTimeField.value) {
    const isTimeInvalid = endTimeField.value <= startTimeField.value;
    showFieldError(endTimeField, document.getElementById('endTimeError'), isTimeInvalid, 'End time must be after start time.');
    if (isTimeInvalid) isFormValid = false;
  }

  if (!selectedEventType) {
    document.getElementById('eventTypeError').style.display = 'block';
    isFormValid = false;
  }

  if (decorationMode === 'package' && !selectedPackage) {
    document.getElementById('packageError').style.display = 'block';
    isFormValid = false;
  }
  const isCustomInvalid = decorationMode === 'custom' && selectedCustomItems.length === 0;
  document.getElementById('customError').style.display = isCustomInvalid ? 'block' : 'none';
  if (isCustomInvalid) isFormValid = false;

  if (transportRequired === null) {
    document.getElementById('transportRequiredError').style.display = 'block';
    isFormValid = false;
  }
  if (transportRequired === true && !selectedVehicle) {
    document.getElementById('vehicleError').style.display = 'block';
    isFormValid = false;
  }

  const grandTotal = parseInt(document.getElementById('grandTotal').textContent.replace(/[^\d]/g, '')) || 0;
  const advance = parseInt(document.getElementById('advancePayment').value) || 0;
  if (advance > grandTotal && grandTotal > 0) isFormValid = false;

  if (!selectedPaymentMethod) {
    document.getElementById('paymentError').style.display = 'block';
    isFormValid = false;
  } else if (selectedPaymentMethod !== 'cash' && !screenshotUploaded) {
    const screenshotErrorEl = document.getElementById('screenshotError');
    if (screenshotErrorEl) screenshotErrorEl.style.display = 'block';
    isFormValid = false;
  }

  if (selectedDeliveryMethods.size === 0) {
    document.getElementById('deliveryError').style.display = 'block';
    isFormValid = false;
  }

  return isFormValid;
}


/* =====================================================================
   13. SUBMIT -- sends booking to backend + shows Thank-You screen
   ===================================================================== */

async function submitBooking(){

    if (!validateForm()) {

        const firstProblem =
            document.querySelector(
                '.is-invalid, .error-text[style*="block"]'
            );

        if (firstProblem) {
            firstProblem.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }

        return;
    }


    // ============================================================
    // BUILD BOOKING DATA
    // ============================================================

    const bookingData = {

        // Customer information
        event_type:
            selectedEventType
                ? (
                    EVENT_TYPES.find(
                        e => e.id === selectedEventType
                    )?.name || ''
                )
                : '',

        event_date:
            document.getElementById('eventDate').value,

        customer_name:
            document.getElementById('custName').value.trim(),

        customer_phone:
            document.getElementById('custPhone').value.trim(),

        location:
            document.getElementById('custLocation').value.trim(),

        start_time:
            document.getElementById('startTime').value,

        end_time:
            document.getElementById('endTime').value,


        // Transport
        transport:
            transportRequired === true
                ? 'Yes'
                : 'No',


        // Payment
        payment_method:
            selectedPaymentMethod || 'Not selected',


        // ========================================================
        // BOOKING DETAILS
        // ========================================================

        decoration_mode:
            decorationMode,

        package_name:
            selectedPackage
                ? selectedPackage.name
                : '',

        package_price:
            selectedPackage
                ? selectedPackage.price
                : 0,

        custom_items:
            selectedCustomItems.map(item => ({
                name: item.name,
                price: item.price
            })),

        chair_quantity:
            chairQty,

        vehicle:
            selectedVehicle
                ? selectedVehicle.name
                : '',

        vehicle_price:
            selectedVehicle
                ? selectedVehicle.price
                : 0,


        // ========================================================
        // PAYMENT / TOTALS
        // ========================================================

        advance_payment:
            document.getElementById('advancePayment')
                ? document.getElementById('advancePayment').value
                : 0,

        grand_total:
            document.getElementById('grandTotal')
                ? document.getElementById('grandTotal').textContent
                : '',

        remaining_amount:
            document.getElementById('remainingAmount')
                ? document.getElementById('remainingAmount').textContent
                : '',


        // ========================================================
        // DELIVERY
        // ========================================================

        delivery_methods:
            Array.from(selectedDeliveryMethods)
    };


    console.log(
        "BOOKING DATA SENT:",
        bookingData
    );


    // ============================================================
    // SEND TO booking1.php
    // ============================================================

    try {

        const response = await fetch(
            "http://localhost/event-system/backend/booking1.php",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },

                credentials: "include",

                body: JSON.stringify(bookingData)
            }
        );


        const result =
            await response.json();


        console.log(
            "BOOKING BACKEND RESPONSE:",
            result
        );


        // ========================================================
        // BACKEND ERROR
        // ========================================================

        if (!result.success) {

            alert(
                "❌ " +
                (
                    result.error ||
                    "Booking could not be created."
                )
            );

            return;
        }


        // ========================================================
        // SUCCESS
        // ========================================================

        lastBookingId =
            "DEC-" +
            new Date().getFullYear() +
            "-" +
            String(result.event_id).padStart(4, "0");


        document.getElementById(
            'bookingRef'
        ).textContent =
            'Booking ID: ' + lastBookingId;


        document.getElementById(
            'thankYouGrandTotal'
        ).textContent =
            document.getElementById(
                'grandTotal'
            ).textContent;


        document.getElementById(
            'thankYouAdvance'
        ).textContent =
            document.getElementById(
                'sumAdvance'
            ).textContent;


        document.getElementById(
            'thankYouRemaining'
        ).textContent =
            document.getElementById(
                'sumRemaining'
            ).textContent;


        // ========================================================
        // HIDE BOOKING FORM
        // ========================================================

        document.getElementById(
            'bookingFormSection'
        ).style.display = 'none';


        // ========================================================
        // SHOW THANK-YOU SECTION
        // ========================================================

        document.getElementById(
            'thankYouSection'
        ).style.display = 'block';


        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });


    } catch (error) {

        console.error(
            "BOOKING SUBMISSION ERROR:",
            error
        );

        alert(
            "❌ Unable to connect to the booking server."
        );
    }
}

/* =====================================================================
   14. DOWNLOAD BILL (PDF) -- uses the jsPDF library loaded in the HTML
   ===================================================================== */

function downloadBill(){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const grandTotalText = document.getElementById('grandTotal').textContent;

  // header bar
  doc.setFillColor(122, 31, 61);
  doc.rect(0, 0, 210, 26, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.text('Dream Event Decoration - Booking Statement', 14, 13);
  doc.setFontSize(10);
  doc.text('Booking ID: ' + (lastBookingId || 'N/A'), 14, 20);

  let y = 36;
  function row(label, value){
    doc.setTextColor(30, 30, 30); doc.setFontSize(10);
    doc.text(`${label}:`, 14, y);
    doc.text(String(value), 80, y);
    y += 7;
  }
  function heading(text){
    doc.setFontSize(12); doc.setTextColor(122, 31, 61);
    doc.text(text, 14, y);
    y += 7;
  }

  heading('Customer Details');
  row('Name', document.getElementById('custName').value);
  row('Phone', document.getElementById('custPhone').value);
  row('Location', document.getElementById('custLocation').value);
  row('Event Date', document.getElementById('eventDate').value);
  row('Time', `${document.getElementById('startTime').value} - ${document.getElementById('endTime').value}`);
  y += 3;

  heading('Booking Details');
  row('Event Type', selectedEventType ? EVENT_TYPES.find(e => e.id === selectedEventType).name : '-');
  if (decorationMode === 'package' && selectedPackage) row('Package', `${selectedPackage.name} (Rs.${selectedPackage.price.toLocaleString()})`);
  if (decorationMode === 'custom') row('Custom Items', selectedCustomItems.map(item => item.name).join(', ') || 'None');
  if (chairQty) row('Chair Decoration', `${chairQty} x Rs.${CHAIR_PRICE} = Rs.${(chairQty * CHAIR_PRICE).toLocaleString()}`);
  row('Transport', (transportRequired === true && selectedVehicle) ? selectedVehicle.name : 'Not required');
  row('Payment Method', selectedPaymentMethod || '-');
  row('Advance Paid', document.getElementById('advancePayment').value || '0');
  row('Remaining Amount', document.getElementById('remainingAmount').textContent);
  y += 4;

  doc.setFontSize(13); doc.setTextColor(122, 31, 61);
  doc.text(`Grand Total: ${grandTotalText}`, 14, y);
  y += 14;

  doc.setFontSize(11); doc.setTextColor(46, 158, 109);
  doc.text('Thank you for choosing us!', 14, y);

  doc.save(`${lastBookingId || 'Booking'}.pdf`);
}


/* =====================================================================
   15. RESET / BACK
   ===================================================================== */

// Wipes every selection and puts the form back to its starting state.
function resetForm(){
  document.getElementById('bookingForm').reset();
  document.querySelectorAll('.active').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.is-invalid, .is-valid').forEach(el => el.classList.remove('is-invalid', 'is-valid'));
  document.querySelectorAll('.error-text').forEach(el => el.style.display = 'none');

  selectedEventType = '';
  decorationMode = 'package';
  selectedPackage = null;
  selectedCustomItems = [];
  chairQty = 0;
  transportRequired = null;
  selectedVehicle = null;
  selectedPaymentMethod = '';
  screenshotUploaded = false;
  selectedDeliveryMethods.clear();

  document.getElementById('packageRow').innerHTML = '';
  document.getElementById('vehicleRow').style.display = 'none';
  document.getElementById('paymentDetailPanel').innerHTML = '';

  setDecorationMode('package'); // also calls refreshEverything()
}

// "Back" button: if we're on the Thank-You screen, go back to a blank
// form. Otherwise, behave like a normal browser Back button.
function goBack(){
  const onThankYouScreen = document.getElementById('thankYouSection').style.display === 'block';
  if (onThankYouScreen) {
    document.getElementById('thankYouSection').style.display = 'none';
    document.getElementById('bookingFormSection').style.display = 'block';
    resetForm();
  } else {
    window.history.back();
  }
}


/* =====================================================================
   16. STARTUP -- wire everything together once the page has loaded
   ===================================================================== */
document.addEventListener('DOMContentLoaded', function(){
  renderEventTypes();
  renderCustomItems();
  renderVehicles();

  // Advance Payment box: recalculate Remaining Balance as the visitor types
  document.getElementById('advancePayment').addEventListener('input', refreshEverything);

  // Plain text/date/time fields: keep the progress bar accurate as the
  // visitor types (card clicks already call refreshEverything() directly)
  document.getElementById('bookingForm').addEventListener('input', updateProgress);
  document.getElementById('bookingForm').addEventListener('change', updateProgress);

  refreshEverything();
});
