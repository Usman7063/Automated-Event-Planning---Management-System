"use strict";

// =========================================================
// EVENT MANAGEMENT
// =========================================================
//
// Backend APIs:
//
// GET    get_events.php
// POST   add_event.php
// POST   update_event.php
// POST   delete_event.php
//
// Database fields:
//
// id
// user_id
// title
// event_type
// description
// client_name
// client_phone
// client_email
// event_date
// event_time
// location
// budget
// status
// created_at
// updated_at
// =========================================================


// =========================================================
// API ENDPOINTS
// =========================================================

const GET_EVENTS_API =
    "http://localhost/event-system/backend/admin/get_events.php";

const ADD_EVENT_API =
    "http://localhost/event-system/backend/admin/add_event.php";

const UPDATE_EVENT_API =
    "http://localhost/event-system/backend/admin/update_event.php";

const DELETE_EVENT_API =
    "http://localhost/event-system/backend/admin/delete_event.php";


// =========================================================
// GLOBAL EVENTS DATA
// =========================================================

let allEvents = [];


// =========================================================
// INITIALIZE
// =========================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        setupEventManagement();

    }
);


// =========================================================
// SETUP
// =========================================================

function setupEventManagement() {

    // -----------------------------------------------------
    // MOVE EVENT MODALS TO BODY
    // -----------------------------------------------------
    //
    // This is important.
    //
    // If a Bootstrap modal is inside a parent section/container
    // that has display:none, transform, overflow, or z-index,
    // Bootstrap's backdrop can cover the page while the modal
    // itself remains hidden.
    //
    // Moving the modals directly under <body> prevents that.
    // -----------------------------------------------------

    moveEventModalToBody(
        "addEventModal"
    );

    moveEventModalToBody(
        "editEventModal"
    );

    moveEventModalToBody(
        "viewEventModal"
    );


    // -----------------------------------------------------
    // ADD EVENT BUTTON
    // -----------------------------------------------------

    const addButton =
        document.getElementById(
            "addEventBtn"
        );

    if (addButton) {

        addButton.addEventListener(
            "click",
            openAddEventModal
        );

    }


    // -----------------------------------------------------
    // REFRESH BUTTON
    // -----------------------------------------------------

    const refreshButton =
        document.getElementById(
            "refreshEventsBtn"
        );

    if (refreshButton) {

        refreshButton.addEventListener(
            "click",
            loadEvents
        );

    }


    // -----------------------------------------------------
    // SEARCH
    // -----------------------------------------------------

    const searchInput =
        document.getElementById(
            "eventSearch"
        );

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterEvents
        );

    }


    // -----------------------------------------------------
    // EVENT TYPE FILTER
    // -----------------------------------------------------

    const eventTypeFilter =
        document.getElementById(
            "eventTypeFilter"
        );

    if (eventTypeFilter) {

        eventTypeFilter.addEventListener(
            "change",
            filterEvents
        );

    }


    // -----------------------------------------------------
    // STATUS FILTER
    // -----------------------------------------------------

    const statusFilter =
        document.getElementById(
            "eventStatusFilter"
        );

    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            filterEvents
        );

    }


    // -----------------------------------------------------
    // ADD FORM
    // -----------------------------------------------------

    const addForm =
        document.getElementById(
            "addEventForm"
        );

    if (addForm) {

        addForm.addEventListener(
            "submit",
            submitAddEvent
        );

    }


    // -----------------------------------------------------
    // EDIT FORM
    // -----------------------------------------------------

    const editForm =
        document.getElementById(
            "editEventForm"
        );

    if (editForm) {

        editForm.addEventListener(
            "submit",
            submitEditEvent
        );

    }


    // -----------------------------------------------------
    // MODAL CLEANUP
    // -----------------------------------------------------

    setupEventModalCleanup();


    // -----------------------------------------------------
    // LOAD EVENTS
    // -----------------------------------------------------

    loadEvents();

}


// =========================================================
// MOVE MODAL DIRECTLY UNDER BODY
// =========================================================

function moveEventModalToBody(
    modalId
) {

    const modal =
        document.getElementById(
            modalId
        );

    if (!modal) {

        return;

    }


    // Already directly inside body
    if (
        modal.parentElement ===
        document.body
    ) {

        return;

    }


    document.body.appendChild(
        modal
    );

}


// =========================================================
// MODAL CLEANUP
// =========================================================

function setupEventModalCleanup() {

    const modalIds = [
        "addEventModal",
        "editEventModal",
        "viewEventModal"
    ];


    modalIds.forEach(
        function (modalId) {

            const modalElement =
                document.getElementById(
                    modalId
                );

            if (!modalElement) {

                return;

            }


            modalElement.addEventListener(
                "hidden.bs.modal",
                function () {

                    cleanupBootstrapModal();

                }
            );

        }
    );

}


// =========================================================
// CLEAN BOOTSTRAP MODAL STATE
// =========================================================

function cleanupBootstrapModal() {

    // -----------------------------------------------------
    // Remove only leftover backdrops.
    //
    // This runs AFTER Bootstrap has finished closing.
    // -----------------------------------------------------

    document
        .querySelectorAll(
            ".modal-backdrop"
        )
        .forEach(
            function (backdrop) {

                backdrop.remove();

            }
        );


    // -----------------------------------------------------
    // Restore body
    // -----------------------------------------------------

    document.body.classList.remove(
        "modal-open"
    );

    document.body.style.removeProperty(
        "padding-right"
    );

    document.body.style.removeProperty(
        "overflow"
    );

}


// =========================================================
// LOAD EVENTS
// =========================================================

async function loadEvents() {

    const tableBody =
        document.getElementById(
            "eventsTableBody"
        );


    if (tableBody) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="9"
                    class="text-center py-5"
                >

                    <i
                        class="fa-solid fa-spinner fa-spin me-2"
                    ></i>

                    Loading events...

                </td>

            </tr>

        `;

    }


    try {

        const response =
            await fetch(
                GET_EVENTS_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "GET EVENTS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(
                    rawResponse
                );

        } catch (error) {

            throw new Error(
                "Events API returned invalid JSON."
            );

        }


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load events."
            );

        }


        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load events."
            );

        }


        allEvents =
            Array.isArray(
                data.events
            )
                ? data.events
                : [];


        updateEventStatistics(
            allEvents,
            data.statistics
        );


        filterEvents();


    } catch (error) {

        console.error(
            "LOAD EVENTS ERROR:",
            error
        );


        if (tableBody) {

            tableBody.innerHTML = `

                <tr>

                    <td
                        colspan="9"
                        class="text-center py-5 text-danger"
                    >

                        <i
                            class="fa-solid fa-circle-exclamation me-2"
                        ></i>

                        ${escapeEventHtml(
                            error.message ||
                            "Unable to load events."
                        )}

                    </td>

                </tr>

            `;

        }


        showEventError(
            error.message ||
            "Unable to load events."
        );

    }

}


// =========================================================
// UPDATE STATISTICS
// =========================================================

function updateEventStatistics(
    events,
    apiStatistics = null
) {

    // -----------------------------------------------------
    // MAKE SURE EVENTS IS AN ARRAY
    // -----------------------------------------------------

    if (!Array.isArray(events)) {

        events = [];

    }


    // -----------------------------------------------------
    // TOTAL
    // -----------------------------------------------------

    const total =
        events.length;


    // -----------------------------------------------------
    // TODAY
    // -----------------------------------------------------

    const today =
        new Date();

    today.setHours(
        0,
        0,
        0,
        0
    );


    // -----------------------------------------------------
    // COUNTERS
    // -----------------------------------------------------

    let upcoming = 0;

    let completed = 0;

    let cancelled = 0;

    let totalBudget = 0;


    // -----------------------------------------------------
    // PROCESS EVENTS
    // -----------------------------------------------------

    events.forEach(
        function (event) {

            if (!event) {
                return;
            }


            // =================================================
            // STATUS
            // =================================================

            const status =
                String(
                    event.status ||
                    ""
                )
                .trim()
                .toLowerCase();


            // =================================================
            // UPCOMING
            // =================================================

            if (event.event_date) {

                const eventDate =
                    new Date(
                        String(
                            event.event_date
                        ) +
                        "T00:00:00"
                    );


                if (
                    !Number.isNaN(
                        eventDate.getTime()
                    )
                ) {

                    if (
                        eventDate >= today &&
                        status !== "cancelled" &&
                        status !== "completed"
                    ) {

                        upcoming++;

                    }

                }

            }


            // =================================================
            // COMPLETED
            // =================================================

            if (
                status === "completed"
            ) {

                completed++;

            }


            // =================================================
            // CANCELLED
            // =================================================

            if (
                status === "cancelled"
            ) {

                cancelled++;

            }


            // =================================================
            // BUDGET
            // =================================================

            const budget =
                Number(
                    event.budget
                );


            if (
                Number.isFinite(
                    budget
                )
            ) {

                totalBudget +=
                    budget;

            }

        }
    );


    // =====================================================
    // UPDATE TOTAL EVENTS
    // =====================================================

    setEventText(
        "totalEvents",
        total
    );


    // =====================================================
    // UPDATE UPCOMING EVENTS
    // =====================================================

    setEventText(
        "upcomingEventsCount",
        upcoming
    );


    // =====================================================
    // UPDATE COMPLETED EVENTS
    // =====================================================

    setEventText(
        "completedEventsCount",
        completed
    );


    // =====================================================
    // UPDATE CANCELLED EVENTS
    // =====================================================

    setEventText(
        "cancelledEventsCount",
        cancelled
    );


    // =====================================================
    // UPDATE TOTAL BUDGET
    // =====================================================

    setEventText(
        "totalEventsBudget",
        formatEventMoney(
            totalBudget
        )
    );


    // =====================================================
    // DEBUG
    // =====================================================

    console.log(
        "EVENT STATISTICS:",
        {
            total: total,
            upcoming: upcoming,
            completed: completed,
            cancelled: cancelled,
            totalBudget: totalBudget
        }
    );

}


// =========================================================
// FILTER EVENTS
// =========================================================

function filterEvents() {

    const searchInput =
        document.getElementById(
            "eventSearch"
        );


    const eventTypeFilter =
        document.getElementById(
            "eventTypeFilter"
        );


    const statusFilter =
        document.getElementById(
            "eventStatusFilter"
        );


    const search =
        String(
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const selectedType =
        String(
            eventTypeFilter?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const selectedStatus =
        String(
            statusFilter?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const filtered =
        allEvents.filter(
            function (event) {

                const title =
                    String(
                        event.title ||
                        ""
                    ).toLowerCase();


                const clientName =
                    String(
                        event.client_name ||
                        ""
                    ).toLowerCase();


                const clientPhone =
                    String(
                        event.client_phone ||
                        ""
                    ).toLowerCase();


                const location =
                    String(
                        event.location ||
                        ""
                    ).toLowerCase();


                const userId =
                    String(
                        event.user_id ??
                        ""
                    ).toLowerCase();


                const eventType =
                    String(
                        event.event_type ||
                        ""
                    ).toLowerCase();


                const status =
                    String(
                        event.status ||
                        ""
                    ).toLowerCase();


                const matchesSearch =
                    !search ||
                    title.includes(search) ||
                    clientName.includes(search) ||
                    clientPhone.includes(search) ||
                    location.includes(search) ||
                    userId.includes(search) ||
                    eventType.includes(search);


                const matchesType =
                    !selectedType ||
                    selectedType === "all" ||
                    eventType ===
                        selectedType;


                const matchesStatus =
                    !selectedStatus ||
                    selectedStatus === "all" ||
                    status ===
                        selectedStatus;


                return (
                    matchesSearch &&
                    matchesType &&
                    matchesStatus
                );

            }
        );


    renderEvents(
        filtered
    );

}


// =========================================================
// RENDER EVENTS
// =========================================================

function renderEvents(
    events
) {

    const tableBody =
        document.getElementById(
            "eventsTableBody"
        );


    const emptyState =
        document.getElementById(
            "eventsEmptyState"
        );


    if (!tableBody) {

        return;

    }


    if (!events.length) {

        tableBody.innerHTML =
            "";


        if (emptyState) {

            emptyState.classList.remove(
                "d-none"
            );

        }

        return;

    }


    if (emptyState) {

        emptyState.classList.add(
            "d-none"
        );

    }


    tableBody.innerHTML =
        events
            .map(
                function (
                    event,
                    index
                ) {

                    const status =
                        String(
                            event.status ||
                            "pending"
                        ).toLowerCase();


                    return `

                        <tr>

                            <!-- NUMBER -->

                            <td>
                                ${index + 1}
                            </td>


                            <!-- EVENT -->

                            <td>

                                <div class="fw-semibold">

                                    ${escapeEventHtml(
                                        event.title ||
                                        "—"
                                    )}

                                </div>

                            </td>


                            <!-- CLIENT -->

                            <td>

                                <div>

                                    ${escapeEventHtml(
                                        event.client_name ||
                                        getClientFallback(
                                            event
                                        )
                                    )}

                                </div>

                                ${
                                    event.client_phone
                                        ? `
                                            <small class="text-muted">
                                                ${escapeEventHtml(
                                                    event.client_phone
                                                )}
                                            </small>
                                          `
                                        : ""
                                }

                            </td>


                            <!-- TYPE -->

                            <td>

                                ${escapeEventHtml(
                                    event.event_type ||
                                    "—"
                                )}

                            </td>


                            <!-- DATE -->

                            <td>

                                ${formatEventDate(
                                    event.event_date
                                )}

                                ${
                                    event.event_time
                                        ? `
                                            <div class="small text-muted">
                                                ${escapeEventHtml(
                                                    event.event_time
                                                )}
                                            </div>
                                          `
                                        : ""
                                }

                            </td>


                            <!-- LOCATION -->

                            <td>

                                ${escapeEventHtml(
                                    event.location ||
                                    "—"
                                )}

                            </td>


                            <!-- BUDGET -->

                            <td>

                                <span class="fw-semibold">

                                    ${formatEventMoney(
                                        event.budget
                                    )}

                                </span>

                            </td>


                            <!-- STATUS -->

                            <td>

                                ${getStatusBadge(
                                    status
                                )}

                            </td>


                            <!-- ACTIONS -->

                            <td>

                                <div class="d-flex gap-1">

                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-primary"
                                        onclick="viewEvent(${Number(event.id)})"
                                        title="View Event"
                                    >

                                        <i
                                            class="fa-solid fa-eye"
                                        ></i>

                                    </button>


                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-warning"
                                        onclick="openEditEventModal(${Number(event.id)})"
                                        title="Edit Event"
                                    >

                                        <i
                                            class="fa-solid fa-pen"
                                        ></i>

                                    </button>


                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-danger"
                                        onclick="deleteEvent(${Number(event.id)})"
                                        title="Delete Event"
                                    >

                                        <i
                                            class="fa-solid fa-trash"
                                        ></i>

                                    </button>

                                </div>

                            </td>

                        </tr>

                    `;

                }
            )
            .join("");

}


// =========================================================
// CLIENT FALLBACK
// =========================================================

function getClientFallback(
    event
) {

    if (
        event.user_id !== null &&
        event.user_id !== undefined &&
        event.user_id !== ""
    ) {

        return (
            "User #" +
            event.user_id
        );

    }


    return "—";

}


// =========================================================
// STATUS BADGE
// =========================================================

function getStatusBadge(
    status
) {

    const cleanStatus =
        String(
            status ||
            "pending"
        ).toLowerCase();


    let badgeClass =
        "bg-secondary";


    if (
        cleanStatus ===
        "confirmed"
    ) {

        badgeClass =
            "bg-primary";

    }


    if (
        cleanStatus ===
        "completed"
    ) {

        badgeClass =
            "bg-success";

    }


    if (
        cleanStatus ===
        "cancelled"
    ) {

        badgeClass =
            "bg-danger";

    }


    if (
        cleanStatus ===
        "pending"
    ) {

        badgeClass =
            "bg-warning text-dark";

    }


    return `

        <span class="badge ${badgeClass}">

            ${escapeEventHtml(
                capitalizeFirstLetter(
                    cleanStatus
                )
            )}

        </span>

    `;

}


// =========================================================
// VIEW EVENT
// =========================================================

function viewEvent(
    eventId
) {

    const event =
        findEventById(
            eventId
        );


    if (!event) {

        showEventError(
            "Event could not be found."
        );

        return;

    }


    // -----------------------------------------------------
    // EVENT INFORMATION
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventTitle",
        event.title
    );


    setEventViewValue(
        "viewEventType",
        event.event_type
    );


    setEventViewValue(
        "viewEventDescription",
        event.description
    );


    // -----------------------------------------------------
    // CLIENT
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventClientName",
        event.client_name
    );


    setEventViewValue(
        "viewEventClientPhone",
        event.client_phone
    );


    setEventViewValue(
        "viewEventClientEmail",
        event.client_email
    );


    // -----------------------------------------------------
    // DATE / TIME / LOCATION
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventDate",
        formatEventDate(
            event.event_date
        )
    );


    setEventViewValue(
        "viewEventTime",
        event.event_time
    );


    setEventViewValue(
        "viewEventLocation",
        event.location
    );


    // -----------------------------------------------------
    // PRICING / STATUS
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventPrice",
        formatEventMoney(
            event.budget
        )
    );


    setEventViewValue(
        "viewEventStatus",
        event.status
            ? capitalizeFirstLetter(
                event.status
            )
            : "Pending"
    );


    // -----------------------------------------------------
    // EVENT ID
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventId",
        event.id
    );


    // -----------------------------------------------------
    // USER ID
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventUserId",
        event.user_id
    );


    // -----------------------------------------------------
    // RECORD INFORMATION
    // -----------------------------------------------------

    setEventViewValue(
        "viewEventCreatedAt",
        event.created_at
    );


    setEventViewValue(
        "viewEventUpdatedAt",
        event.updated_at
    );


    // -----------------------------------------------------
    // OPEN
    // -----------------------------------------------------

    showEventModal(
        "viewEventModal"
    );

}


// =========================================================
// OPEN ADD EVENT MODAL
// =========================================================

function openAddEventModal() {

    const form =
        document.getElementById(
            "addEventForm"
        );


    if (form) {

        form.reset();

    }


    showEventModal(
        "addEventModal"
    );

}


// =========================================================
// SUBMIT ADD EVENT
// =========================================================

async function submitAddEvent(
    event
) {

    event.preventDefault();


    const form =
        event.currentTarget;


    const button =
        document.getElementById(
            "saveEventBtn"
        );


    if (!form) {

        return;

    }


    if (button) {

        button.disabled =
            true;


        button.innerHTML = `

            <i
                class="fa-solid fa-spinner fa-spin me-1"
            ></i>

            Adding...

        `;

    }


    try {

        const formData =
            new FormData();


        // -------------------------------------------------
        // USER
        // -------------------------------------------------

        formData.append(
            "user_id",
            getFormValue(
                form,
                "user_id",
                "eventUserId"
            )
        );


        // -------------------------------------------------
        // TITLE
        // -------------------------------------------------

        formData.append(
            "title",
            getFormValue(
                form,
                "name",
                "eventName"
            )
        );


        // -------------------------------------------------
        // EVENT TYPE
        // -------------------------------------------------

        formData.append(
            "event_type",
            getFormValue(
                form,
                "event_type",
                "eventType"
            )
        );


        // -------------------------------------------------
        // DESCRIPTION
        // -------------------------------------------------

        formData.append(
            "description",
            getFormValue(
                form,
                "description",
                "eventDescription"
            )
        );


        // -------------------------------------------------
        // CLIENT
        // -------------------------------------------------

        formData.append(
            "client_name",
            getFormValue(
                form,
                "client_name",
                "eventClientName"
            )
        );


        formData.append(
            "client_phone",
            getFormValue(
                form,
                "client_phone",
                "eventClientPhone"
            )
        );


        formData.append(
            "client_email",
            getFormValue(
                form,
                "client_email",
                "eventClientEmail"
            )
        );


        // -------------------------------------------------
        // DATE
        // -------------------------------------------------

        formData.append(
            "event_date",
            getFormValue(
                form,
                "event_date",
                "eventDate"
            )
        );


        // -------------------------------------------------
        // TIME
        // -------------------------------------------------

        formData.append(
            "event_time",
            getFormValue(
                form,
                "event_time",
                "eventTime"
            )
        );


        // -------------------------------------------------
        // LOCATION
        // -------------------------------------------------

        formData.append(
            "location",
            getFormValue(
                form,
                "location",
                "eventLocation"
            )
        );


        // -------------------------------------------------
        // BUDGET
        // -------------------------------------------------

        formData.append(
            "budget",
            getFormValue(
                form,
                "budget",
                "eventBudget"
            )
        );


        // -------------------------------------------------
        // STATUS
        // -------------------------------------------------

        formData.append(
            "status",
            getFormValue(
                form,
                "status",
                "eventStatus"
            ) ||
            "pending"
        );


        console.log(
            "ADD EVENT FORM DATA:",
            Object.fromEntries(
                formData.entries()
            )
        );


        // -------------------------------------------------
        // REQUEST
        // -------------------------------------------------

        const response =
            await fetch(
                ADD_EVENT_API,
                {
                    method: "POST",

                    credentials: "include",

                    body: formData
                }
            );


        const data =
            await parseJsonResponse(
                response,
                "Add Event"
            );


        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.error ||
                "Unable to add event."
            );

        }


        // -------------------------------------------------
        // SUCCESS
        // -------------------------------------------------

        showEventSuccess(
            "Event added successfully."
        );


        // -------------------------------------------------
        // CLOSE
        // -------------------------------------------------

        closeEventModal(
            "addEventModal"
        );


        // -------------------------------------------------
        // RELOAD
        // -------------------------------------------------

        await loadEvents();


    } catch (error) {

        console.error(
            "ADD EVENT ERROR:",
            error
        );


        showEventError(
            error.message ||
            "Unable to add event."
        );


    } finally {

        if (button) {

            button.disabled =
                false;


            button.innerHTML = `

                <i
                    class="fa-solid fa-plus me-1"
                ></i>

                Add Event

            `;

        }

    }

}


// =========================================================
// OPEN EDIT EVENT MODAL
// =========================================================

function openEditEventModal(
    eventId
) {

    console.log(
        "EDIT EVENT ID:",
        eventId
    );


    // -----------------------------------------------------
    // FIND EVENT
    // -----------------------------------------------------

    const eventData =
        findEventById(
            eventId
        );


    console.log(
        "EDIT EVENT OBJECT:",
        eventData
    );


    if (!eventData) {

        showEventError(
            "Event could not be found."
        );

        return;

    }


    // -----------------------------------------------------
    // MODAL
    // -----------------------------------------------------

    const modalElement =
        document.getElementById(
            "editEventModal"
        );


    if (!modalElement) {

        console.error(
            "editEventModal was not found."
        );

        return;

    }


    // =====================================================
    // FILL FORM
    // =====================================================

    setEventInputValue(
        "editEventId",
        eventData.id ?? ""
    );


    // -----------------------------------------------------
    // USER ID
    // -----------------------------------------------------

    setEventInputValue(
        "editEventUserId",
        eventData.user_id ?? ""
    );


    // -----------------------------------------------------
    // TITLE
    // -----------------------------------------------------

    setEventInputValue(
        "editEventTitle",
        eventData.title ?? ""
    );


    // -----------------------------------------------------
    // EVENT TYPE
    // -----------------------------------------------------

    setEventInputValue(
        "editEventType",
        eventData.event_type ?? ""
    );


    // -----------------------------------------------------
    // DESCRIPTION
    // -----------------------------------------------------

    setEventInputValue(
        "editEventDescription",
        eventData.description ?? ""
    );


    // -----------------------------------------------------
    // CLIENT NAME
    // -----------------------------------------------------

    setEventInputValue(
        "editEventClientName",
        eventData.client_name ?? ""
    );


    // -----------------------------------------------------
    // PHONE
    // -----------------------------------------------------

    setEventInputValue(
        "editEventClientPhone",
        eventData.client_phone ?? ""
    );


    // -----------------------------------------------------
    // EMAIL
    // -----------------------------------------------------

    setEventInputValue(
        "editEventClientEmail",
        eventData.client_email ?? ""
    );


    // -----------------------------------------------------
    // DATE
    // -----------------------------------------------------

    setEventInputValue(
        "editEventDate",
        eventData.event_date ?? ""
    );


    // -----------------------------------------------------
    // TIME
    // -----------------------------------------------------

    setEventInputValue(
        "editEventTime",
        normalizeEventTime(
            eventData.event_time
        )
    );


    // -----------------------------------------------------
    // LOCATION
    // -----------------------------------------------------

    setEventInputValue(
        "editEventLocation",
        eventData.location ?? ""
    );


    // -----------------------------------------------------
    // BUDGET
    // -----------------------------------------------------
    //
    // IMPORTANT:
    // The current admin.html uses editEventBudget.
    // Do NOT use editEventPrice here.
    // -----------------------------------------------------

    setEventInputValue(
        "editEventBudget",
        eventData.budget ?? ""
    );


    // -----------------------------------------------------
    // STATUS
    // -----------------------------------------------------

    setEventInputValue(
        "editEventStatus",
        eventData.status ??
        "pending"
    );


    // -----------------------------------------------------
    // SHOW MODAL
    // -----------------------------------------------------

    showEventModal(
        "editEventModal"
    );

}


// =========================================================
// NORMALIZE TIME
// =========================================================

function normalizeEventTime(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "";

    }


    const text =
        String(
            value
        );


    // MySQL TIME may be HH:MM:SS
    if (
        text.length >= 5
    ) {

        return text.substring(
            0,
            5
        );

    }


    return text;

}


// =========================================================
// SUBMIT EDIT EVENT
// =========================================================

async function submitEditEvent(
    event
) {

    event.preventDefault();


    const form =
        event.currentTarget;


    const button =
        document.getElementById(
            "updateEventBtn"
        );


    if (!form) {

        return;

    }


    if (button) {

        button.disabled =
            true;


        button.innerHTML = `

            <i
                class="fa-solid fa-spinner fa-spin me-1"
            ></i>

            Saving...

        `;

    }


    try {

        const formData =
            new FormData();


        // =================================================
        // EVENT ID
        // =================================================

        const eventId =
            getFormValue(
                form,
                "event_id",
                "editEventId"
            );


        if (!eventId) {

            throw new Error(
                "Event ID is missing."
            );

        }


        formData.append(
            "event_id",
            eventId
        );


        // =================================================
        // USER ID
        // =================================================
        //
        // user_id is nullable in your events table.
        // Therefore an empty value is allowed here.
        // =================================================

        const userId =
            getFormValue(
                form,
                "user_id",
                "editEventUserId"
            );


        formData.append(
            "user_id",
            userId
        );


        // =================================================
        // TITLE
        // =================================================

        formData.append(
            "title",
            getFormValue(
                form,
                "title",
                "editEventTitle"
            )
        );


        // =================================================
        // EVENT TYPE
        // =================================================

        formData.append(
            "event_type",
            getFormValue(
                form,
                "event_type",
                "editEventType"
            )
        );


        // =================================================
        // DESCRIPTION
        // =================================================

        formData.append(
            "description",
            getFormValue(
                form,
                "description",
                "editEventDescription"
            )
        );


        // =================================================
        // CLIENT NAME
        // =================================================

        formData.append(
            "client_name",
            getFormValue(
                form,
                "client_name",
                "editEventClientName"
            )
        );


        // =================================================
        // CLIENT PHONE
        // =================================================

        formData.append(
            "client_phone",
            getFormValue(
                form,
                "client_phone",
                "editEventClientPhone"
            )
        );


        // =================================================
        // CLIENT EMAIL
        // =================================================

        formData.append(
            "client_email",
            getFormValue(
                form,
                "client_email",
                "editEventClientEmail"
            )
        );


        // =================================================
        // DATE
        // =================================================

        formData.append(
            "event_date",
            getFormValue(
                form,
                "event_date",
                "editEventDate"
            )
        );


        // =================================================
        // TIME
        // =================================================

        formData.append(
            "event_time",
            getFormValue(
                form,
                "event_time",
                "editEventTime"
            )
        );


        // =================================================
        // LOCATION
        // =================================================

        formData.append(
            "location",
            getFormValue(
                form,
                "location",
                "editEventLocation"
            )
        );


        // =================================================
        // BUDGET
        // =================================================

        formData.append(
            "budget",
            getFormValue(
                form,
                "budget",
                "editEventBudget"
            )
        );


        // =================================================
        // STATUS
        // =================================================

        formData.append(
            "status",
            getFormValue(
                form,
                "status",
                "editEventStatus"
            ) ||
            "pending"
        );


        // =================================================
        // DEBUG
        // =================================================

        console.log(
            "UPDATE EVENT FORM DATA:"
        );


        for (
            const [
                key,
                value
            ]
            of formData.entries()
        ) {

            console.log(
                key + ":",
                value
            );

        }


        // =================================================
        // SEND REQUEST
        // =================================================

        const response =
            await fetch(
                UPDATE_EVENT_API,
                {
                    method: "POST",

                    credentials: "include",

                    body: formData
                }
            );


        // =================================================
        // RESPONSE
        // =================================================

        const data =
            await parseJsonResponse(
                response,
                "Update Event"
            );


        // =================================================
        // CHECK
        // =================================================

        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.error ||
                "Unable to update event."
            );

        }


        // =================================================
        // SUCCESS
        // =================================================

        showEventSuccess(
            "Event updated successfully."
        );


        // =================================================
        // CLOSE MODAL
        // =================================================

        closeEventModal(
            "editEventModal"
        );


        // =================================================
        // RELOAD
        // =================================================

        await loadEvents();


    } catch (error) {

        console.error(
            "UPDATE EVENT ERROR:",
            error
        );


        showEventError(
            error.message ||
            "Unable to update event."
        );


    } finally {

        if (button) {

            button.disabled =
                false;


            button.innerHTML = `

                <i
                    class="fa-solid fa-save me-1"
                ></i>

                Save Changes

            `;

        }

    }

}


// =========================================================
// DELETE EVENT
// =========================================================

async function deleteEvent(
    eventId
) {

    const event =
        findEventById(
            eventId
        );


    if (!event) {

        showEventError(
            "Event could not be found."
        );

        return;

    }


    const eventTitle =
        event.title ||
        "this event";


    const confirmed =
        window.confirm(
            "Are you sure you want to delete this event?\n\n" +
            eventTitle
        );


    if (!confirmed) {

        return;

    }


    try {

        const formData =
            new FormData();


        formData.append(
            "event_id",
            eventId
        );


        const response =
            await fetch(
                DELETE_EVENT_API,
                {
                    method: "POST",

                    credentials: "include",

                    body: formData
                }
            );


        const data =
            await parseJsonResponse(
                response,
                "Delete Event"
            );


        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.error ||
                "Unable to delete event."
            );

        }


        showEventSuccess(
            "Event deleted successfully."
        );


        await loadEvents();


    } catch (error) {

        console.error(
            "DELETE EVENT ERROR:",
            error
        );


        showEventError(
            error.message ||
            "Unable to delete event."
        );

    }

}


// =========================================================
// FIND EVENT
// =========================================================

function findEventById(
    eventId
) {

    return allEvents.find(
        function (event) {

            return (
                Number(event.id) ===
                Number(eventId)
            );

        }
    );

}


// =========================================================
// SHOW EVENT MODAL
// =========================================================

function showEventModal(
    modalId
) {

    const modalElement =
        document.getElementById(
            modalId
        );


    if (!modalElement) {

        console.error(
            modalId +
            " was not found."
        );

        return;

    }


    if (
        typeof bootstrap ===
        "undefined" ||
        !bootstrap.Modal
    ) {

        console.error(
            "Bootstrap JavaScript is not loaded."
        );

        return;

    }


    // -----------------------------------------------------
    // Make absolutely sure modal is directly under body.
    // -----------------------------------------------------

    if (
        modalElement.parentElement !==
        document.body
    ) {

        document.body.appendChild(
            modalElement
        );

    }


    // -----------------------------------------------------
    // Get existing Bootstrap instance
    // -----------------------------------------------------

    let modal =
        bootstrap.Modal.getInstance(
            modalElement
        );


    // -----------------------------------------------------
    // If there is an existing instance,
    // dispose it before recreating it.
    // -----------------------------------------------------

    if (modal) {

        modal.dispose();

    }


    // -----------------------------------------------------
    // Create fresh instance
    // -----------------------------------------------------

    modal =
        new bootstrap.Modal(
            modalElement,
            {
                backdrop: true,
                keyboard: true,
                focus: true
            }
        );


    // -----------------------------------------------------
    // Show
    // -----------------------------------------------------

    modal.show();

}


// =========================================================
// OPEN BOOTSTRAP MODAL
// =========================================================
//
// Kept for compatibility with any existing admin code.
// =========================================================

function openBootstrapModal(
    modalId
) {

    showEventModal(
        modalId
    );

}


// =========================================================
// CLOSE EVENT MODAL
// =========================================================

function closeEventModal(
    modalId
) {

    const modalElement =
        document.getElementById(
            modalId
        );


    if (!modalElement) {

        return;

    }


    if (
        typeof bootstrap ===
        "undefined" ||
        !bootstrap.Modal
    ) {

        return;

    }


    const modal =
        bootstrap.Modal.getInstance(
            modalElement
        );


    if (modal) {

        modal.hide();

    } else {

        cleanupBootstrapModal();

    }

}


// =========================================================
// GET FORM VALUE
// =========================================================
//
// Supports:
//
// name="field"
//
// OR
//
// id="fieldId"
// =========================================================

function getFormValue(
    form,
    name,
    id
) {

    if (!form) {

        return "";

    }


    // -----------------------------------------------------
    // Try name first
    // -----------------------------------------------------

    const byName =
        form.elements.namedItem(
            name
        );


    if (
        byName &&
        typeof byName.value !==
            "undefined"
    ) {

        return String(
            byName.value
        ).trim();

    }


    // -----------------------------------------------------
    // Try ID
    // -----------------------------------------------------

    const byId =
        document.getElementById(
            id
        );


    if (
        byId &&
        typeof byId.value !==
            "undefined"
    ) {

        return String(
            byId.value
        ).trim();

    }


    return "";

}


// =========================================================
// SET VIEW VALUE
// =========================================================

function setEventViewValue(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return;

    }


    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        element.textContent =
            "—";

        return;

    }


    element.textContent =
        value;

}


// =========================================================
// SET INPUT VALUE
// =========================================================

function setEventInputValue(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        console.warn(
            "Edit event field not found:",
            id
        );

        return;

    }


    element.value =
        value ?? "";

}


// =========================================================
// SET TEXT
// =========================================================

function setEventText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return;

    }


    element.textContent =
        value;

}


// =========================================================
// FORMAT MONEY
// =========================================================

function formatEventMoney(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "PKR 0";

    }


    const number =
        Number(
            value
        );


    if (
        Number.isNaN(
            number
        )
    ) {

        return String(
            value
        );

    }


    return (
        "PKR " +
        number.toLocaleString(
            "en-PK",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }
        )
    );

}




// =========================================================
// FORMAT DATE
// =========================================================

function formatEventDate(
    value
) {

    if (!value) {

        return "—";

    }


    const date =
        new Date(
            value +
            "T00:00:00"
        );


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return String(
            value
        );

    }


    return date.toLocaleDateString(
        "en-PK",
        {
            year: "numeric",
            month: "short",
            day: "numeric"
        }
    );

}


// =========================================================
// ESCAPE HTML
// =========================================================

function escapeEventHtml(
    value
) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =========================================================
// CAPITALIZE
// =========================================================

function capitalizeFirstLetter(
    value
) {

    const text =
        String(
            value ||
            ""
        );


    if (!text) {

        return "";

    }


    return (
        text.charAt(0).toUpperCase() +
        text.slice(1)
    );

}


// =========================================================
// PARSE JSON RESPONSE
// =========================================================

async function parseJsonResponse(
    response,
    apiName
) {

    const rawResponse =
        await response.text();


    console.log(
        apiName.toUpperCase() +
        " RESPONSE:",
        rawResponse
    );


    let data;


    try {

        data =
            JSON.parse(
                rawResponse
            );

    } catch (error) {

        console.error(
            apiName +
            " RAW RESPONSE:",
            rawResponse
        );


        throw new Error(
            apiName +
            " API returned invalid JSON."
        );

    }


    return data;

}


// =========================================================
// SUCCESS MESSAGE
// =========================================================

function showEventSuccess(
    message
) {

    if (
        typeof showToast ===
        "function"
    ) {

        showToast(
            message,
            "success"
        );

    }

}


// =========================================================
// ERROR MESSAGE
// =========================================================

function showEventError(
    message
) {

    if (
        typeof showToast ===
        "function"
    ) {

        showToast(
            message,
            "error"
        );

    } else {

        alert(
            message
        );

    }

}
