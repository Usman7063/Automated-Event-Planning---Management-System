/*=========================================================
    Hassan Tent Service
    app.js
    PART-1
=========================================================*/


document.addEventListener("DOMContentLoaded", function(){
// ============================================================
// AUTO-FILL LOGGED-IN USER DATA
// ============================================================

function autofillLoggedInUser() {

    const storedUser =
        localStorage.getItem("loggedInUser");

    // Do nothing if visitor is not logged in
    if (!storedUser) {
        return;
    }

    let user;

    try {

        user = JSON.parse(storedUser);

    } catch (error) {

        console.error(
            "Invalid logged-in user data:",
            error
        );

        return;
    }

    if (!user) {
        return;
    }


    // Get existing booking fields

    const fullName =
        document.getElementById("fullName");

    const email =
        document.getElementById("email");

    const mobile =
        document.getElementById("mobile");

    const cnic =
        document.getElementById("cnic");


    // Automatically fill user information

    if (fullName && user.full_name) {

        fullName.value =
            user.full_name;

    }

    if (email && user.email) {

        email.value =
            user.email;

    }

    if (mobile && user.phone) {

        mobile.value =
            user.phone;

    }

    if (cnic && user.cnic) {

        cnic.value =
            user.cnic;

    }


    console.log(
        "✅ Logged-in user data automatically filled."
    );
}


// Run autofill

autofillLoggedInUser();


// =====================================
// Global Elements
// =====================================

const rows = document.querySelectorAll("tbody tr");

const grandTotal = document.getElementById("grandTotal");

const searchInput = document.getElementById("searchItem");

const summaryList = document.getElementById("summaryList");

const liveGrandTotal = document.getElementById("liveGrandTotal");




// =====================================
// Stock Data
// =====================================

const stock = {


    chair_qaum:300,
    chair_parachute:200,
    chair_cover:300,


    table_round:50,
    table_square:30,
    table_cover:50,


    plate_big:500,
    plate_small:500,


    food_spoon:500,


    dish:100,
    donga:50,


    dish_spoon:100,
    donga_spoon:50,


    parat:20,
    parat_spoon:20,


    jug_steel:30,
    glass_steel:300,


    jug_glass:20,
    glass_glass:200,


    canopy:10,
    shamiana:10,
    qanat:100,


    carpet:50,
    qahwa_tanki:5,


    hammam:5,
    tarpaal:20,


    bamboo:100,
    rope:100,


    kali:50,
    choway:50,


    jazeer:20,
    takht_posh:30


};





// =====================================
// PART-1B (NEW)
// Packages Data
// =====================================
// Only the "quantities" for each package are written here.
// The price is auto-calculated from the rate in the items table below —
// so if an item's rate ever changes, the package price will
// automatically update — no separate change needed.
// =====================================

const packageCards =
document.querySelectorAll(".package-card");

const selectedPackageInfo =
document.getElementById("selectedPackageInfo");

const selectedPackageName =
document.getElementById("selectedPackageName");

const selectedPackagePrice =
document.getElementById("selectedPackagePrice");

let currentPackage = "";


// =====================================
// Get an item's current rate from the table
// =====================================

function getItemRate(stockKey){

    const qtyInput =
    document.querySelector(`[data-stock="${stockKey}"]`);

    if(!qtyInput) return 0;

    const row =
    qtyInput.closest("tr");

    if(!row) return 0;

    const rateInput =
    row.querySelector(".rate");

    return rateInput ? (Number(rateInput.value) || 0) : 0;

}


// =====================================
// Total package price (Auto Calculate)
// =====================================

function calculatePackagePrice(items){

    let total = 0;

    Object.keys(items).forEach(function(key){

        const qty = items[key];
        const rate = getItemRate(key);

        total += qty * rate;

    });

    return total;

}


// =====================================
// Show all package prices as soon as the page loads
// =====================================

function renderPackagePrices(){

    packageCards.forEach(function(card){

        const items =
        JSON.parse(card.dataset.items || "{}");

        // The Custom card should not show a fixed price
        if(card.dataset.package === "custom") return;

        const price =
        calculatePackagePrice(items);

        const priceTag =
        card.querySelector(".package-price");

        if(priceTag){

            priceTag.innerHTML =
            "Rs. " + price.toLocaleString("en-PK");

        }

    });

}


// =====================================
// When a package is selected — its item quantities
// are automatically filled into the table below
// =====================================

function applyPackage(card){

    const items =
    JSON.parse(card.dataset.items || "{}");

    const pkgKey =
    card.dataset.package;

    // ================================
    // First remove "active" from all package cards
    // ================================

    packageCards.forEach(function(c){

        c.classList.remove("active");

    });

    card.classList.add("active");

    currentPackage = pkgKey;

    // ================================
    // Custom means no package —
    // Don't touch the current quantities, just show the selection
    // ================================

    if(pkgKey === "custom"){

        if(selectedPackageInfo){
            selectedPackageInfo.classList.add("d-none");
        }

        localStorage.setItem("selectedPackage", "");
        localStorage.setItem("packageName", "");
        localStorage.setItem("packagePrice", "0");

        updateFormProgress();

        return;

    }

    // ================================
    // Fill each item's quantity from the package into the table
    // (find the matching input via data-stock, set its value
    // and fire the input event so the existing calculation engine
    // (validateStock → updateLinkedItems → updateRow) runs automatically)
    // ================================

    Object.keys(items).forEach(function(key){

        const qtyInput =
        document.querySelector(`[data-stock="${key}"]`);

        if(!qtyInput) return;

        qtyInput.value = items[key];

        qtyInput.dispatchEvent(new Event("input"));

    });

    // ================================
    // Show + save the selected package info
    // ================================

    const price =
    calculatePackagePrice(items);

    const pkgTitle =
    card.querySelector("h5") ? card.querySelector("h5").innerText.trim() : pkgKey;

    if(selectedPackageInfo){
        selectedPackageInfo.classList.remove("d-none");
    }

    if(selectedPackageName){
        selectedPackageName.innerText = pkgTitle;
    }

    if(selectedPackagePrice){
        selectedPackagePrice.innerText =
        "Rs. " + price.toLocaleString("en-PK");
    }

    localStorage.setItem("selectedPackage", pkgKey);
    localStorage.setItem("packageName", pkgTitle);
    localStorage.setItem("packagePrice", price.toString());

    updateFormProgress();

}


// =====================================
// Click on package card / button
// =====================================

packageCards.forEach(function(card){

    card.addEventListener("click", function(){

        applyPackage(card);

    });

});


// =====================================
// PART-1C (NEW)
// Form Completion Progress Bar
// =====================================
// This function checks whether the required fields are filled,
// and updates the Progress Bar at the top accordingly.
// It is also called at the end of calculateGrandTotal()
// so the bar also updates automatically when items are selected.
// =====================================

const formProgressBar =
document.getElementById("formProgressBar");

const formProgressPercent =
document.getElementById("formProgressPercent");

function updateFormProgress(){

    if(!formProgressBar) return;

    // ================================
    // List of required fields
    // ================================

    const requiredFieldIds = [
        "customerName",
        "customerPhone",
        "eventType",
        "eventDate",
        "customerAddress"
    ];

    let totalSteps = requiredFieldIds.length + 2;
    // +2 = (1) at least one item/package must be selected
    //      (2) agreeing to the terms and conditions

    let doneSteps = 0;

    requiredFieldIds.forEach(function(id){

        const field = document.getElementById(id);

        if(field && field.value && field.value.trim() !== ""){
            doneSteps++;
        }

    });

    // ================================
    // Whether at least one item is selected
    // ================================

    let anyItemSelected = false;

    document.querySelectorAll(".qty").forEach(function(input){

        if((Number(input.value) || 0) > 0){
            anyItemSelected = true;
        }

    });

    if(anyItemSelected) doneSteps++;

    // ================================
    // Terms and conditions
    // ================================

    const agreeTerms =
    document.getElementById("agreeTerms");

    if(agreeTerms && agreeTerms.checked){
        doneSteps++;
    }

    // ================================
    // Update the Progress Bar
    // ================================

    const percent =
    Math.min(100, Math.round((doneSteps / totalSteps) * 100));

    formProgressBar.style.width = percent + "%";
    formProgressBar.setAttribute("aria-valuenow", percent);

    if(formProgressPercent){
        formProgressPercent.innerText = percent + "%";
    }

}

// Live update on required fields too
["customerName","customerPhone","eventType","eventDate","customerAddress","agreeTerms"]
.forEach(function(id){

    const field = document.getElementById(id);

    if(field){

        field.addEventListener("input", updateFormProgress);
        field.addEventListener("change", updateFormProgress);

    }

});


// =====================================
// Calculate One Row
// =====================================

function calculateRow(row){


    const qtyInput =
    row.querySelector(".qty");


    const rateInput =
    row.querySelector(".rate");


    const amountInput =
    row.querySelector(".amount");



    if(!qtyInput || !rateInput || !amountInput)
    return;



    const qty =
    Number(qtyInput.value) || 0;



    const rate =
    Number(rateInput.value) || 0;



    amountInput.value =
    qty * rate;



}

// =====================================
// Grand Total
// =====================================

function calculateGrandTotal(){

    let itemsTotal = 0;

    // ============================
    // Calculate Items Total
    // ============================

    document.querySelectorAll(".amount").forEach(function(input){

        itemsTotal += Number(input.value) || 0;

    });

    // ============================
    // Vehicle Charges
    // ============================

    let vehiclePrice =
    Number(localStorage.getItem("vehiclePrice")) || 0;

    // ============================
    // Final Total
    // ============================

    let finalTotal =
    itemsTotal + vehiclePrice;

    // ============================
    // Show Grand Total
    // ============================

    if(grandTotal){

        grandTotal.value =
        finalTotal.toLocaleString("en-PK");

    }

    // ============================
    // Live Total
    // ============================

    if(liveGrandTotal){

        liveGrandTotal.innerHTML =
        "Rs. " + finalTotal.toLocaleString("en-PK");

    }

    // ============================
    // Save For Payment Page
    // ============================

    localStorage.setItem(
        "bookingTotal",
        itemsTotal.toString()
    );

    localStorage.setItem(
        "vehiclePrice",
        vehiclePrice.toString()
    );

    localStorage.setItem(
        "finalTotal",
        finalTotal.toString()
    );

    console.log("Items :", itemsTotal);
    console.log("Vehicle :", vehiclePrice);
    console.log("Final :", finalTotal);

    // Payment page update
    if(typeof updateFinalTotal === "function"){

        updateFinalTotal();

    }

    // Also update form completion (Progress Bar) alongside
    updateFormProgress();

}

// =====================================
// Update Row
// (Recalculates an item row's rate/amount
// and then also updates the Grand Total —
// this function didn't exist before,
// which is why the price wasn't being added)
// =====================================

function updateRow(row){

    if(row){

        calculateRow(row);

    }

    calculateGrandTotal();

}

// =====================================
// Stock Validation
// =====================================

function validateStock(input){



    const key =
    input.dataset.stock;



    if(!key) return;



    const limit =
    stock[key];



    if(limit === undefined)
    return;





    const available =
    input.parentElement.querySelector(".available");



    const error =
    input.parentElement.querySelector(".qty-error");





    if(available){


        available.innerHTML =
        "Available : " + limit;


    }






    let qty =
    Number(input.value) || 0;





    if(qty > limit){



        input.value =
        limit;



        input.classList.add(
        "is-invalid"
        );



        if(error){


            error.innerHTML =
            "⚠ Only " + limit + " available";


        }




    }
    else{



        input.classList.remove(
        "is-invalid"
        );



        if(error){


            error.innerHTML =
            "";


        }


    }





}







// =====================================
// Initial Load
// =====================================

rows.forEach(function(row){


    calculateRow(row);


});



calculateGrandTotal();




// =====================================
// PART-2 continues here
// =====================================

// =====================================
// Auto Linked Items
// =====================================

function updateLinkedItems(source){


    const key =
    source.dataset.link;



    if(!key) return;



    const target =
    document.querySelector(
        `[data-target="${key}"]`
    );



    if(!target) return;



    if(Number(source.value) === 0){


        target.value = 0;


    }

    else if(Number(target.value) === 0){


        target.value =
        source.value;


    }



    updateRow(
        target.closest("tr")
    );


}






// =====================================
// Quantity Events
// =====================================

rows.forEach(function(row){



    const qty =
    row.querySelector(".qty");



    if(qty){



        qty.addEventListener("input",function(){



            if(Number(this.value) < 0){


                this.value = 0;


            }



            validateStock(this);



            updateLinkedItems(this);



            updateRow(row);



        });



    }



});







// =====================================
// Initial Stock Check
// =====================================

document.querySelectorAll(".qty")
.forEach(function(input){


    validateStock(input);


});






// =====================================
// Initial Amount Calculation
// =====================================

rows.forEach(function(row){


    calculateRow(row);


});



calculateGrandTotal();





// =====================================
// PART-3 continues here
// =====================================
// =====================================
// Live Summary
// =====================================

function updateSummary(){


    if(!summaryList) return;



    let html = "";

    let total = 0;




    rows.forEach(function(row){



        const item =
        row.cells[1].innerText.trim();



        const qty =
        Number(
            row.querySelector(".qty").value
        ) || 0;



        const amount =
        Number(
            row.querySelector(".amount").value
        ) || 0;




        if(qty > 0){



            html += `

            <div class="d-flex justify-content-between border-bottom py-2">

                <span>${item}</span>

                <strong>${qty}</strong>

            </div>

            `;



            total += amount;



        }



    });




    if(html === ""){


        html = `

        <div class="text-center text-muted">

            No items selected yet.

        </div>

        `;


    }


    // =====================================
    // Add the vehicle line to the summary
    // =====================================

    if(typeof vehiclePrice !== "undefined" && vehiclePrice > 0){

        html += `

        <div class="d-flex justify-content-between border-bottom py-2 text-primary fw-bold">

            <span><i class="fa-solid fa-truck"></i> Vehicle Charges</span>

            <strong>Rs. ${vehiclePrice.toLocaleString()}</strong>

        </div>

        `;

    }


    summaryList.innerHTML = html;



    if(liveGrandTotal){

        const finalDisplayTotal =
        total + (typeof vehiclePrice !== "undefined" ? vehiclePrice : 0);

        liveGrandTotal.innerHTML =
        "Rs. " + finalDisplayTotal.toLocaleString();



    }



}

// Update the Summary as soon as a vehicle is selected (callable externally)
window.updateSummary = updateSummary;






// =====================================
// Search Items
// =====================================

if(searchInput){



    searchInput.addEventListener("keyup",function(){



        const keyword =
        this.value.toLowerCase();




        rows.forEach(function(row){



            const item =
            row.cells[1]
            .innerText
            .toLowerCase();




            row.style.display =
            item.includes(keyword)
            ? ""
            : "none";



        });



    });



}






// =====================================
// Row Highlight
// =====================================

rows.forEach(function(row){



    const qty =
    row.querySelector(".qty");



    if(qty){



        qty.addEventListener("input",function(){



            if(Number(this.value) > 0){


                row.classList.add(
                "table-success"
                );


            }

            else{


                row.classList.remove(
                "table-success"
                );


            }



            updateSummary();



        });



    }



});






// =====================================
// Initial Summary
// =====================================

updateSummary();





// =====================================
// Back Button
// =====================================

const backBtn = document.getElementById("backBtn");

if(backBtn){

    backBtn.addEventListener("click", function(){

        window.history.back();

    });

}

// =====================================
// Preview Button
// =====================================

const previewButton = document.getElementById("previewButton");

if(previewButton){

    previewButton.addEventListener("click", function(e){

        e.preventDefault();


        const previewItems =
        document.getElementById("previewItems");


        const previewTotal =
        document.getElementById("previewTotal");


        const modalElement =
        document.getElementById("previewModal");



        if(previewItems){

            previewItems.innerHTML =
            summaryList.innerHTML;

        }


        if(previewTotal){

            const itemsTotal =
            parseFloat(grandTotal.value.replace(/,/g, "")) || 0;

            const vehicleAmount =
            (typeof vehiclePrice !== "undefined") ? vehiclePrice : 0;

            const finalPreviewTotal =
            itemsTotal + vehicleAmount;

            previewTotal.innerHTML =
            "Rs. " + finalPreviewTotal.toLocaleString();

        }


        if(modalElement){

            const modal =
            bootstrap.Modal.getOrCreateInstance(modalElement);

            modal.show();

        }


    });

}

// =====================================
// PART-4 continues here
// =====================================


// =====================================
// Print Button
// =====================================

const printBtn =
document.getElementById("printBtn");


if(printBtn){


    printBtn.addEventListener("click",function(){


        window.print();


    });


}






// =====================================
// Helper functions for building the receipt
// Only filled-in / selected fields will be included
// =====================================

function receiptRow(label, value){

    return `
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #eee;">
            <span style="font-weight:bold;">${label}</span>
            <span>${value}</span>
        </div>
    `;

}

function receiptSection(title, rowsHtml){

    return `
        <h5 style="background:#0d6efd;color:#fff;padding:8px 12px;margin:20px 0 0;border-radius:6px 6px 0 0;font-size:16px;">${title}</h5>
        <div style="border:1px solid #ddd;border-top:none;padding:10px 14px;margin-bottom:6px;">
            ${rowsHtml}
        </div>
    `;

}

function buildReceiptElement(){

    const wrapper = document.createElement("div");

    wrapper.setAttribute("dir", "ltr");

    wrapper.style.cssText =
        "background:#ffffff;color:#111111;padding:24px;width:750px;" +
        "font-family:Tahoma,'Segoe UI',Arial,sans-serif;font-size:15px;line-height:1.9;";

    let html = "";

    // ===== Header =====
    html += `
        <div style="text-align:center;border-bottom:3px solid #0d6efd;padding-bottom:14px;margin-bottom:10px;">
            <h2 style="margin:0;color:#0d6efd;">Hassan Tent Service</h2>
            <p style="margin:6px 0 0;font-size:14px;">Booking Receipt</p>
        </div>
    `;

    // ===== Booking Information (only filled fields) =====
    const refNumber = document.getElementById("refNumber");
    const bookingDate = document.getElementById("bookingDate");
    const eventDate = document.getElementById("eventDate");

    let bookingRows = "";

    if(refNumber && refNumber.value.trim() !== ""){
        bookingRows += receiptRow("Reference Number", refNumber.value);
    }
    if(bookingDate && bookingDate.value.trim() !== ""){
        bookingRows += receiptRow("Date", bookingDate.value);
    }
    if(eventDate && eventDate.value.trim() !== ""){
        bookingRows += receiptRow("Event Date", eventDate.value);
    }

    const eventTypeField = document.getElementById("eventType");
    const eventTypeOtherField = document.getElementById("eventTypeOther");

    if(eventTypeField && eventTypeField.value.trim() !== ""){

        let eventTypeValue = eventTypeField.value;

        if(eventTypeValue === "Other" && eventTypeOtherField && eventTypeOtherField.value.trim() !== ""){
            eventTypeValue = eventTypeOtherField.value.trim();
        }

        bookingRows += receiptRow("Event Type", eventTypeValue);

    }

    if(bookingRows !== ""){
        html += receiptSection("Booking Information", bookingRows);
    }

    // ===== Customer Information (only filled fields) =====
    const customerName = document.getElementById("customerName");
    const customerPhone = document.getElementById("customerPhone");
    const alternatePhone = document.getElementById("alternatePhone");
    const customerEmail = document.getElementById("customerEmail");
    const customerAddress = document.getElementById("customerAddress");
    const customerNote = document.getElementById("customerNote");

    let customerRows = "";

    if(customerName && customerName.value.trim() !== ""){
        customerRows += receiptRow("Customer Name", customerName.value);
    }
    if(customerPhone && customerPhone.value.trim() !== ""){
        customerRows += receiptRow("Mobile Number", customerPhone.value);
    }
    if(alternatePhone && alternatePhone.value.trim() !== ""){
        customerRows += receiptRow("Alternate Number", alternatePhone.value);
    }
    if(customerEmail && customerEmail.value.trim() !== ""){
        customerRows += receiptRow("Email", customerEmail.value);
    }
    if(customerAddress && customerAddress.value.trim() !== ""){
        customerRows += receiptRow("Address", customerAddress.value);
    }
    if(customerNote && customerNote.value.trim() !== ""){
        customerRows += receiptRow("Note", customerNote.value);
    }

    if(customerRows !== ""){
        html += receiptSection("Customer Information", customerRows);
    }

    // ===== Item Details (only items with quantity greater than 0) =====
    let itemsBody = "";

    rows.forEach(function(row){

        const qtyField = row.querySelector(".qty");
        const qty = Number(qtyField ? qtyField.value : 0) || 0;

        if(qty > 0){

            const name = row.cells[1].innerText.trim();
            const rateField = row.querySelector(".rate");
            const amountField = row.querySelector(".amount");

            const rate = rateField ? rateField.value : 0;
            const amount = amountField ? Number(amountField.value) || 0 : 0;

            itemsBody += `
                <tr>
                    <td style="padding:6px;border:1px solid #ddd;">${name}</td>
                    <td style="padding:6px;border:1px solid #ddd;text-align:center;">${qty}</td>
                    <td style="padding:6px;border:1px solid #ddd;text-align:center;">${rate}</td>
                    <td style="padding:6px;border:1px solid #ddd;text-align:center;">${amount.toLocaleString()}</td>
                </tr>
            `;

        }

    });

    if(itemsBody !== ""){

        html += `
            <h5 style="background:#212529;color:#fff;padding:8px 12px;margin:20px 0 0;border-radius:6px 6px 0 0;font-size:16px;">Item Details</h5>
            <table style="width:100%;border-collapse:collapse;margin-bottom:6px;">
                <thead>
                    <tr style="background:#e9ecef;">
                        <th style="padding:6px;border:1px solid #ddd;">Item</th>
                        <th style="padding:6px;border:1px solid #ddd;">Quantity</th>
                        <th style="padding:6px;border:1px solid #ddd;">Rate</th>
                        <th style="padding:6px;border:1px solid #ddd;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsBody}
                </tbody>
            </table>
        `;

    }

    // ===== Transportation Service (only when a vehicle is selected) =====
    const serviceVehicleInput = document.getElementById("serviceVehicle");

    const serviceVehicleChecked =
    serviceVehicleInput ? serviceVehicleInput.checked : false;

    if(serviceVehicleChecked && typeof vehiclePrice !== "undefined" && vehiclePrice > 0){

        const selectedBtn =
        document.querySelector(".vehicleBtn.btn-primary, .vehicleBtn.btn-danger");

        let vehicleName = "Vehicle";

        if(selectedBtn){

            const vCard = selectedBtn.closest(".card");

            if(vCard){

                const heading = vCard.querySelector("h5");

                if(heading) vehicleName = heading.innerText.trim();

            }

        }

        const transportRows =
        receiptRow("Vehicle", vehicleName) +
        receiptRow("Vehicle Charges", "Rs. " + vehiclePrice.toLocaleString());

        html += receiptSection("Transportation Service", transportRows);

    }

    // ===== Total Amount =====
    const itemsTotal =
    grandTotal ? (parseFloat(grandTotal.value.toString().replace(/,/g,"")) || 0) : 0;

    const vAmount =
    (typeof vehiclePrice !== "undefined") ? vehiclePrice : 0;

    const finalAmount = itemsTotal + vAmount;

    html += `
        <div style="border-top:2px solid #212529;margin-top:14px;padding-top:14px;
        display:flex;justify-content:space-between;font-size:20px;font-weight:bold;">
            <span>Total Amount</span>
            <span>Rs. ${finalAmount.toLocaleString()}</span>
        </div>
    `;

    wrapper.innerHTML = html;

    return wrapper;

}

// =====================================
// Event Type
// =====================================

const eventType =
document.getElementById("eventType");

const eventTypeOtherWrap =
document.getElementById("eventTypeOtherWrap");

const eventTypeOther =
document.getElementById("eventTypeOther");

if(eventType){

    eventType.addEventListener("change", function(){

        if(this.value === "Other"){

            if(eventTypeOtherWrap){
                eventTypeOtherWrap.style.display = "block";
            }

        }
        else{

            if(eventTypeOtherWrap){
                eventTypeOtherWrap.style.display = "none";
            }

            if(eventTypeOther){
                eventTypeOther.value = "";
            }

        }

    });

}

// =====================================
// Statement Download (plain text)
// =====================================

function buildStatementText(){

    const lines = [];
    const sep = "----------------------------------------";

    lines.push("HASSAN TENT SERVICE");
    lines.push("Booking Statement");
    lines.push(sep);
    lines.push("");

    // ===== Booking Information =====
    const refNumber = document.getElementById("refNumber");
    const bookingDate = document.getElementById("bookingDate");
    const eventDate = document.getElementById("eventDate");
    const eventTypeField = document.getElementById("eventType");
    const eventTypeOtherField = document.getElementById("eventTypeOther");

    let bookingLines = [];

    if(refNumber && refNumber.value.trim() !== ""){
        bookingLines.push("Reference Number: " + refNumber.value);
    }
    if(bookingDate && bookingDate.value.trim() !== ""){
        bookingLines.push("Date: " + bookingDate.value);
    }
    if(eventDate && eventDate.value.trim() !== ""){
        bookingLines.push("Event Date: " + eventDate.value);
    }
    if(eventTypeField && eventTypeField.value.trim() !== ""){

        let eventTypeValue = eventTypeField.value;

        if(eventTypeValue === "Other" && eventTypeOtherField && eventTypeOtherField.value.trim() !== ""){
            eventTypeValue = eventTypeOtherField.value.trim();
        }

        bookingLines.push("Event Type: " + eventTypeValue);

    }

    if(bookingLines.length){
        lines.push("BOOKING INFORMATION");
        lines.push(...bookingLines);
        lines.push("");
    }

    // ===== Customer Information =====
    const customerName = document.getElementById("customerName");
    const customerPhone = document.getElementById("customerPhone");
    const alternatePhone = document.getElementById("alternatePhone");
    const customerEmail = document.getElementById("customerEmail");
    const customerAddress = document.getElementById("customerAddress");
    const customerNote = document.getElementById("customerNote");

    let customerLines = [];

    if(customerName && customerName.value.trim() !== ""){
        customerLines.push("Customer Name: " + customerName.value);
    }
    if(customerPhone && customerPhone.value.trim() !== ""){
        customerLines.push("Mobile Number: " + customerPhone.value);
    }
    if(alternatePhone && alternatePhone.value.trim() !== ""){
        customerLines.push("Alternate Number: " + alternatePhone.value);
    }
    if(customerEmail && customerEmail.value.trim() !== ""){
        customerLines.push("Email: " + customerEmail.value);
    }
    if(customerAddress && customerAddress.value.trim() !== ""){
        customerLines.push("Address: " + customerAddress.value);
    }
    if(customerNote && customerNote.value.trim() !== ""){
        customerLines.push("Note: " + customerNote.value);
    }

    if(customerLines.length){
        lines.push("CUSTOMER INFORMATION");
        lines.push(...customerLines);
        lines.push("");
    }

    // ===== Item Details =====
    let itemLines = [];

    rows.forEach(function(row){

        const qtyField = row.querySelector(".qty");
        const qty = Number(qtyField ? qtyField.value : 0) || 0;

        if(qty > 0){

            const name = row.cells[1].innerText.trim();
            const rateField = row.querySelector(".rate");
            const amountField = row.querySelector(".amount");

            const rate = rateField ? rateField.value : 0;
            const amount = amountField ? Number(amountField.value) || 0 : 0;

            itemLines.push(
                name + "  x" + qty + "  @ Rs. " + rate + "  = Rs. " + amount.toLocaleString()
            );

        }

    });

    if(itemLines.length){
        lines.push("ITEM DETAILS");
        lines.push(...itemLines);
        lines.push("");
    }

    // ===== Transportation Service =====
    const serviceVehicleInput = document.getElementById("serviceVehicle");
    const serviceVehicleChecked = serviceVehicleInput ? serviceVehicleInput.checked : false;

    if(serviceVehicleChecked && typeof vehiclePrice !== "undefined" && vehiclePrice > 0){

        const selectedBtn =
        document.querySelector(".vehicleBtn.btn-primary, .vehicleBtn.btn-danger");

        let vehicleName = "Vehicle";

        if(selectedBtn){
            const vCard = selectedBtn.closest(".card");
            if(vCard){
                const heading = vCard.querySelector("h5");
                if(heading) vehicleName = heading.innerText.trim();
            }
        }

        lines.push("TRANSPORTATION SERVICE");
        lines.push("Vehicle: " + vehicleName);
        lines.push("Vehicle Charges: Rs. " + vehiclePrice.toLocaleString());
        lines.push("");

    }

    // ===== Total Amount =====
    const itemsTotal =
    grandTotal ? (parseFloat(grandTotal.value.toString().replace(/,/g,"")) || 0) : 0;

    const vAmount =
    (typeof vehiclePrice !== "undefined") ? vehiclePrice : 0;

    const finalAmount = itemsTotal + vAmount;

    lines.push(sep);
    lines.push("TOTAL AMOUNT: Rs. " + finalAmount.toLocaleString());
    lines.push(sep);

    return lines.join("\n");

}

const pdfBtn =
document.getElementById("statementBtn");

if(pdfBtn){

    pdfBtn.addEventListener("click", function(){

        const text = buildStatementText();

        const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.download = "Tent-Booking-Statement.txt";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        URL.revokeObjectURL(url);

    });

}






// =====================================
// Confirm Order
// =====================================

const confirmOrder =
document.getElementById("confirmOrder");



if(confirmOrder){



    confirmOrder.addEventListener("click",function(){



        alert(
        "✅ Order confirmed successfully."
        );



        const modalElement =
        document.getElementById("previewModal");



        if(modalElement){



            const modal =
            bootstrap.Modal.getInstance(modalElement);



            if(modal){

                modal.hide();

            }



        }



    });



}

// =====================================
// Form Reset
// =====================================

const form = document.querySelector("form");

if(form){

    form.addEventListener("reset", function(){

        setTimeout(function(){

            // ============================
            // Reset Quantity
            // ============================

            document.querySelectorAll(".qty").forEach(function(input){

                input.value = 0;
                input.classList.remove("is-invalid");

            });

            // ============================
            // Reset Amount
            // ============================

            document.querySelectorAll(".amount").forEach(function(input){

                input.value = 0;

            });

            // ============================
            // Clear Error Messages
            // ============================

            document.querySelectorAll(".qty-error").forEach(function(error){

                error.innerHTML = "";

            });

            // ============================
            // Remove Highlight
            // ============================

            rows.forEach(function(row){

                row.classList.remove("table-success");

            });

            // ============================
            // Reset Vehicle
            // ============================

            vehiclePrice = 0;

            localStorage.removeItem("vehiclePrice");
            localStorage.removeItem("finalTotal");

            const ownVehicleRadio =
            document.getElementById("ownVehicle");

            const serviceVehicleRadio =
            document.getElementById("serviceVehicle");

            if(ownVehicleRadio){

                ownVehicleRadio.checked = true;

            }

            if(serviceVehicleRadio){

                serviceVehicleRadio.checked = false;

            }

            if(vehicleCard){

                vehicleCard.style.display = "none";

            }

            document.querySelectorAll(".vehicleBtn").forEach(function(btn){

                btn.classList.remove(
                    "btn-primary",
                    "btn-danger"
                );

                if(btn.dataset.price === "3000"){

                    btn.classList.add("btn-outline-primary");

                }

                if(btn.dataset.price === "5000"){

                    btn.classList.add("btn-outline-danger");

                }

            });

            // ============================
            // Reset Vehicle Charges
            // ============================

            const vehicleCharges =
            document.getElementById("vehicleCharges");

            if(vehicleCharges){

                vehicleCharges.value = "Rs. 0";

            }

            // ============================
            // Reset Event Type
            // ============================

            const eventType =
            document.getElementById("eventType");

            const eventTypeOtherWrap =
            document.getElementById("eventTypeOtherWrap");

            const eventTypeOther =
            document.getElementById("eventTypeOther");

            if(eventType){

                eventType.selectedIndex = 0;

            }

            if(eventTypeOtherWrap){

                eventTypeOtherWrap.style.display = "none";

            }

            if(eventTypeOther){

                eventTypeOther.value = "";

            }

            // ============================
            // Recalculate Totals
            // ============================

            calculateGrandTotal();

            if(typeof updateSummary === "function"){

                updateSummary();

            }

        },100);

    });

}
// =====================================
// Final Initialize
// =====================================


rows.forEach(function(row){


    calculateRow(row);


});



calculateGrandTotal();



updateSummary();



document.querySelectorAll(".qty")
.forEach(function(input){


    validateStock(input);


});


// =====================================
// Next Button
// =====================================

const nextBtn = document.getElementById("nextBtn");

if (nextBtn) {

    nextBtn.addEventListener("click", function (e) {

        e.preventDefault();

        // Customer Information Save
        localStorage.setItem("customerName", document.getElementById("customerName").value);
        localStorage.setItem("customerPhone", document.getElementById("customerPhone").value);
        localStorage.setItem("alternatePhone", document.getElementById("alternatePhone").value);
        localStorage.setItem("customerEmail", document.getElementById("customerEmail").value);
        localStorage.setItem("customerAddress", document.getElementById("customerAddress").value);
        localStorage.setItem("customerNote", document.getElementById("customerNote").value);

        // Reference Number Save
        const refNumberField = document.getElementById("refNumber");
        localStorage.setItem("refNumber", refNumberField ? refNumberField.value : "");

        // Save Grand Total (items total only)
        localStorage.setItem(
            "bookingTotal",
            grandTotal.value.replace(/,/g, "")
        );

        // =====================================
        // Save the event type
        // =====================================

        const eventTypeVal =
        document.getElementById("eventType");

        const eventTypeOtherVal =
        document.getElementById("eventTypeOther");

        let savedEventType = eventTypeVal ? eventTypeVal.value : "";

        if(savedEventType === "Other" && eventTypeOtherVal && eventTypeOtherVal.value.trim() !== ""){
            savedEventType = eventTypeOtherVal.value.trim();
        }

        localStorage.setItem("eventType", savedEventType);

        // =====================================
        // Save the vehicle information
        // =====================================

        const selectedVehicleOption =
        document.querySelector('input[name="vehicleOption"]:checked');

        localStorage.setItem(
            "vehicleOption",
            selectedVehicleOption ? selectedVehicleOption.value : "0"
        );

        localStorage.setItem(
            "vehiclePrice",
            (typeof vehiclePrice !== "undefined" ? vehiclePrice : 0)
        );

        // Save Final Total (items + vehicle)
        const finalTotalField =
        document.getElementById("finalTotal");

        localStorage.setItem(
            "finalTotal",
            finalTotalField
            ? finalTotalField.value.replace(/[^0-9]/g, "")
            : grandTotal.value.replace(/,/g, "")
        );

        // Payment Page Open
        window.location.href = "payment.html";

    });

}

console.log("✅ Hassan Tent Service Loaded Successfully");

});

// =====================================
// Transportation Service
// =====================================

const ownVehicle =
document.getElementById("ownVehicle");

const serviceVehicle =
document.getElementById("serviceVehicle");

const vehicleCard =
document.getElementById("vehicleCard");

const vehicleCharges =
document.getElementById("vehicleCharges");

const finalTotal =
document.getElementById("finalTotal");

let vehiclePrice = 0;


// =====================================
// Final Total
// =====================================

function updateFinalTotal(){

    const grandTotal =
    document.getElementById("grandTotal");

    if(!grandTotal) return;

    const vehicleCharges =
    document.getElementById("vehicleCharges");

    const finalTotal =
    document.getElementById("finalTotal");

    if(!vehicleCharges || !finalTotal){
        return;
    }

    let bookingTotal =
    parseFloat(
        grandTotal.value.replace(/,/g,"")
    ) || 0;

    let total =
    bookingTotal + vehiclePrice;

    vehicleCharges.value =
    "Rs. " + vehiclePrice.toLocaleString();

    finalTotal.value =
    "Rs. " + total.toLocaleString();

}



// Own vehicle
if(ownVehicle){

    ownVehicle.addEventListener("change",function(){

        vehicleCard.style.display = "none";

        vehiclePrice = 0;

        updateFinalTotal();

        if(window.updateSummary) window.updateSummary();

    });

}



// Hassan Tent Service's vehicle
if(serviceVehicle){

    serviceVehicle.addEventListener("change",function(){

        vehicleCard.style.display = "block";

        if(window.updateSummary) window.updateSummary();

    });

}



// =====================================
// Suzuki / Jeep Selection
// =====================================

document.querySelectorAll(".vehicleBtn").forEach(function(btn){

    btn.addEventListener("click", function(){

        vehiclePrice = Number(this.dataset.price);

        // Save Vehicle Price
        localStorage.setItem("vehiclePrice", vehiclePrice);

        // Update Totals
        updateFinalTotal();

        // Recalculate the Booking Total
        if(typeof calculateGrandTotal === "function"){
            calculateGrandTotal();
        }

        if(window.updateSummary){
            window.updateSummary();
        }

    });

});


// =====================================
// First Time Load
// =====================================

updateFinalTotal();
// =====================================
// Vehicle Button Active
// =====================================

document.querySelectorAll(".vehicleBtn")
.forEach(function(btn){

    btn.addEventListener("click", function(){

        // First reset all buttons to normal
        document.querySelectorAll(".vehicleBtn")
        .forEach(function(button){

            button.classList.remove(
                "btn-primary",
                "btn-danger"
            );

            if(button.dataset.price == "3000"){

                button.classList.add(
                    "btn-outline-primary"
                );

            }

            if(button.dataset.price == "5000"){

                button.classList.add(
                    "btn-outline-danger"
                );

            }

        });

        // Highlight the selected button
        if(this.dataset.price == "3000"){

            this.classList.remove(
                "btn-outline-primary"
            );

            this.classList.add(
                "btn-primary"
            );

        }

        if(this.dataset.price == "5000"){

            this.classList.remove(
                "btn-outline-danger"
            );

            this.classList.add(
                "btn-danger"
            );

        }

    });

});



// =====================================
// Grand Total Auto Update
// =====================================

// Whenever the Booking Total changes,
// the Final Total will also update automatically

setInterval(function(){

    updateFinalTotal();

},300);
document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("bookingForm");

    if (!form) {
        console.error("bookingForm not found.");
        return;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        alert("Form submitted!");

        const data = {
            event_type: document.getElementById("eventType")?.value || "",
            event_date: document.getElementById("eventDate")?.value || "",
            customer_name: document.getElementById("customerName")?.value || "",
            customer_phone: document.getElementById("customerPhone")?.value || ""
        };

        console.log("Sending data:", data);

        fetch("http://localhost/event-system/backend/booking.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        })
        .then(async res => {
            const text = await res.text();

            console.log("Raw server response:", text);

            try {
                return JSON.parse(text);
            } catch (error) {
                throw new Error("Server returned invalid JSON: " + text);
            }
        })
        .then(response => {

            console.log("Server response:", response);

            if (response.success) {
                alert("✅ Booking Created! ID: " + response.booking_id);
            } else {
                alert("❌ " + response.error);
            }

        })
        .catch(error => {
            console.error("Error:", error);
            alert("❌ " + error.message);
        });

    });

});