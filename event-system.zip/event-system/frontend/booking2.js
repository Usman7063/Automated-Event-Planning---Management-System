// =====================================================================
// HASSAN TENT SERVICE — BOOKING LOGIC
// =====================================================================

// ---------- Helpers ----------

function pkr(n) {
    return "PKR " + Math.round(n).toLocaleString("en-PK");
}

function refNumber() {
    return "HTS-" + Date.now().toString().slice(-6);
}

// ---------- Pricing / package data ----------

const PRICING = {

    sound: {
        packages: {
            "": { price: 0, includes: {} },
            "Basic Package": {
                price: 15000,
                includes: { speakers: 2, woofers: 1, amplifiers: 1, mixers: 1, wiredMic: 1, wirelessMic: 0, dj: false }
            },
            "Standard Package": {
                price: 25000,
                includes: { speakers: 4, woofers: 2, amplifiers: 2, mixers: 1, wiredMic: 2, wirelessMic: 1, dj: false }
            },
            "Premium Package": {
                price: 40000,
                includes: { speakers: 6, woofers: 4, amplifiers: 3, mixers: 2, wiredMic: 2, wirelessMic: 2, dj: true }
            },
            "VIP Package": {
                price: 65000,
                includes: { speakers: 10, woofers: 6, amplifiers: 4, mixers: 2, wiredMic: 4, wirelessMic: 4, dj: true }
            },
            "Custom Package": {
                price: 0,
                includes: { speakers: 0, woofers: 0, amplifiers: 0, mixers: 0, wiredMic: 0, wirelessMic: 0, dj: false }
            }
        },
        extraRates: { speakers: 1500, woofers: 3000, amplifiers: 2500, mixers: 2000, wiredMic: 800, wirelessMic: 1500, dj: 8000 },
        labels: { speakers: "Speaker", woofers: "Woofer", amplifiers: "Amplifier", mixers: "Mixer", wiredMic: "Wired Mic", wirelessMic: "Wireless Mic", dj: "DJ Setup" }
    },

    lighting: {
        packages: {
            "": { price: 0, includes: {} },
            "Basic": {
                price: 12000,
                includes: { stageLights: 2, parLights: 4, movingHeads: 0, floodLights: 2, smoke: false }
            },
            "Standard": {
                price: 20000,
                includes: { stageLights: 4, parLights: 8, movingHeads: 2, floodLights: 4, smoke: false }
            },
            "Premium": {
                price: 35000,
                includes: { stageLights: 8, parLights: 12, movingHeads: 4, floodLights: 6, smoke: true }
            },
            "VIP": {
                price: 55000,
                includes: { stageLights: 12, parLights: 20, movingHeads: 8, floodLights: 10, smoke: true }
            },
            "Custom": {
                price: 0,
                includes: { stageLights: 0, parLights: 0, movingHeads: 0, floodLights: 0, smoke: false }
            }
        },
        extraRates: { stageLights: 1000, parLights: 500, movingHeads: 2500, floodLights: 800, smoke: 3000 },
        labels: { stageLights: "Stage Light", parLights: "LED PAR", movingHeads: "Moving Head", floodLights: "Flood Light", smoke: "Smoke Machine" }
    },

    vehicle: { "None": 0, "Suzuki Pickup": 3000, "Jeep": 5000 },
    generator: { "No": 0, "Yes": 4000 }
};

// =====================================================================
// FORM CONFIGURATION (shared engine drives both Sound & Lighting)
// =====================================================================

const FORMS = {

    sound: {
        formId: "soundBookingForm",
        catalog: "sound",
        packageSelectId: "soundPackage",
        previewId: "packagePreviewSound",
        extraFieldIds: { speakers: "exSpeakers", woofers: "exWoofers", amplifiers: "exAmplifiers", mixers: "exMixers", wiredMic: "exWiredMic", wirelessMic: "exWirelessMic" },
        djSelectId: "exDjSetup",
        vehicleId: "vehicleSound",
        generatorId: "generatorSound",
        advanceId: "advance",
        vehicleCostTagId: "vehicleCostTagSound",
        generatorCostTagId: "generatorCostTagSound",
        confirmViaId: "confirmVia",
        summary: { pkg: "sndPkgPrice", extra: "sndExtraPrice", vehicle: "sndVehiclePrice", gen: "sndGenPrice", grand: "sndGrandTotal", advance: "sndAdvancePaid", balance: "sndBalanceRemaining" },
        paymentSelectId: "paymentMethod",
        qrBoxId: "qrBoxSound",
        fileInputId: "paymentScreenshotSound",
        uploadDropId: "uploadDropSound",
        progressFillId: "progressFillSound",
        progressPctId: "progressPctSound",
        thankYouId: "thankYouSound",
        successCardId: "soundFormCard",
        requiredTextIds: ["fullName", "mobile", "eventType", "eventDate", "guests", "city", "address", "soundPackage", "paymentMethod", "confirmVia"],
        agreeId: "agree",
        nameId: "fullName",
        eventTypeId: "eventType",
        eventDateId: "eventDate"
    },

    lighting: {
        formId: "lightingBookingForm",
        catalog: "lighting",
        packageSelectId: "lightingPackage",
        previewId: "packagePreviewLight",
        extraFieldIds: { stageLights: "exStageLights", parLights: "exParLights", movingHeads: "exMovingHeads", floodLights: "exFloodLights" },
        smokeSelectId: "exSmoke",
        vehicleId: "vehicleLight",
        generatorId: "generatorLight",
        advanceId: "advanceLight",
        vehicleCostTagId: "vehicleCostTagLight",
        generatorCostTagId: "generatorCostTagLight",
        confirmViaId: "confirmViaLight",
        summary: { pkg: "ltPkgPrice", extra: "ltExtraPrice", vehicle: "ltVehiclePrice", gen: "ltGenPrice", grand: "ltGrandTotal", advance: "ltAdvancePaid", balance: "ltBalanceRemaining" },
        paymentSelectId: "paymentMethodLight",
        qrBoxId: "qrBoxLight",
        fileInputId: "paymentScreenshotLight",
        uploadDropId: "uploadDropLight",
        progressFillId: "progressFillLight",
        progressPctId: "progressPctLight",
        thankYouId: "thankYouLight",
        successCardId: "lightingFormCard",
        requiredTextIds: ["lightFullName", "lightMobile", "lightEventType", "lightEventDate", "lightingPackage", "paymentMethodLight", "confirmViaLight"],
        agreeId: "lightAgree",
        nameId: "lightFullName",
        eventTypeId: "lightEventType",
        eventDateId: "lightEventDate"
    }
};

// =====================================================================
// PACKAGE PREVIEW (auto-selected included items)
// =====================================================================

function renderPackagePreview(cfg) {

    const catalog = PRICING[cfg.catalog];
    const select = document.getElementById(cfg.packageSelectId);
    const box = document.getElementById(cfg.previewId);
    if (!select || !box) return;

    const pkgName = select.value;
    const pkg = catalog.packages[pkgName];

    if (!pkgName || !pkg || pkg.price === 0) {
        box.classList.remove("show");
        box.innerHTML = "";
        return;
    }

    let badges = "";

    Object.keys(pkg.includes).forEach(function (key) {

        const val = pkg.includes[key];
        const label = catalog.labels[key];

        if (typeof val === "boolean") {
            if (val) badges += `<span class="pp-badge"><b>Included</b> — ${label}</span>`;
        } else if (val > 0) {
            badges += `<span class="pp-badge"><b>${val}×</b> ${label}</span>`;
        }
    });

    box.innerHTML = `
        <div class="pp-head">
            <strong>${pkgName} — What's Included</strong>
            <span class="pp-price">${pkr(pkg.price)}</span>
        </div>
        <div class="pp-badges">${badges || "<span class='pp-badge'>Build your own below — nothing pre-included</span>"}</div>
    `;

    box.classList.add("show");
}

// =====================================================================
// LIVE TOTAL CALCULATION
// =====================================================================

function calculateTotals(cfg) {

    const catalog = PRICING[cfg.catalog];
    const pkgName = document.getElementById(cfg.packageSelectId).value;
    const pkg = catalog.packages[pkgName] || { price: 0 };
    const pkgPrice = pkg.price || 0;

    let extraPrice = 0;

    Object.keys(cfg.extraFieldIds).forEach(function (key) {

        const el = document.getElementById(cfg.extraFieldIds[key]);
        if (!el) return;

        const qty = parseInt(el.value, 10) || 0;
        const rate = catalog.extraRates[key] || 0;

        extraPrice += qty * rate;
    });

    // Sound: DJ setup flat extra (only if not already included in package)
    if (cfg.djSelectId) {

        const djEl = document.getElementById(cfg.djSelectId);
        const includesDj = pkg.includes && pkg.includes.dj;

        if (djEl && djEl.value === "Yes" && !includesDj) {
            extraPrice += catalog.extraRates.dj || 0;
        }
    }

    // Lighting: smoke machine flat extra (only if not already included)
    if (cfg.smokeSelectId) {

        const smokeEl = document.getElementById(cfg.smokeSelectId);
        const includesSmoke = pkg.includes && pkg.includes.smoke;

        if (smokeEl && smokeEl.value === "Yes" && !includesSmoke) {
            extraPrice += catalog.extraRates.smoke || 0;
        }
    }

    const vehicleEl = document.getElementById(cfg.vehicleId);
    const genEl = document.getElementById(cfg.generatorId);

    const vehiclePrice = vehicleEl ? (PRICING.vehicle[vehicleEl.value] || 0) : 0;
    const genPrice = genEl ? (PRICING.generator[genEl.value] || 0) : 0;

    const grandTotal = pkgPrice + extraPrice + vehiclePrice + genPrice;

    const advanceEl = document.getElementById(cfg.advanceId);
    const advance = advanceEl ? (parseFloat(advanceEl.value) || 0) : 0;
    const balance = Math.max(0, grandTotal - advance);

    return { pkgPrice, extraPrice, vehiclePrice, genPrice, grandTotal, advance, balance };
}

function updateSummary(cfg) {

    const totals = calculateTotals(cfg);
    const s = cfg.summary;

    const pkgEl = document.getElementById(s.pkg);
    const extraEl = document.getElementById(s.extra);
    const vehicleEl = document.getElementById(s.vehicle);
    const genEl = document.getElementById(s.gen);
    const grandEl = document.getElementById(s.grand);
    const advanceEl = document.getElementById(s.advance);
    const balanceEl = document.getElementById(s.balance);

    if (pkgEl) pkgEl.textContent = pkr(totals.pkgPrice);
    if (extraEl) extraEl.textContent = pkr(totals.extraPrice);
    if (vehicleEl) vehicleEl.textContent = pkr(totals.vehiclePrice);
    if (genEl) genEl.textContent = pkr(totals.genPrice);
    if (advanceEl) advanceEl.textContent = pkr(totals.advance);
    if (balanceEl) balanceEl.textContent = pkr(totals.balance);

    // Inline cost tags next to the Vehicle / Generator selects
    const vehicleTag = document.getElementById(cfg.vehicleCostTagId);
    const genTag = document.getElementById(cfg.generatorCostTagId);
    if (vehicleTag) vehicleTag.textContent = pkr(totals.vehiclePrice);
    if (genTag) genTag.textContent = pkr(totals.genPrice);

    if (grandEl) {

        grandEl.textContent = pkr(totals.grandTotal);
        grandEl.classList.add("pulse");

        setTimeout(function () {
            grandEl.classList.remove("pulse");
        }, 200);
    }

    return totals;
}

// =====================================================================
// PROGRESS BAR
// =====================================================================

function updateProgress(cfg) {

    const fill = document.getElementById(cfg.progressFillId);
    const pctLabel = document.getElementById(cfg.progressPctId);
    if (!fill) return;

    let total = cfg.requiredTextIds.length + 1; // +1 for terms checkbox
    let filled = 0;

    cfg.requiredTextIds.forEach(function (id) {

        const el = document.getElementById(id);
        if (el && el.value && el.value.trim() !== "") filled++;
    });

    const agreeEl = document.getElementById(cfg.agreeId);
    if (agreeEl && agreeEl.checked) filled++;

    // Payment proof counts toward progress if required
    const paymentEl = document.getElementById(cfg.paymentSelectId);
    const fileEl = document.getElementById(cfg.fileInputId);

    if (paymentEl && paymentEl.value && paymentEl.value !== "Cash") {

        total++;
        if (fileEl && fileEl.files && fileEl.files.length > 0) filled++;
    }

    const pct = Math.min(100, Math.round((filled / total) * 100));

    fill.style.width = pct + "%";
    if (pctLabel) pctLabel.textContent = pct + "%";
}

// =====================================================================
// PAYMENT METHOD → QR CODE + SCREENSHOT PROOF
// =====================================================================

function setupPaymentToggle(cfg) {

    const select = document.getElementById(cfg.paymentSelectId);
    const qrBox = document.getElementById(cfg.qrBoxId);
    const fileInput = document.getElementById(cfg.fileInputId);

    if (!select) return;

    function toggle() {

        const method = select.value;
        const needsProof = method && method !== "Cash";

        if (qrBox) qrBox.classList.toggle("show", needsProof);

        if (fileInput) {

            if (needsProof) {
                fileInput.setAttribute("required", "required");
            } else {
                fileInput.removeAttribute("required");
                fileInput.classList.remove("is-invalid", "is-valid");
            }
        }

        const methodLabel = qrBox ? qrBox.querySelector(".qr-method-name") : null;
        if (methodLabel) methodLabel.textContent = method;

        updateProgress(cfg);
    }

    select.addEventListener("change", toggle);
    toggle();
}

function setupFilePreview(cfg) {

    const fileInput = document.getElementById(cfg.fileInputId);
    const drop = document.getElementById(cfg.uploadDropId);
    if (!fileInput || !drop) return;

    const nameTag = drop.querySelector(".upload-filename");

    fileInput.addEventListener("change", function () {

        if (fileInput.files && fileInput.files.length > 0) {

            drop.classList.add("is-valid");
            drop.classList.remove("is-invalid");
            if (nameTag) nameTag.textContent = "✓ " + fileInput.files[0].name + " attached";

        } else {

            drop.classList.remove("is-valid");
            if (nameTag) nameTag.textContent = "";
        }

        updateProgress(cfg);
    });
}

// =====================================================================
// BIND LIVE-UPDATE LISTENERS FOR A FORM
// =====================================================================

function bindLiveUpdates(cfg) {

    const form = document.getElementById(cfg.formId);
    if (!form) return;

    function refresh() {
        renderPackagePreview(cfg);
        updateSummary(cfg);
        updateProgress(cfg);
    }

    form.addEventListener("input", refresh);
    form.addEventListener("change", refresh);

    form.addEventListener("reset", function () {

        setTimeout(function () {

            const qrBox = document.getElementById(cfg.qrBoxId);
            const drop = document.getElementById(cfg.uploadDropId);
            const nameTag = drop ? drop.querySelector(".upload-filename") : null;

            if (qrBox) qrBox.classList.remove("show");
            if (drop) { drop.classList.remove("is-valid", "is-invalid"); }
            if (nameTag) nameTag.textContent = "";

            document.querySelectorAll("#" + cfg.formId + " .form-control, #" + cfg.formId + " .form-select")
                .forEach(function (field) {
                    field.classList.remove("is-invalid", "is-valid");
                });

            refresh();

        }, 0);
    });

    setupPaymentToggle(cfg);
    setupFilePreview(cfg);

    refresh();
}

// =====================================================================
// FIELD VALIDATION
// =====================================================================

function checkField(field) {

    if (!field) return true;

    if (!field.value.trim()) {
        field.classList.add("is-invalid");
        field.classList.remove("is-valid");
        return false;
    }

    field.classList.add("is-valid");
    field.classList.remove("is-invalid");
    return true;
}

function checkFile(cfg) {

    const select = document.getElementById(cfg.paymentSelectId);
    const fileInput = document.getElementById(cfg.fileInputId);
    const drop = document.getElementById(cfg.uploadDropId);

    if (!select || select.value === "Cash" || !select.value) return true;

    const hasFile = fileInput && fileInput.files && fileInput.files.length > 0;

    if (drop) {
        drop.classList.toggle("is-invalid", !hasFile);
        drop.classList.toggle("is-valid", !!hasFile);
    }

    return hasFile;
}

// =====================================================================
// THANK YOU PAGE
// =====================================================================

function showThankYou(cfg, totals) {

    const formCard = document.getElementById(cfg.successCardId);
    const thankYou = document.getElementById(cfg.thankYouId);
    if (!thankYou) return;

    const set = function (suffix, value) {
        const el = document.getElementById(cfg.thankYouId + suffix);
        if (el) el.textContent = value || "—";
    };

    const name = document.getElementById(cfg.nameId).value;
    const eventType = document.getElementById(cfg.eventTypeId).value;
    const eventDate = document.getElementById(cfg.eventDateId).value;
    const paymentMethod = document.getElementById(cfg.paymentSelectId).value;
    const packageName = document.getElementById(cfg.packageSelectId).value;
    const vehicle = document.getElementById(cfg.vehicleId).value;
    const generator = document.getElementById(cfg.generatorId).value;
    const confirmVia = document.getElementById(cfg.confirmViaId).value;
    const ref = refNumber();

    set("Ref", ref);
    set("Name", name);
    set("Event", eventType + " — " + eventDate);
    set("Package", packageName || "—");
    set("PkgPrice", pkr(totals.pkgPrice));
    set("ExtraPrice", pkr(totals.extraPrice));
    set("Vehicle", vehicle);
    set("Generator", generator);
    set("Payment", paymentMethod);
    set("Advance", pkr(totals.advance));
    set("Balance", pkr(totals.balance));
    set("Total", pkr(totals.grandTotal));

    // Sound-only extra fields
    let mobileVal = "";
    let emailVal = "";

    if (cfg.catalog === "sound") {

        mobileVal = document.getElementById("mobile").value;
        emailVal = document.getElementById("email").value;
        const city = document.getElementById("city").value;
        const address = document.getElementById("address").value;

        set("Mobile", mobileVal);
        set("Email", emailVal);
        set("Location", (city ? city + " — " : "") + address);
    }

    // Lighting-only extra fields
    if (cfg.catalog === "lighting") {

        mobileVal = document.getElementById("lightMobile").value;
        emailVal = document.getElementById("lightEmail") ? document.getElementById("lightEmail").value : "";
        set("Mobile", mobileVal);
    }

    // Where the confirmation is actually being sent
    let confirmTarget = "—";

    if (confirmVia === "SMS") {
        confirmTarget = "SMS to " + (mobileVal || "your mobile number");
    } else if (confirmVia === "Email") {
        confirmTarget = "Email to " + (emailVal || "your email address");
    } else if (confirmVia === "Both") {
        confirmTarget = "SMS to " + (mobileVal || "your mobile") + " & Email to " + (emailVal || "your email");
    }

    set("Confirm", confirmTarget);

    const notice = document.getElementById(cfg.thankYouId + "Notice");

    if (notice) {

        notice.textContent = "Sending confirmation...";

        setTimeout(function () {

            const channelText = confirmVia === "Both" ? "SMS & Email" : (confirmVia || "SMS/Email");

            notice.textContent = paymentMethod === "Cash"
                ? "A confirmation has been sent via " + channelText + ". Our team will call to finalize details."
                : "Payment proof received. A confirmation via " + channelText + " will be sent once verified by our team.";
        }, 900);
    }

    if (formCard) formCard.classList.add("d-none");
    thankYou.classList.remove("d-none");

    window.scrollTo({ top: 0, behavior: "smooth" });
}

function backToServicesFrom(thankYouId, formCardId) {

    const thankYou = document.getElementById(thankYouId);
    const formCard = document.getElementById(formCardId);

    if (thankYou) thankYou.classList.add("d-none");
    if (formCard) formCard.classList.remove("d-none");

    backToServices();
}

// =====================================================================
// SERVICE SELECTION (Sound / Lighting cards)
// =====================================================================

const serviceSection = document.getElementById("serviceSection");
const soundForm = document.getElementById("soundForm");
const lightingForm = document.getElementById("lightingForm");
const soundCard = document.getElementById("soundCard");
const lightingCard = document.getElementById("lightingCard");
const mainHero = document.getElementById("mainHero");

if (soundCard) {
    soundCard.addEventListener("click", function () {
        serviceSection.classList.add("d-none");
        soundForm.classList.remove("d-none");
        lightingForm.classList.add("d-none");
        if (mainHero) mainHero.classList.add("d-none");
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}

if (lightingCard) {
    lightingCard.addEventListener("click", function () {
        serviceSection.classList.add("d-none");
        lightingForm.classList.remove("d-none");
        soundForm.classList.add("d-none");
        if (mainHero) mainHero.classList.add("d-none");
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}

function backToServices() {
    soundForm.classList.add("d-none");
    lightingForm.classList.add("d-none");
    serviceSection.classList.remove("d-none");
    if (mainHero) mainHero.classList.remove("d-none");
    window.scrollTo({ top: 0, behavior: "smooth" });
}



// =====================================================================
// SOUND FORM SUBMIT VALIDATION + BACKEND CONNECTION
// =====================================================================

const soundBookingForm =
    document.getElementById("soundBookingForm");


if (soundBookingForm) {

    soundBookingForm.addEventListener(
        "submit",
        async function (e) {

            // =========================================================
            // STOP NORMAL FORM SUBMISSION
            // =========================================================

            e.preventDefault();


            let isValid = true;

            const cfg =
                FORMS.sound;


            // =========================================================
            // GET FORM ELEMENTS
            // =========================================================

            const fullName =
                document.getElementById("fullName");

            const mobile =
                document.getElementById("mobile");

            const email =
                document.getElementById("email");

            const cnic =
                document.getElementById("cnic");

            const eventType =
                document.getElementById("eventType");

            const eventDate =
                document.getElementById("eventDate");

            const guests =
                document.getElementById("guests");

            const city =
                document.getElementById("city");

            const address =
                document.getElementById("address");

            const soundPackage =
                document.getElementById("soundPackage");

            const paymentMethod =
                document.getElementById("paymentMethod");

            const confirmVia =
                document.getElementById("confirmVia");

            const agree =
                document.getElementById("agree");

            const startTime =
                document.getElementById("startTime");

            const endTime =
                document.getElementById("endTime");

            const area =
                document.getElementById("area");

            const vehicle =
                document.getElementById("vehicleSound");

            const generator =
                document.getElementById("generatorSound");

            const advance =
                document.getElementById("advance");

            const notes =
                document.getElementById("notes");


            // =========================================================
            // RESET VALIDATION
            // =========================================================

            document.querySelectorAll(
                "#soundBookingForm .form-control, " +
                "#soundBookingForm .form-select"
            ).forEach(function (field) {

                field.classList.remove("is-invalid");
                field.classList.remove("is-valid");

            });


            // =========================================================
            // REQUIRED FIELDS
            // =========================================================

            [
                fullName,
                mobile,
                eventType,
                eventDate,
                guests,
                city,
                address,
                soundPackage,
                paymentMethod,
                confirmVia

            ].forEach(function (field) {

                if (!checkField(field)) {

                    isValid = false;

                }

            });


            // =========================================================
            // MOBILE VALIDATION
            // =========================================================

            const mobilePattern =
                /^03[0-9]{9}$/;


            if (
                mobile &&
                mobile.value.trim() !== "" &&
                !mobilePattern.test(
                    mobile.value.trim()
                )
            ) {

                mobile.classList.remove(
                    "is-valid"
                );

                mobile.classList.add(
                    "is-invalid"
                );

                isValid = false;

            }


            // =========================================================
            // EMAIL VALIDATION
            // =========================================================

            if (
                email &&
                email.value.trim() !== ""
            ) {

                const emailPattern =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


                if (
                    !emailPattern.test(
                        email.value.trim()
                    )
                ) {

                    email.classList.add(
                        "is-invalid"
                    );

                    email.classList.remove(
                        "is-valid"
                    );

                    isValid = false;

                } else {

                    email.classList.add(
                        "is-valid"
                    );

                }

            }


            // =========================================================
            // CNIC VALIDATION
            // =========================================================

    
// =========================================================
// CNIC VALIDATION
// =========================================================

if (
    cnic &&
    cnic.value.trim() !== ""
) {

    const cnicValue =
        cnic.value.trim();


    /*
     * Accepts:
     *
     * 12345-1234567-1
     *
     * OR
     *
     * 1234512345671
     */

    const cnicPattern =
        /^(?:[0-9]{5}-[0-9]{7}-[0-9]{1}|[0-9]{13})$/;


    if (
        !cnicPattern.test(cnicValue)
    ) {

        cnic.classList.remove(
            "is-valid"
        );

        cnic.classList.add(
            "is-invalid"
        );

        isValid = false;


    } else {

        cnic.classList.remove(
            "is-invalid"
        );

        cnic.classList.add(
            "is-valid"
        );

    }

}




            // =========================================================
            // PAYMENT SCREENSHOT VALIDATION
            // =========================================================

            if (!checkFile(cfg)) {

                isValid = false;

            }


            // =========================================================
            // TERMS & CONDITIONS
            // =========================================================

            if (
                !agree ||
                !agree.checked
            ) {

                alert(
                    "Please accept the Terms & Conditions."
                );

                isValid = false;

            }


            // =========================================================
            // STOP IF VALIDATION FAILED
            // =========================================================

            if (!isValid) {

                console.log(
                    "Sound booking validation failed."
                );

                return;
            }


            // =========================================================
            // CALCULATE EXISTING PRICE
            // =========================================================

            const totals =
                calculateTotals(cfg);


            // =========================================================
            // COLLECT BOOKING DATA
            // =========================================================

            const data = {

                // -----------------------------------------------------
                // SERVICE
                // -----------------------------------------------------

                service_type:
                    "Sound",


                // -----------------------------------------------------
                // CUSTOMER
                // -----------------------------------------------------

                customer_name:
                    fullName.value.trim(),

                customer_phone:
                    mobile.value.trim(),

                email:
                    email
                        ? email.value.trim()
                        : "",

                cnic:
                    cnic
                        ? cnic.value.trim()
                        : "",


                // -----------------------------------------------------
                // EVENT
                // -----------------------------------------------------

                event_type:
                    eventType.value.trim(),

                event_date:
                    eventDate.value.trim(),

                start_time:
                    startTime
                        ? startTime.value
                        : "",

                end_time:
                    endTime
                        ? endTime.value
                        : "",

                guests:
                    guests
                        ? parseInt(
                            guests.value,
                            10
                        ) || 0
                        : 0,


                // -----------------------------------------------------
                // LOCATION
                // -----------------------------------------------------

                city:
                    city
                        ? city.value.trim()
                        : "",

                area:
                    area
                        ? area.value.trim()
                        : "",

                address:
                    address
                        ? address.value.trim()
                        : "",


                // -----------------------------------------------------
                // PACKAGE
                // -----------------------------------------------------

                package_name:
                    soundPackage.value.trim(),

                package_price:
                    totals.pkgPrice,

                extra_price:
                    totals.extraPrice,


                // -----------------------------------------------------
                // VEHICLE
                // -----------------------------------------------------

                vehicle:
                    vehicle
                        ? vehicle.value
                        : "None",

                vehicle_price:
                    totals.vehiclePrice,


                // -----------------------------------------------------
                // GENERATOR
                // -----------------------------------------------------

                generator:
                    generator
                        ? generator.value
                        : "No",

                generator_price:
                    totals.genPrice,


                // -----------------------------------------------------
                // TOTAL
                // -----------------------------------------------------

                grand_total:
                    totals.grandTotal,

                advance_payment:
                    totals.advance,

                remaining_amount:
                    totals.balance,


                // -----------------------------------------------------
                // PAYMENT
                // -----------------------------------------------------

                payment_method:
                    paymentMethod.value.trim(),

                confirm_via:
                    confirmVia.value.trim(),


                // -----------------------------------------------------
                // NOTES
                // -----------------------------------------------------

                notes:
                    notes
                        ? notes.value.trim()
                        : ""
            };


            // =========================================================
            // DEBUG
            // =========================================================

            console.log(
                "================================="
            );

            console.log(
                "SOUND BOOKING DATA BEING SENT:"
            );

            console.log(data);

            console.log(
                "================================="
            );


            // =========================================================
            // PREVENT DOUBLE SUBMISSION
            // =========================================================

            const submitButton =
                soundBookingForm.querySelector(
                    'button[type="submit"], input[type="submit"]'
                );


            if (submitButton) {

                submitButton.disabled = true;

            }


            // =========================================================
            // SEND TO booking2.php
            // =========================================================

            try {

                const response =
                    await fetch(
                        "http://localhost/event-system/backend/booking2.php",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json",

                                "Accept":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(data)
                        }
                    );


                // =====================================================
                // READ RAW RESPONSE
                // =====================================================

                const rawResponse =
                    await response.text();


                console.log(
                    "booking2.php RAW RESPONSE:"
                );

                console.log(
                    rawResponse
                );


                // =====================================================
                // HTTP ERROR
                // =====================================================

                if (!response.ok) {

                    console.error(
                        "booking2.php HTTP error:",
                        response.status
                    );

                    alert(
                        "❌ Booking failed.\n\n" +
                        "Server returned HTTP " +
                        response.status +
                        "."
                    );


                    if (submitButton) {

                        submitButton.disabled = false;

                    }


                    return;
                }


                // =====================================================
                // PARSE JSON
                // =====================================================

                let result;


                try {

                    result =
                        JSON.parse(
                            rawResponse
                        );

                } catch (jsonError) {

                    console.error(
                        "Invalid JSON from booking2.php:",
                        rawResponse
                    );

                    alert(
                        "❌ booking2.php returned invalid JSON."
                    );


                    if (submitButton) {

                        submitButton.disabled = false;

                    }


                    return;
                }


                // =====================================================
                // DEBUG SERVER RESPONSE
                // =====================================================

                console.log(
                    "SOUND SERVER RESPONSE:",
                    result
                );


                // =====================================================
                // BACKEND ERROR
                // =====================================================

                if (!result.success) {

                    console.error(
                        "Booking2 backend error:",
                        result
                    );

                    alert(
                        "❌ Booking failed:\n\n" +
                        (
                            result.error ||
                            "Unknown server error"
                        )
                    );


                    if (submitButton) {

                        submitButton.disabled = false;

                    }


                    return;
                }


                // =====================================================
                // SUCCESS
                // =====================================================

                console.log(
                    "✅ SOUND BOOKING CREATED SUCCESSFULLY"
                );

                console.log(
                    "Booking ID:",
                    result.booking2_id
                );

                console.log(
                    "Event ID:",
                    result.event_id
                );

                console.log(
                    "Vendor ID:",
                    result.vendor_id
                );


                // =====================================================
                // SUCCESS MESSAGE
                // =====================================================

                alert(
                    "✅ Form submitted successfully!"
                );


                // =====================================================
                // SHOW EXISTING THANK-YOU PAGE
                // =====================================================

                showThankYou(
                    cfg,
                    totals
                );


            } catch (error) {

                console.error(
                    "Sound booking connection error:",
                    error
                );

                alert(
                    "❌ Unable to connect to the booking server.\n\n" +
                    error.message
                );


                if (submitButton) {

                    submitButton.disabled = false;

                }

            }

        }
    );

}

// =====================================================================
// LIGHTING FORM SUBMIT VALIDATION + BACKEND CONNECTION
// =====================================================================

const lightingBookingForm =
    document.getElementById("lightingBookingForm");

if (lightingBookingForm) {

    lightingBookingForm.addEventListener(
        "submit",
        async function (e) {

            e.preventDefault();

            let isValid = true;
            const cfg = FORMS.lighting;

            const fullName =
                document.getElementById("lightFullName");

            const mobile =
                document.getElementById("lightMobile");

            const email =
                document.getElementById("lightEmail");

            const eventType =
                document.getElementById("lightEventType");

            const eventDate =
                document.getElementById("lightEventDate");

            const lightingPackage =
                document.getElementById("lightingPackage");

            const paymentMethod =
                document.getElementById("paymentMethodLight");

            const confirmVia =
                document.getElementById("confirmViaLight");

            const agree =
                document.getElementById("lightAgree");

            const startTime =
                document.getElementById("lightStartTime");

            const endTime =
                document.getElementById("lightEndTime");

            const vehicle =
                document.getElementById("vehicleLight");

            const generator =
                document.getElementById("generatorLight");

            const advance =
                document.getElementById("advanceLight");

            const notes =
                document.getElementById("lightNotes");

            // ---------------------------------------------------------
            // RESET VALIDATION
            // ---------------------------------------------------------

            document.querySelectorAll(
                "#lightingBookingForm .form-control, #lightingBookingForm .form-select"
            ).forEach(function (field) {

                field.classList.remove("is-valid");
                field.classList.remove("is-invalid");

            });

            // ---------------------------------------------------------
            // REQUIRED FIELDS
            // ---------------------------------------------------------

            [
                fullName,
                mobile,
                eventType,
                eventDate,
                lightingPackage,
                paymentMethod,
                confirmVia
            ].forEach(function (f) {

                if (!checkField(f)) {
                    isValid = false;
                }

            });

            // ---------------------------------------------------------
            // MOBILE VALIDATION
            // ---------------------------------------------------------

            const mobilePattern =
                /^03[0-9]{9}$/;

            if (
                mobile &&
                mobile.value.trim() !== "" &&
                !mobilePattern.test(mobile.value.trim())
            ) {

                mobile.classList.remove("is-valid");
                mobile.classList.add("is-invalid");

                isValid = false;
            }

            // ---------------------------------------------------------
            // PAYMENT SCREENSHOT VALIDATION
            // ---------------------------------------------------------

            if (!checkFile(cfg)) {
                isValid = false;
            }

            // ---------------------------------------------------------
            // TERMS & CONDITIONS
            // ---------------------------------------------------------

            if (!agree.checked) {

                alert(
                    "Please accept the Terms & Conditions."
                );

                isValid = false;
            }

            // ---------------------------------------------------------
            // STOP IF VALIDATION FAILED
            // ---------------------------------------------------------

            if (!isValid) {
                return;
            }

            // ---------------------------------------------------------
            // CALCULATE EXISTING PRICE
            // ---------------------------------------------------------

            const totals =
                calculateTotals(cfg);

            // ---------------------------------------------------------
            // COLLECT DATA FOR booking2.php
            // ---------------------------------------------------------

            const data = {

                // Service
                service_type: "Lighting",

                // Customer
                customer_name:
                    fullName.value.trim(),

                customer_phone:
                    mobile.value.trim(),

                email:
                    email ? email.value.trim() : "",

                cnic: "",

                // Event
                event_type:
                    eventType.value.trim(),

                event_date:
                    eventDate.value.trim(),

                start_time:
                    startTime ? startTime.value : "",

                end_time:
                    endTime ? endTime.value : "",

                guests: 0,

                // Location
                city: "",
                area: "",
                address: "",

                // Package
                package_name:
                    lightingPackage.value.trim(),

                package_price:
                    totals.pkgPrice,

                extra_price:
                    totals.extraPrice,

                // Transport
                vehicle:
                    vehicle ? vehicle.value : "None",

                vehicle_price:
                    totals.vehiclePrice,

                // Generator
                generator:
                    generator ? generator.value : "No",

                generator_price:
                    totals.genPrice,

                // Total
                grand_total:
                    totals.grandTotal,

                advance_payment:
                    totals.advance,

                remaining_amount:
                    totals.balance,

                // Payment
                payment_method:
                    paymentMethod.value.trim(),

                confirm_via:
                    confirmVia.value.trim(),

                // Notes
                notes:
                    notes ? notes.value.trim() : ""
            };

            console.log(
                "LIGHTING BOOKING DATA SENT:",
                data
            );

            // ---------------------------------------------------------
            // SEND TO booking2.php
            // ---------------------------------------------------------

            try {

                const response = await fetch(
                    "http://localhost/event-system/backend/booking2.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json"
                        },

                        body: JSON.stringify(data)
                    }
                );

                const result =
                    await response.json();

                console.log(
                    "LIGHTING SERVER RESPONSE:",
                    result
                );

                // -----------------------------------------------------
                // BACKEND ERROR
                // -----------------------------------------------------

                if (!result.success) {

                    alert(
                        "❌ Booking failed:\n" +
                        (result.error ||
                            "Unknown server error")
                    );

                    return;
                }

                // -----------------------------------------------------
                // SUCCESS
                // -----------------------------------------------------

                console.log(
                    "Lighting booking created:",
                    result.booking2_id
                );

                // Existing thank-you page remains unchanged
                showThankYou(
                    cfg,
                    totals
                );

            } catch (error) {

                console.error(
                    "Lighting booking error:",
                    error
                );

                alert(
                    "❌ Unable to connect to the booking server."
                );
            }

        }
    );

}





// =====================================================================
// DOWNLOAD STATEMENT — SOUND
// =====================================================================

function runSoundDownload() {

        const totals = calculateTotals(FORMS.sound);

        let name = document.getElementById("fullName").value;
        let mobile = document.getElementById("mobile").value;
        let email = document.getElementById("email").value;
        let event = document.getElementById("eventType").value;
        let date = document.getElementById("eventDate").value;
        let city = document.getElementById("city").value;
        let address = document.getElementById("address").value;
        let packageName = document.getElementById("soundPackage").value;
        let vehicle = document.getElementById("vehicleSound").value;
        let generator = document.getElementById("generatorSound").value;
        let paymentMethod = document.getElementById("paymentMethod").value;

        let statement = `
HASSAN TENT SERVICE
============================
Sound System Booking Statement

Customer Information
----------------------------
Name: ${name}
Mobile: ${mobile}
Email: ${email}

Event Information
----------------------------
Event Type: ${event}
Event Date: ${date}
City: ${city}
Address: ${address}

Sound Package: ${packageName}
Package Price: ${pkr(totals.pkgPrice)}
Extra Equipment: ${pkr(totals.extraPrice)}
Vehicle (${vehicle}): ${pkr(totals.vehiclePrice)}
Generator (${generator}): ${pkr(totals.genPrice)}

----------------------------
TOTAL BILL: ${pkr(totals.grandTotal)}
Advance Paid: ${pkr(totals.advance)}
Balance Remaining: ${pkr(totals.balance)}
----------------------------

Payment Method: ${paymentMethod}

============================
Thank You For Booking With Us.
`;

        let blob = new Blob([statement], { type: "text/plain" });
        let link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "Sound_Booking_Statement.txt";
        link.click();
}

document.querySelectorAll(".download-sound-btn").forEach(function (btn) {
    btn.addEventListener("click", runSoundDownload);
});

// =====================================================================
// DOWNLOAD STATEMENT — LIGHTING
// =====================================================================

function runLightDownload() {

        const totals = calculateTotals(FORMS.lighting);

        let name = document.getElementById("lightFullName").value;
        let mobile = document.getElementById("lightMobile").value;
        let event = document.getElementById("lightEventType").value;
        let date = document.getElementById("lightEventDate").value;
        let packageName = document.getElementById("lightingPackage").value;
        let vehicle = document.getElementById("vehicleLight").value;
        let generator = document.getElementById("generatorLight").value;
        let paymentMethod = document.getElementById("paymentMethodLight").value;

        let statement = `
HASSAN TENT SERVICE
============================
Lighting Booking Statement

Customer Information
----------------------------
Name: ${name}
Mobile: ${mobile}

Event Information
----------------------------
Event Type: ${event}
Event Date: ${date}

Lighting Package: ${packageName}
Package Price: ${pkr(totals.pkgPrice)}
Extra Equipment: ${pkr(totals.extraPrice)}
Vehicle (${vehicle}): ${pkr(totals.vehiclePrice)}
Generator (${generator}): ${pkr(totals.genPrice)}

----------------------------
TOTAL BILL: ${pkr(totals.grandTotal)}
Advance Paid: ${pkr(totals.advance)}
Balance Remaining: ${pkr(totals.balance)}
----------------------------

Payment Method: ${paymentMethod}

============================
Thank You For Booking With Us.
`;

        let blob = new Blob([statement], { type: "text/plain" });
        let link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "Lighting_Booking_Statement.txt";
        link.click();
}

document.querySelectorAll(".download-light-btn").forEach(function (btn) {
    btn.addEventListener("click", runLightDownload);
});

// =====================================================================
// INIT
// =====================================================================

document.addEventListener("DOMContentLoaded", function () {
    bindLiveUpdates(FORMS.sound);
    bindLiveUpdates(FORMS.lighting);
});


