document.addEventListener("DOMContentLoaded", function () {

    const loginForm = document.getElementById("loginForm");

    const loginBtn = document.getElementById("loginBtn");

    const loginBtnText = document.getElementById("loginBtnText");

    const loginSpinner = document.getElementById("loginSpinner");

    const loginMessage = document.getElementById("loginMessage");


    if (!loginForm) {
        return;
    }


    function showMessage(message, type) {

        loginMessage.textContent = message;

        loginMessage.className =
            "alert alert-" + type;

        loginMessage.style.display = "block";
    }


    loginForm.addEventListener("submit", async function (e) {

        e.preventDefault();


        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;


        if (!email || !password) {

            showMessage(
                "Please enter your email and password.",
                "danger"
            );

            return;
        }


        // =====================================================
        // DISABLE BUTTON WHILE LOGGING IN
        // =====================================================

        loginBtn.disabled = true;

        loginBtnText.textContent = "Logging in...";

        loginSpinner.classList.remove("d-none");


        try {

            const response = await fetch(
                "http://localhost/event-system/backend/login.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"
                    },

                    credentials: "include",

                    body: JSON.stringify({

                        email: email,

                        password: password

                    })
                }
            );


            const rawResponse =
                await response.text();


            console.log(
                "LOGIN RAW RESPONSE:",
                rawResponse
            );


            let result;


            try {

                result =
                    JSON.parse(rawResponse);

            } catch (error) {

                console.error(
                    "Invalid JSON:",
                    rawResponse
                );

                showMessage(
                    "Server returned an invalid response.",
                    "danger"
                );

                return;
            }


            console.log(
                "LOGIN RESPONSE:",
                result
            );


            // =================================================
            // LOGIN FAILED
            // =================================================

            if (!result.success) {

                showMessage(
                    result.error ||
                    "Login failed.",
                    "danger"
                );

                return;
            }


            // =================================================
            // MAKE SURE USER DATA EXISTS
            // =================================================

            if (!result.user) {

                showMessage(
                    "Login succeeded but user information was not returned.",
                    "danger"
                );

                return;
            }


            // =================================================
            // STORE USER INFORMATION
            // =================================================

            localStorage.setItem(
                "loggedInUser",
                JSON.stringify(result.user)
            );


            // =================================================
            // CHECK USER ROLE
            // =================================================

            const userRole =
                String(
                    result.user.role || ""
                ).toLowerCase().trim();


            console.log(
                "LOGGED IN USER ROLE:",
                userRole
            );


            // =================================================
            // SUCCESS MESSAGE
            // =================================================

            showMessage(
                "Login successful! Redirecting...",
                "success"
            );


            // =================================================
            // REDIRECT
            // =================================================

            setTimeout(function () {

                if (userRole === "admin") {

                    console.log(
                        "ADMIN LOGIN DETECTED - REDIRECTING TO ADMIN PANEL"
                    );


                    window.location.href =
                        "admin.html";


                } else {

                    console.log(
                        "NORMAL USER LOGIN - REDIRECTING TO INDEX"
                    );


                    window.location.href =
                        "index.html";

                }

            }, 800);


        } catch (error) {

            console.error(
                "Login connection error:",
                error
            );


            showMessage(
                "Unable to connect to the login server.",
                "danger"
            );


        } finally {

            loginBtn.disabled = false;

            loginBtnText.textContent = "Login";

            loginSpinner.classList.add("d-none");

        }

    });

});