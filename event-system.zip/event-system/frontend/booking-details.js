"use strict";

// =========================================================
// BOOKING DETAILS
// =========================================================

const BOOKING_DETAILS_API =
    "http://localhost/event-system/backend/admin/get_bookings.php";


// =========================================================
// VIEW BOOKING
// =========================================================

async function viewBooking(sourceOrIndex, possibleId) {

    try {

        // -------------------------------------------------
        // LOAD BOOKINGS
        // -------------------------------------------------

        const response =
            await fetch(
                BOOKING_DETAILS_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "BOOKING DETAILS RESPONSE:",
            rawResponse
        );


        let data;

        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Bookings API returned invalid JSON."
            );

        }


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load booking details."
            );

        }


        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load booking details."
            );

        }


        const bookings =
            Array.isArray(data.bookings)
                ? data.bookings
                : [];


        // -------------------------------------------------
        // FIND BOOKING
        // -------------------------------------------------

        let booking = null;


        // -------------------------------------------------
        // CASE 1
        // viewBooking(source, id)
        // -------------------------------------------------

        if (
            possibleId !== undefined
        ) {

            const source =
                String(
                    sourceOrIndex || ""
                ).toLowerCase();


            const bookingId =
                Number(
                    possibleId
                );


            booking =
                bookings.find(
                    item => {

                        return (
                            Number(item.id) ===
                                bookingId &&

                            String(
                                item.source || ""
                            ).toLowerCase() ===
                                source
                        );

                    }
                );

        }


        // -------------------------------------------------
        // CASE 2
        // viewBooking(index)
        // -------------------------------------------------

        else {

            const index =
                Number(
                    sourceOrIndex
                );


            if (
                !Number.isNaN(index)
            ) {

                /*
                 * The current admin.js uses the table
                 * index when creating the View button.
                 *
                 * The filtered table can differ from the
                 * original API array, so first try the
                 * corresponding booking.
                 */

                booking =
                    bookings[index];

            }

        }


        // -------------------------------------------------
        // NOT FOUND
        // -------------------------------------------------

        if (!booking) {

            showBookingDetailsError(
                "Booking details could not be found."
            );

            return;

        }


        console.log(
            "SELECTED BOOKING:",
            booking
        );


        // -------------------------------------------------
        // GET FULL DETAILS
        // -------------------------------------------------

        const details =
            booking.details &&
            typeof booking.details === "object"

                ? {
                    ...booking,
                    ...booking.details
                }

                : booking;


        // -------------------------------------------------
        // CUSTOMER
        // -------------------------------------------------

        setBookingValue(
            "bookingCustomerName",
            details.customer_name
        );

        setBookingValue(
            "bookingCustomerPhone",
            details.customer_phone
        );

        setBookingValue(
            "bookingCustomerEmail",
            details.email
        );

        setBookingValue(
            "bookingCustomerCnic",
            details.cnic
        );


        // -------------------------------------------------
        // EVENT
        // -------------------------------------------------

        setBookingValue(
            "bookingEventType",
            details.event_type
        );

        setBookingValue(
            "bookingEventDate",
            formatBookingDate(
                details.event_date
            )
        );

        setBookingValue(
            "bookingServiceType",
            details.service_type
        );

        setBookingValue(
            "bookingStartTime",
            formatTime(
                details.start_time
            )
        );

        setBookingValue(
            "bookingEndTime",
            formatTime(
                details.end_time
            )
        );

        setBookingValue(
            "bookingGuests",
            details.guests
        );


        // -------------------------------------------------
        // LOCATION
        // -------------------------------------------------

        setBookingValue(
            "bookingCity",
            details.city
        );

        setBookingValue(
            "bookingArea",
            details.area
        );

        setBookingValue(
            "bookingAddress",
            details.address
        );


        // -------------------------------------------------
        // PACKAGE / SERVICES
        // -------------------------------------------------

        setBookingValue(
            "bookingPackage",
            details.package_name
        );

        setBookingValue(
            "bookingPackagePrice",
            formatMoney(
                details.package_price
            )
        );

        setBookingValue(
            "bookingExtraPrice",
            formatMoney(
                details.extra_price
            )
        );

        setBookingValue(
            "bookingVehicle",
            details.vehicle
        );

        setBookingValue(
            "bookingVehiclePrice",
            formatMoney(
                details.vehicle_price
            )
        );

        setBookingValue(
            "bookingGenerator",
            details.generator
        );

        setBookingValue(
            "bookingGeneratorPrice",
            formatMoney(
                details.generator_price
            )
        );


        // -------------------------------------------------
        // PAYMENT
        // -------------------------------------------------

        setBookingValue(
            "bookingGrandTotal",
            formatMoney(
                details.grand_total
            )
        );

        setBookingValue(
            "bookingAdvancePayment",
            formatMoney(
                details.advance_payment
            )
        );

        setBookingValue(
            "bookingRemainingAmount",
            formatMoney(
                details.remaining_amount
            )
        );

        setBookingValue(
            "bookingPaymentMethod",
            details.payment_method
        );

        setBookingValue(
            "bookingConfirmVia",
            details.confirm_via
        );

        setBookingValue(
            "bookingStatus",
            details.status
        );


        // -------------------------------------------------
        // ADDITIONAL
        // -------------------------------------------------

        setBookingValue(
            "bookingNotes",
            details.notes
        );

        setBookingValue(
            "bookingCreatedAt",
            details.created_at
        );


        // -------------------------------------------------
        // OPEN MODAL
        // -------------------------------------------------

        openBookingModal();


    } catch (error) {

        console.error(
            "VIEW BOOKING ERROR:",
            error
        );


        showBookingDetailsError(
            error.message ||
            "Unable to load booking details."
        );

    }

}


// =========================================================
// SET VALUE
// =========================================================

function setBookingValue(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {
        return;
    }


    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        element.textContent =
            "—";

        return;

    }


    element.textContent =
        value;

}


// =========================================================
// FORMAT MONEY
// =========================================================

function formatMoney(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "—";

    }


    const number =
        Number(value);


    if (
        Number.isNaN(number)
    ) {

        return String(value);

    }


    return (
        "PKR " +
        number.toLocaleString(
            "en-PK",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }
        )
    );

}


// =========================================================
// FORMAT DATE
// =========================================================

function formatBookingDate(
    value
) {

    if (!value) {
        return "—";
    }


    const date =
        new Date(
            String(value)
                .replace(
                    " ",
                    "T"
                )
        );


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return String(value);

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// =========================================================
// FORMAT TIME
// =========================================================

function formatTime(
    value
) {

    if (!value) {
        return "—";
    }


    const text =
        String(value);


    return text.substring(
        0,
        5
    );

}


// =========================================================
// OPEN MODAL
// =========================================================

function openBookingModal() {

    const modalElement =
        document.getElementById(
            "bookingDetailsModal"
        );


    if (!modalElement) {

        console.error(
            "bookingDetailsModal was not found."
        );

        return;

    }


    if (
        typeof bootstrap ===
        "undefined"
    ) {

        console.error(
            "Bootstrap JavaScript is not loaded."
        );

        return;

    }


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


// =========================================================
// ERROR
// =========================================================

function showBookingDetailsError(
    message
) {

    console.error(
        message
    );


    if (
        typeof showToast ===
        "function"
    ) {

        showToast(
            message,
            "error"
        );

        return;

    }


    alert(
        message
    );

}

