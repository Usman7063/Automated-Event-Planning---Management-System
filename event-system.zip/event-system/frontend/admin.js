"use strict";


// =========================================================
// CONFIGURATION
// =========================================================

const DASHBOARD_API =
    "http://localhost/event-system/backend/admin/dashboard.php";

const USERS_API =
    "http://localhost/event-system/backend/admin/get_users.php";

const UPDATE_USER_STATUS_API =
    "http://localhost/event-system/backend/admin/update_user_status.php";

const BOOKINGS_API =
    "http://localhost/event-system/backend/admin/get_bookings.php";

const UPDATE_BOOKING_STATUS_API =
    "http://localhost/event-system/backend/admin/update_booking_status.php";

const LOGOUT_API =
    "http://localhost/event-system/backend/admin/admin_logout.php";


// =========================================================
// DOM
// =========================================================

const loadingOverlay =
    document.getElementById("loadingOverlay");

const sidebar =
    document.getElementById("adminSidebar");

const sidebarOverlay =
    document.getElementById("sidebarOverlay");

const sidebarToggle =
    document.getElementById("sidebarToggle");

const refreshBtn =
    document.getElementById("refreshBtn");

const logoutLink =
    document.getElementById("logoutLink");


// =========================================================
// GLOBAL DATA
// =========================================================

let allUsers = [];

let allBookings = [];


// =========================================================
// INITIALIZE
// =========================================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        setupNavigation();

        setupSidebar();

        setupRefresh();

        setupLogout();

        setupUserManagement();

        setupBookingManagement();

        loadDashboard();

        loadUsers();

    }
);


// =========================================================
// LOAD DASHBOARD
// =========================================================

async function loadDashboard() {

    showLoading(true);

    try {

        const response =
            await fetch(
                DASHBOARD_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "ADMIN DASHBOARD RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Server returned invalid JSON."
            );

        }


        // -------------------------------------------------
        // ACCESS DENIED
        // -------------------------------------------------

        if (
            response.status === 401 ||
            response.status === 403
        ) {

            throw new Error(
                data.error ||
                "Administrator privileges are required."
            );

        }


        // -------------------------------------------------
        // SERVER ERROR
        // -------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load admin dashboard."
            );

        }


        // -------------------------------------------------
        // API ERROR
        // -------------------------------------------------

        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load dashboard."
            );

        }


        // -------------------------------------------------
        // POPULATE DASHBOARD
        // -------------------------------------------------

        populateAdmin(data);

        populateStatistics(
            data.statistics
        );


        // -------------------------------------------------
        // DASHBOARD USERS
        // -------------------------------------------------

        if (data.users) {

            populateUsers(
                data.users
            );

        }


    } catch (error) {

        console.error(
            "ADMIN DASHBOARD ERROR:",
            error
        );


        showToast(
            error.message ||
            "Unable to load dashboard.",
            "error"
        );


    } finally {

        showLoading(false);

    }

}


// =========================================================
// ADMIN INFORMATION
// =========================================================

function populateAdmin(data) {

    const admin =
        data.admin || {};


    const name =
        admin.admin_name ||
        admin.full_name ||
        "Administrator";


    const email =
        admin.admin_email ||
        admin.email ||
        "admin@gmail.com";


    setText(
        "sidebarAdminName",
        name
    );


    setText(
        "sidebarAdminEmail",
        email
    );


    setText(
        "topbarAdminName",
        name
    );


    setText(
        "welcomeAdminName",
        name
    );

}


// =========================================================
// STATISTICS
// =========================================================

function populateStatistics(stats) {

    if (!stats) {
        return;
    }


    // -----------------------------------------------------
    // USERS
    // -----------------------------------------------------

    const users =
        stats.users || {};


    setText(
        "totalUsers",
        users.total || 0
    );


    setText(
        "overviewUsers",
        users.total || 0
    );


    setText(
        "activeUsers",
        users.active || 0
    );


    setText(
        "inactiveUsers",
        users.inactive || 0
    );


    setText(
        "rejectedUsers",
        users.rejected || 0
    );


    // -----------------------------------------------------
    // BOOKINGS
    // -----------------------------------------------------

    const bookings =
        stats.bookings || {};


    setText(
        "totalBookings",
        bookings.total || 0
    );


    setText(
        "pendingBookings",
        bookings.pending || 0
    );


    setText(
        "approvedBookings",
        bookings.approved || 0
    );


    setText(
        "rejectedBookings",
        bookings.rejected || 0
    );


    setText(
        "sidebarPendingBookings",
        bookings.pending || 0
    );


    // -----------------------------------------------------
    // EVENTS
    // -----------------------------------------------------

    const events =
        stats.events || {};


    setText(
        "totalEvents",
        events.total || 0
    );


    // -----------------------------------------------------
    // VENDORS
    // -----------------------------------------------------

    const vendors =
        stats.vendors || {};


    setText(
        "totalVendors",
        vendors.total || 0
    );


    setText(
        "totalVendors2",
        vendors.total || 0
    );


    setText(
        "approvedVendors",
        vendors.approved || 0
    );


    setText(
        "pendingVendors",
        vendors.pending || 0
    );


    setText(
        "rejectedVendors",
        vendors.rejected || 0
    );


    // -----------------------------------------------------
    // INDIVIDUAL BOOKING SYSTEMS
    // -----------------------------------------------------

    const booking =
        stats.booking || {};


    const booking1 =
        stats.booking1 || {};


    const booking2 =
        stats.booking2 || {};


    setText(
        "bookingTotal",
        booking.total || 0
    );


    setText(
        "booking1Total",
        booking1.total || 0
    );


    setText(
        "booking2Total",
        booking2.total || 0
    );

}


// =========================================================
// DASHBOARD USERS
// =========================================================

function populateUsers(users) {

    if (!users) {
        return;
    }

    // This function is intentionally kept simple.
    // The complete users table is handled by loadUsers()
    // and renderUsers().

}


// =========================================================
// USER MANAGEMENT
// =========================================================

// ---------------------------------------------------------
// LOAD USERS
// ---------------------------------------------------------

async function loadUsers() {

    const tableBody =
        document.getElementById(
            "usersTableBody"
        );


    const emptyState =
        document.getElementById(
            "usersEmptyState"
        );


    if (!tableBody) {
        return;
    }


    tableBody.innerHTML = `
        <tr>
            <td
                colspan="8"
                class="text-center py-5"
            >
                <i class="fa-solid fa-spinner fa-spin"></i>
                Loading users...
            </td>
        </tr>
    `;


    try {

        const response =
            await fetch(
                USERS_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "ADMIN USERS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Users API returned invalid JSON."
            );

        }


        // -------------------------------------------------
        // ACCESS DENIED
        // -------------------------------------------------

        if (
            response.status === 401 ||
            response.status === 403
        ) {

            throw new Error(
                data.error ||
                "Administrator privileges are required."
            );

        }


        // -------------------------------------------------
        // SERVER ERROR
        // -------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load users."
            );

        }


        // -------------------------------------------------
        // API ERROR
        // -------------------------------------------------

        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load users."
            );

        }


        // -------------------------------------------------
        // STORE USERS
        // -------------------------------------------------

        allUsers =
            Array.isArray(data.users)
                ? data.users
                : [];


        console.log(
            "USERS LOADED:",
            allUsers
        );


        renderUsers(
            allUsers
        );


    } catch (error) {

        console.error(
            "LOAD USERS ERROR:",
            error
        );


        tableBody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="text-center py-5 text-danger"
                >
                    <i class="fa-solid fa-circle-exclamation"></i>
                    ${escapeHtml(error.message)}
                </td>
            </tr>
        `;


        if (emptyState) {

            emptyState.classList.add(
                "d-none"
            );

        }

    }

}


// =========================================================
// RENDER USERS
// =========================================================

function renderUsers(users) {

    const tableBody =
        document.getElementById(
            "usersTableBody"
        );


    const emptyState =
        document.getElementById(
            "usersEmptyState"
        );


    if (!tableBody) {
        return;
    }


    // -----------------------------------------------------
    // NO USERS
    // -----------------------------------------------------

    if (
        !users ||
        users.length === 0
    ) {

        tableBody.innerHTML = "";


        if (emptyState) {

            emptyState.classList.remove(
                "d-none"
            );

        }


        return;

    }


    // -----------------------------------------------------
    // HIDE EMPTY STATE
    // -----------------------------------------------------

    if (emptyState) {

        emptyState.classList.add(
            "d-none"
        );

    }


    // -----------------------------------------------------
    // RENDER USERS
    // -----------------------------------------------------

    tableBody.innerHTML =
        users.map(
            (user, index) => {

                const userId =
                    Number(user.id);


                const currentStatus =
                    String(
                        user.status || ""
                    ).toLowerCase();


                return `
                    <tr>

                        <td>
                            ${index + 1}
                        </td>


                        <td>
                            <strong>
                                ${escapeHtml(
                                    user.full_name ||
                                    "—"
                                )}
                            </strong>
                        </td>


                        <td>
                            ${escapeHtml(
                                user.email ||
                                "—"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                user.phone ||
                                "—"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                user.cnic ||
                                "—"
                            )}
                        </td>


                        <td>
                            ${getStatusBadge(
                                user.status
                            )}
                        </td>


                        <td>
                            ${formatDate(
                                user.created_at
                            )}
                        </td>


                        <td>

                            <div
                                class="d-flex gap-2 flex-wrap"
                            >

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-primary"
                                    onclick="viewUser(${userId})"
                                    title="View User"
                                >
                                    <i
                                        class="fa-solid fa-eye"
                                    ></i>
                                </button>


                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-success"
                                    onclick="updateUserStatus(${userId}, 'approved')"
                                    title="Approve User"
                                    ${
                                        currentStatus ===
                                        "approved"
                                            ? "disabled"
                                            : ""
                                    }
                                >
                                    <i
                                        class="fa-solid fa-user-check"
                                    ></i>
                                </button>


                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-warning"
                                    onclick="updateUserStatus(${userId}, 'inactive')"
                                    title="Deactivate User"
                                    ${
                                        currentStatus ===
                                        "inactive"
                                            ? "disabled"
                                            : ""
                                    }
                                >
                                    <i
                                        class="fa-solid fa-user-slash"
                                    ></i>
                                </button>


                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="updateUserStatus(${userId}, 'rejected')"
                                    title="Reject User"
                                    ${
                                        currentStatus ===
                                        "rejected"
                                            ? "disabled"
                                            : ""
                                    }
                                >
                                    <i
                                        class="fa-solid fa-user-xmark"
                                    ></i>
                                </button>

                            </div>

                        </td>

                    </tr>
                `;

            }
        ).join("");

}


// =========================================================
// UPDATE USER STATUS
// =========================================================

async function updateUserStatus(
    userId,
    newStatus
) {

    if (!userId || !newStatus) {
        return;
    }


    const user =
        allUsers.find(
            item =>
                Number(item.id) ===
                Number(userId)
        );


    if (!user) {

        showToast(
            "User not found.",
            "error"
        );

        return;

    }


    const statusLabels = {

        approved:
            "approve",

        inactive:
            "deactivate",

        rejected:
            "reject"

    };


    const action =
        statusLabels[newStatus] ||
        "update";


    const confirmed =
        confirm(
            `Are you sure you want to ${action} "${user.full_name}"?`
        );


    if (!confirmed) {
        return;
    }


    try {

        const response =
            await fetch(
                UPDATE_USER_STATUS_API,
                {
                    method: "POST",

                    credentials: "include",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"
                    },

                    body:
                        JSON.stringify({

                            user_id:
                                Number(userId),

                            status:
                                newStatus

                        })
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "UPDATE USER STATUS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Status update API returned invalid JSON."
            );

        }


        // -------------------------------------------------
        // ACCESS DENIED
        // -------------------------------------------------

        if (
            response.status === 401 ||
            response.status === 403
        ) {

            throw new Error(
                data.error ||
                "Administrator privileges are required."
            );

        }


        // -------------------------------------------------
        // SERVER ERROR
        // -------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to update user status."
            );

        }


        // -------------------------------------------------
        // API ERROR
        // -------------------------------------------------

        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to update user status."
            );

        }


        // -------------------------------------------------
        // UPDATE LOCAL USER
        // -------------------------------------------------

        user.status =
            newStatus;


        // -------------------------------------------------
        // REFRESH USERS
        // -------------------------------------------------

        filterUsers();


        // -------------------------------------------------
        // SUCCESS MESSAGE
        // -------------------------------------------------

        showToast(
            data.message ||
            "User status updated successfully.",
            "success"
        );


        // -------------------------------------------------
        // REFRESH DASHBOARD
        // -------------------------------------------------

        await loadDashboard();


    } catch (error) {

        console.error(
            "UPDATE USER STATUS ERROR:",
            error
        );


        showToast(
            error.message ||
            "Unable to update user status.",
            "error"
        );

    }

}


// =========================================================
// USER SEARCH + FILTER
// =========================================================

function setupUserManagement() {

    const searchInput =
        document.getElementById(
            "userSearch"
        );


    const statusFilter =
        document.getElementById(
            "userStatusFilter"
        );


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterUsers
        );

    }


    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            filterUsers
        );

    }

}


// =========================================================
// FILTER USERS
// =========================================================

function filterUsers() {

    const searchInput =
        document.getElementById(
            "userSearch"
        );


    const statusFilter =
        document.getElementById(
            "userStatusFilter"
        );


    const search =
        (
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const status =
        statusFilter?.value ||
        "";


    const filteredUsers =
        allUsers.filter(
            user => {

                const name =
                    String(
                        user.full_name ||
                        ""
                    )
                    .toLowerCase();


                const email =
                    String(
                        user.email ||
                        ""
                    )
                    .toLowerCase();


                const phone =
                    String(
                        user.phone ||
                        ""
                    )
                    .toLowerCase();


                const cnic =
                    String(
                        user.cnic ||
                        ""
                    )
                    .toLowerCase();


                const matchesSearch =
                    !search ||
                    name.includes(search) ||
                    email.includes(search) ||
                    phone.includes(search) ||
                    cnic.includes(search);


                const matchesStatus =
                    !status ||
                    String(
                        user.status ||
                        ""
                    ).toLowerCase() ===
                    status.toLowerCase();


                return (
                    matchesSearch &&
                    matchesStatus
                );

            }
        );


    renderUsers(
        filteredUsers
    );

}


// =========================================================
// VIEW USER
// =========================================================

function viewUser(userId) {

    const user =
        allUsers.find(
            item =>
                Number(item.id) ===
                Number(userId)
        );


    if (!user) {

        showToast(
            "User not found.",
            "error"
        );

        return;

    }


    alert(
        "User: " +
        (user.full_name || "—") +
        "\nEmail: " +
        (user.email || "—") +
        "\nPhone: " +
        (user.phone || "—") +
        "\nCNIC: " +
        (user.cnic || "—") +
        "\nStatus: " +
        (user.status || "—")
    );

}


// =========================================================
// BOOKING MANAGEMENT
// =========================================================

// ---------------------------------------------------------
// LOAD BOOKINGS
// ---------------------------------------------------------

async function loadBookings() {

    const tableBody =
        document.getElementById(
            "bookingsTableBody"
        );


    const emptyState =
        document.getElementById(
            "bookingsEmptyState"
        );


    if (!tableBody) {
        return;
    }


    tableBody.innerHTML = `
        <tr>
            <td
                colspan="8"
                class="text-center py-5"
            >
                <i class="fa-solid fa-spinner fa-spin"></i>
                Loading bookings...
            </td>
        </tr>
    `;


    try {

        const response =
            await fetch(
                BOOKINGS_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "ADMIN BOOKINGS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Bookings API returned invalid JSON."
            );

        }


        // -------------------------------------------------
        // ACCESS DENIED
        // -------------------------------------------------

        if (
            response.status === 401 ||
            response.status === 403
        ) {

            throw new Error(
                data.error ||
                "Administrator privileges are required."
            );

        }


        // -------------------------------------------------
        // SERVER ERROR
        // -------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load bookings."
            );

        }


        // -------------------------------------------------
        // API ERROR
        // -------------------------------------------------

        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load bookings."
            );

        }


        // -------------------------------------------------
        // STORE BOOKINGS
        // -------------------------------------------------

        allBookings =
            Array.isArray(data.bookings)
                ? data.bookings
                : [];


        console.log(
            "BOOKINGS LOADED:",
            allBookings
        );


        renderBookings(
            allBookings
        );


    } catch (error) {

        console.error(
            "LOAD BOOKINGS ERROR:",
            error
        );


        tableBody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="text-center py-5 text-danger"
                >
                    <i
                        class="fa-solid fa-circle-exclamation"
                    ></i>
                    ${escapeHtml(error.message)}
                </td>
            </tr>
        `;


        if (emptyState) {

            emptyState.classList.add(
                "d-none"
            );

        }

    }

}



// =========================================================
// RENDER BOOKINGS
// =========================================================

function renderBookings(bookings) {

    const tableBody =
        document.getElementById(
            "bookingsTableBody"
        );


    const emptyState =
        document.getElementById(
            "bookingsEmptyState"
        );


    if (!tableBody) {
        return;
    }


    // -----------------------------------------------------
    // EMPTY STATE
    // -----------------------------------------------------

    if (
        !bookings ||
        bookings.length === 0
    ) {

        tableBody.innerHTML = "";


        if (emptyState) {

            emptyState.classList.remove(
                "d-none"
            );

        }


        return;

    }


    if (emptyState) {

        emptyState.classList.add(
            "d-none"
        );

    }


    // -----------------------------------------------------
    // RENDER TABLE
    // -----------------------------------------------------

    tableBody.innerHTML =
        bookings.map(
            (booking, index) => {

                const status =
                    String(
                        booking.status ||
                        "unknown"
                    ).toLowerCase();


                const source =
                    String(
                        booking.source ||
                        "booking"
                    ).toLowerCase();


                // -----------------------------------------
                // ACTION BUTTONS
                // -----------------------------------------

                let actionButtons = `

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-primary"
                        onclick="viewBooking(
                            '${escapeHtml(source)}',
                            ${Number(booking.id)}
                        )"
                        title="View Booking"
                    >
                        <i
                            class="fa-solid fa-eye"
                        ></i>
                    </button>

                `;


                // -----------------------------------------
                // APPROVE / REJECT
                // -----------------------------------------

                if (
                    status ===
                    "pending"
                ) {

                    actionButtons += `

                        <button
                            type="button"
                            class="btn btn-sm btn-outline-success ms-1"
                            onclick="updateBookingStatus(
                                ${Number(booking.id)},
                                '${escapeHtml(source)}',
                                'approved'
                            )"
                            title="Approve Booking"
                        >
                            <i
                                class="fa-solid fa-check"
                            ></i>
                        </button>


                        <button
                            type="button"
                            class="btn btn-sm btn-outline-danger ms-1"
                            onclick="updateBookingStatus(
                                ${Number(booking.id)},
                                '${escapeHtml(source)}',
                                'rejected'
                            )"
                            title="Reject Booking"
                        >
                            <i
                                class="fa-solid fa-xmark"
                            ></i>
                        </button>

                    `;

                }


                // -----------------------------------------
                // PRICE INFORMATION
                // -----------------------------------------

                let priceDisplay = "—";


                if (
                    source === "booking1"
                ) {

                    if (
                        booking.grand_total !== null &&
                        booking.grand_total !== undefined &&
                        booking.grand_total !== ""
                    ) {

                        priceDisplay =
                            "Rs. " +
                            Number(
                                booking.grand_total
                            ).toLocaleString();

                    } else {

                        priceDisplay = "—";

                    }

                }


                // -----------------------------------------
                // RETURN ROW
                // -----------------------------------------

                return `

                    <tr>

                        <td>
                            ${index + 1}
                        </td>


                        <td>
                            <strong>
                                ${escapeHtml(
                                    booking.customer_name ||
                                    "—"
                                )}
                            </strong>
                        </td>


                        <td>
                            ${escapeHtml(
                                booking.customer_phone ||
                                "—"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                booking.event_type ||
                                "—"
                            )}
                        </td>


                        <td>
                            ${formatDate(
                                booking.event_date
                            )}
                        </td>


                        <td>
                            ${getBookingSourceBadge(
                                booking.source
                            )}
                        </td>


                        <td>
                            ${priceDisplay}
                        </td>


                        <td>
                            ${getStatusBadge(
                                booking.status
                            )}
                        </td>


                        <td>

                            <div
                                class="d-flex align-items-center"
                            >

                                ${actionButtons}

                            </div>

                        </td>

                    </tr>

                `;

            }
        ).join("");

}


// =========================================================
// VIEW BOOKING
// =========================================================

function viewBooking(
    source,
    bookingId
) {

    const booking =
        allBookings.find(
            function (item) {

                return (
                    String(item.source).toLowerCase() ===
                    String(source).toLowerCase() &&
                    Number(item.id) ===
                    Number(bookingId)
                );

            }
        );


    if (!booking) {

        showToast(
            "Booking not found.",
            "error"
        );

        return;

    }


    const details =
        booking.details ||
        {};


    alert(
        "Booking Details" +

        "\n\nCustomer: " +
        (
            details.customer_name ||
            booking.customer_name ||
            "—"
        ) +

        "\nPhone: " +
        (
            details.customer_phone ||
            booking.customer_phone ||
            "—"
        ) +

        "\nEmail: " +
        (
            details.email ||
            booking.email ||
            "—"
        ) +

        "\nCNIC: " +
        (
            details.cnic ||
            booking.cnic ||
            "—"
        ) +

        "\nEvent Type: " +
        (
            details.event_type ||
            booking.event_type ||
            "—"
        ) +

        "\nEvent Date: " +
        (
            details.event_date ||
            booking.event_date ||
            "—"
        ) +

        "\nStart Time: " +
        (
            details.start_time ||
            booking.start_time ||
            "—"
        ) +

        "\nEnd Time: " +
        (
            details.end_time ||
            booking.end_time ||
            "—"
        ) +

        "\nTransport: " +
        (
            details.transport ||
            booking.transport ||
            "—"
        ) +

        "\nGuests: " +
        (
            details.guests ||
            booking.guests ||
            "—"
        ) +

        "\nCity: " +
        (
            details.city ||
            booking.city ||
            "—"
        ) +

        "\nArea: " +
        (
            details.area ||
            booking.area ||
            "—"
        ) +

        "\nAddress: " +
        (
            details.address ||
            booking.address ||
            "—"
        ) +

        "\nService: " +
        (
            details.service_type ||
            booking.service_type ||
            "—"
        ) +

        "\nPackage: " +
        (
            details.package_name ||
            booking.package_name ||
            "—"
        ) +

        "\nPackage Price: " +
        (
            details.package_price ||
            booking.package_price ||
            "—"
        ) +

        "\nExtra Price: " +
        (
            details.extra_price ||
            booking.extra_price ||
            "—"
        ) +

        "\nVehicle: " +
        (
            details.vehicle ||
            booking.vehicle ||
            "—"
        ) +

        "\nVehicle Price: " +
        (
            details.vehicle_price ||
            booking.vehicle_price ||
            "—"
        ) +

        "\nGenerator: " +
        (
            details.generator ||
            booking.generator ||
            "—"
        ) +

        "\nGenerator Price: " +
        (
            details.generator_price ||
            booking.generator_price ||
            "—"
        ) +

        "\nGrand Total: " +
        (
            details.grand_total ||
            booking.grand_total ||
            "—"
        ) +

        "\nAdvance Payment: " +
        (
            details.advance_payment ??
            booking.advance_payment ??
            "—"
        ) +

        "\nRemaining Amount: " +
        (
            details.remaining_amount ??
            booking.remaining_amount ??
            "—"
        ) +

        "\nPayment Method: " +
        (
            details.payment_method ||
            booking.payment_method ||
            "—"
        ) +

        "\nStatus: " +
        (
            booking.status ||
            "—"
        )
    );

}




// =========================================================
// UPDATE BOOKING STATUS
// =========================================================

async function updateBookingStatus(
    bookingId,
    source,
    newStatus
) {

    if (
        !bookingId ||
        !source ||
        !newStatus
    ) {

        return;

    }


    const action =
        newStatus === "approved"
            ? "approve"
            : "reject";


    const confirmed =
        confirm(
            `Are you sure you want to ${action} this booking?`
        );


    if (!confirmed) {
        return;
    }


    try {

        const response =
            await fetch(
                UPDATE_BOOKING_STATUS_API,
                {
                    method: "POST",

                    credentials: "include",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"
                    },

                    body:
                        JSON.stringify({

                            booking_id:
                                Number(bookingId),

                            source:
                                source,

                            status:
                                newStatus

                        })
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "UPDATE BOOKING STATUS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Server returned invalid JSON."
            );

        }


        // -------------------------------------------------
        // ACCESS DENIED
        // -------------------------------------------------

        if (
            response.status === 401 ||
            response.status === 403
        ) {

            throw new Error(
                data.error ||
                "Administrator privileges are required."
            );

        }


        // -------------------------------------------------
        // SERVER ERROR
        // -------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to update booking status."
            );

        }


        // -------------------------------------------------
        // API ERROR
        // -------------------------------------------------

        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to update booking status."
            );

        }


        // -------------------------------------------------
        // SUCCESS
        // -------------------------------------------------

        showToast(
            data.message ||
            "Booking status updated successfully.",
            "success"
        );


        // -------------------------------------------------
        // REFRESH DASHBOARD
        // -------------------------------------------------

        await loadDashboard();


        // -------------------------------------------------
        // REFRESH BOOKINGS
        // -------------------------------------------------

        await loadBookings();


    } catch (error) {

        console.error(
            "UPDATE BOOKING STATUS ERROR:",
            error
        );


        showToast(
            error.message ||
            "Unable to update booking status.",
            "error"
        );

    }

}


// =========================================================
// BOOKING SOURCE BADGE
// =========================================================

function getBookingSourceBadge(source) {

    const value =
        String(
            source || ""
        ).toLowerCase();


    let label =
        "Unknown";


    if (
        value ===
        "booking"
    ) {

        label =
            "Booking";

    } else if (
        value ===
        "booking1"
    ) {

        label =
            "Booking 1";

    } else if (
        value ===
        "booking2"
    ) {

        label =
            "Booking 2";

    }


    return `
        <span class="badge bg-secondary">
            ${escapeHtml(label)}
        </span>
    `;

}


// =========================================================
// BOOKING SEARCH + FILTER
// =========================================================

function setupBookingManagement() {

    const searchInput =
        document.getElementById(
            "bookingSearch"
        );


    const statusFilter =
        document.getElementById(
            "bookingStatusFilter"
        );


    const sourceFilter =
        document.getElementById(
            "bookingSourceFilter"
        );


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterBookings
        );

    }


    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            filterBookings
        );

    }


    if (sourceFilter) {

        sourceFilter.addEventListener(
            "change",
            filterBookings
        );

    }

}


// =========================================================
// FILTER BOOKINGS
// =========================================================

function filterBookings() {

    const searchInput =
        document.getElementById(
            "bookingSearch"
        );


    const statusFilter =
        document.getElementById(
            "bookingStatusFilter"
        );


    const sourceFilter =
        document.getElementById(
            "bookingSourceFilter"
        );


    const search =
        (
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const status =
        statusFilter?.value ||
        "";


    const source =
        sourceFilter?.value ||
        "";


    const filteredBookings =
        allBookings.filter(
            booking => {

                const customerName =
                    String(
                        booking.customer_name ||
                        ""
                    )
                    .toLowerCase();


                const customerPhone =
                    String(
                        booking.customer_phone ||
                        ""
                    )
                    .toLowerCase();


                const eventType =
                    String(
                        booking.event_type ||
                        ""
                    )
                    .toLowerCase();


                const matchesSearch =
                    !search ||
                    customerName.includes(search) ||
                    customerPhone.includes(search) ||
                    eventType.includes(search);


                const matchesStatus =
                    !status ||
                    String(
                        booking.status ||
                        ""
                    )
                    .toLowerCase() ===
                    status.toLowerCase();


                const matchesSource =
                    !source ||
                    String(
                        booking.source ||
                        ""
                    )
                    .toLowerCase() ===
                    source.toLowerCase();


                return (
                    matchesSearch &&
                    matchesStatus &&
                    matchesSource
                );

            }
        );


    renderBookings(
        filteredBookings
    );

}


// =========================================================
// STATUS BADGE
// =========================================================

function getStatusBadge(status) {

    const value =
        String(
            status || "unknown"
        )
        .toLowerCase();


    let badgeClass =
        "bg-secondary";


    if (
        value === "active" ||
        value === "approved"
    ) {

        badgeClass =
            "bg-success";

    }


    if (
        value === "inactive"
    ) {

        badgeClass =
            "bg-warning text-dark";

    }


    if (
        value === "rejected"
    ) {

        badgeClass =
            "bg-danger";

    }


    return `
        <span class="badge ${badgeClass}">
            ${escapeHtml(
                status ||
                "Unknown"
            )}
        </span>
    `;

}


// =========================================================
// FORMAT DATE
// =========================================================

function formatDate(dateString) {

    if (!dateString) {
        return "—";
    }


    const date =
        new Date(
            String(dateString).replace(
                " ",
                "T"
            )
        );


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return escapeHtml(
            dateString
        );

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day:
                "2-digit",

            month:
                "short",

            year:
                "numeric"
        }
    );

}


// =========================================================
// NAVIGATION
// =========================================================

function setupNavigation() {

    const navLinks =
        document.querySelectorAll(
            ".admin-nav-link[data-section]"
        );


    navLinks.forEach(
        link => {

            link.addEventListener(
                "click",
                event => {

                    event.preventDefault();


                    const section =
                        link.dataset.section;


                    switchSection(
                        section
                    );


                    closeSidebar();

                }
            );

        }
    );

}


// =========================================================
// SWITCH SECTION
// =========================================================

function switchSection(section) {

    // -----------------------------------------------------
    // Hide all sections
    // -----------------------------------------------------

    const sections =
        document.querySelectorAll(
            ".admin-section"
        );


    sections.forEach(
        item => {

            item.classList.remove(
                "active-section"
            );

        }
    );


    // -----------------------------------------------------
    // Show selected section
    // -----------------------------------------------------

    const target =
        document.getElementById(
            section + "Section"
        );


    if (target) {

        target.classList.add(
            "active-section"
        );

    }


    // -----------------------------------------------------
    // LOAD SECTION DATA
    // -----------------------------------------------------

    if (
        section ===
        "bookings"
    ) {

        loadBookings();

    }


    if (
        section ===
        "users"
    ) {

        loadUsers();

    }


    if (
        section ===
        "dashboard"
    ) {

        loadDashboard();

    }


    // -----------------------------------------------------
    // ACTIVE NAVIGATION
    // -----------------------------------------------------

    const navLinks =
        document.querySelectorAll(
            ".admin-nav-link[data-section]"
        );


    navLinks.forEach(
        link => {

            link.classList.remove(
                "active"
            );


            if (
                link.dataset.section ===
                section
            ) {

                link.classList.add(
                    "active"
                );

            }

        }
    );


    // -----------------------------------------------------
    // PAGE TITLE
    // -----------------------------------------------------

    const titles = {

        dashboard: [
            "Dashboard",
            "Overview of your event management system"
        ],

        users: [
            "User Management",
            "Manage registered customers"
        ],

        bookings: [
            "Booking Management",
            "Manage customer bookings"
        ],

        vendors: [
            "Vendor Management",
            "Manage event service vendors"
        ],

        events: [
            "Event Management",
            "Manage customer events"
        ],

        settings: [
            "Admin Settings",
            "Manage administrator settings"
        ]

    };


    const title =
        titles[section];


    if (title) {

        setText(
            "pageTitle",
            title[0]
        );


        setText(
            "pageSubtitle",
            title[1]
        );

    }

}


// =========================================================
// SIDEBAR
// =========================================================

function setupSidebar() {

    if (!sidebarToggle) {
        return;
    }


    sidebarToggle.addEventListener(
        "click",
        () => {

            if (sidebar) {

                sidebar.classList.toggle(
                    "sidebar-open"
                );

            }


            if (sidebarOverlay) {

                sidebarOverlay.classList.toggle(
                    "show"
                );

            }

        }
    );


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            "click",
            closeSidebar
        );

    }

}


// =========================================================
// CLOSE SIDEBAR
// =========================================================

function closeSidebar() {

    if (sidebar) {

        sidebar.classList.remove(
            "sidebar-open"
        );

    }


    if (sidebarOverlay) {

        sidebarOverlay.classList.remove(
            "show"
        );

    }

}


// =========================================================
// REFRESH
// =========================================================

function setupRefresh() {

    if (!refreshBtn) {
        return;
    }


    refreshBtn.addEventListener(
        "click",
        async () => {

            const icon =
                refreshBtn.querySelector(
                    "i"
                );


            icon?.classList.add(
                "fa-spin"
            );


            try {

                await loadDashboard();


                // Refresh users if user section exists

                if (
                    document.getElementById(
                        "usersTableBody"
                    )
                ) {

                    await loadUsers();

                }


                // Refresh bookings if booking section exists

                if (
                    document.getElementById(
                        "bookingsTableBody"
                    )
                ) {

                    await loadBookings();

                }


            } finally {

                icon?.classList.remove(
                    "fa-spin"
                );

            }

        }
    );

}


// =========================================================
// LOGOUT
// =========================================================

function setupLogout() {

    if (!logoutLink) {
        return;
    }


    logoutLink.addEventListener(
        "click",
        async event => {

            event.preventDefault();


            const confirmed =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (!confirmed) {
                return;
            }


            console.log(
                "ADMIN LOGOUT STARTED"
            );


            // =================================================
            // REMOVE FRONTEND LOGIN STATE
            // =================================================

            localStorage.removeItem(
                "loggedInUser"
            );


            // =================================================
            // DESTROY PHP SESSION
            // =================================================

            try {

                const response =
                    await fetch(
                        LOGOUT_API,
                        {
                            method: "POST",

                            credentials:
                                "include",

                            headers: {
                                "Accept":
                                    "application/json"
                            }
                        }
                    );


                const rawResponse =
                    await response.text();


                console.log(
                    "ADMIN LOGOUT STATUS:",
                    response.status
                );


                console.log(
                    "ADMIN LOGOUT RESPONSE:",
                    rawResponse
                );


            } catch (error) {

                console.error(
                    "Logout request failed:",
                    error
                );

            }


            // =================================================
            // GO TO ADMIN LOGIN PAGE
            // =================================================

            window.location.href =
                "login.html";

        }
    );

}


// =========================================================
// HELPER: SET TEXT
// =========================================================

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {
        return;
    }


    element.textContent =
        value;

}


// =========================================================
// LOADING
// =========================================================

function showLoading(show) {

    if (!loadingOverlay) {
        return;
    }


    loadingOverlay.style.display =
        show
            ? "flex"
            : "none";

}


// =========================================================
// TOAST
// =========================================================

function showToast(
    message,
    type = "info"
) {

    const toast =
        document.getElementById(
            "adminToast"
        );


    const toastMessage =
        document.getElementById(
            "toastMessage"
        );


    const toastIcon =
        document.getElementById(
            "toastIcon"
        );


    if (!toast) {
        return;
    }


    // -----------------------------------------------------
    // MESSAGE
    // -----------------------------------------------------

    if (toastMessage) {

        toastMessage.textContent =
            message;

    }


    // -----------------------------------------------------
    // ICON
    // -----------------------------------------------------

    if (toastIcon) {

        if (
            type ===
            "success"
        ) {

            toastIcon.className =
                "fa-solid fa-circle-check";


        } else if (
            type ===
            "error"
        ) {

            toastIcon.className =
                "fa-solid fa-circle-exclamation";


        } else if (
            type ===
            "warning"
        ) {

            toastIcon.className =
                "fa-solid fa-triangle-exclamation";


        } else {

            toastIcon.className =
                "fa-solid fa-circle-info";

        }

    }


    // -----------------------------------------------------
    // SHOW
    // -----------------------------------------------------

    toast.classList.add(
        "show"
    );


    // -----------------------------------------------------
    // AUTO HIDE
    // -----------------------------------------------------

    setTimeout(
        () => {

            toast.classList.remove(
                "show"
            );

        },
        3500
    );

}


// =========================================================
// ESCAPE HTML
// =========================================================

function escapeHtml(value) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}