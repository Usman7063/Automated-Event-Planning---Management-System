// ======================================================
// HASSAN TENT SERVICE
// PAYMENT JAVASCRIPT
// BACKEND CONNECTED VERSION
// ======================================================


// ======================================================
// BACKEND URL
// ======================================================

const PAYMENT_BACKEND_URL =
    "http://localhost/event-system/backend/payment.php";


// ======================================================
// GET ELEMENTS
// ======================================================

console.log(
    "Local Storage Total:",
    localStorage.getItem("bookingTotal")
);


const grandTotal =
    document.getElementById("grandTotal");


const finalTotal =
    document.getElementById("finalTotal");


const itemsTotal =
    document.getElementById("itemsTotal");


const vehicleChargesWrap =
    document.getElementById("vehicleChargesWrap");


const vehicleChargesDisplay =
    document.getElementById("vehicleChargesDisplay");


const advanceAmount =
    document.getElementById("advanceAmount");


const remainingAmount =
    document.getElementById("remainingAmount");


const paymentCards =
    document.querySelectorAll(
        ".payment-option-card"
    );


const paymentMethods =
    document.querySelectorAll(
        ".paymentMethod"
    );


const paymentMethodError =
    document.getElementById(
        "paymentMethodError"
    );


const contactCards =
    document.querySelectorAll(
        ".contact-option-card"
    );


const contactMethods =
    document.querySelectorAll(
        ".contactMethod"
    );


const contactMethodError =
    document.getElementById(
        "contactMethodError"
    );


const contactPhoneDisplay =
    document.getElementById(
        "contactPhoneDisplay"
    );


const contactEmailDisplay =
    document.getElementById(
        "contactEmailDisplay"
    );


const qrSection =
    document.getElementById(
        "qrSection"
    );


const qrImage =
    document.getElementById(
        "qrImage"
    );


const accountTitle =
    document.getElementById(
        "accountTitle"
    );


const accountNumber =
    document.getElementById(
        "accountNumber"
    );


const onlinePaymentSection =
    document.getElementById(
        "onlinePaymentSection"
    );


const transactionIdField =
    document.getElementById(
        "transactionId"
    );


const confirmBooking =
    document.getElementById(
        "confirmBooking"
    );


// ======================================================
// SHOW PREVIOUS PAGE
// ======================================================

window.addEventListener(
    "load",
    function () {

        const previousPage =
            document.referrer;


        const previousPageEl =
            document.getElementById(
                "previousPage"
            );


        if (previousPageEl) {

            previousPageEl.innerHTML =
                previousPage ||
                "No Previous Page Found";

        }

    }
);


// ======================================================
// UPDATE FINAL TOTAL
// ======================================================

function updateFinalTotal() {


    let itemsAmount =
        parseFloat(
            (
                localStorage.getItem(
                    "bookingTotal"
                ) || "0"
            ).replace(/,/g, "")
        ) || 0;


    let vehicleAmount =
        parseFloat(
            localStorage.getItem(
                "vehiclePrice"
            ) || "0"
        ) || 0;


    let savedFinalTotal =
        parseFloat(
            (
                localStorage.getItem(
                    "finalTotal"
                ) || "0"
            ).replace(/,/g, "")
        ) || 0;


    let total =
        savedFinalTotal > 0
            ? savedFinalTotal
            : (
                itemsAmount +
                vehicleAmount
            );


    console.log(
        "Received Payment Total:",
        total
    );


    if (finalTotal) {

        finalTotal.value =
            total.toLocaleString(
                "en-PK"
            );

    }


    if (itemsTotal) {

        itemsTotal.value =
            itemsAmount.toLocaleString(
                "en-PK"
            );

    }


    if (vehicleAmount > 0) {

        if (vehicleChargesWrap) {

            vehicleChargesWrap.style.display =
                "block";

        }


        if (vehicleChargesDisplay) {

            vehicleChargesDisplay.value =
                vehicleAmount.toLocaleString(
                    "en-PK"
                );

        }

    } else {

        if (vehicleChargesWrap) {

            vehicleChargesWrap.style.display =
                "none";

        }

    }


    // ==================================================
    // CUSTOMER CONTACT
    // ==================================================

    const savedPhone =
        localStorage.getItem(
            "customerPhone"
        );


    const savedEmail =
        localStorage.getItem(
            "customerEmail"
        );


    if (
        contactPhoneDisplay &&
        savedPhone
    ) {

        contactPhoneDisplay.innerHTML =
            savedPhone;

    }


    if (
        contactEmailDisplay &&
        savedEmail
    ) {

        contactEmailDisplay.innerHTML =
            savedEmail;

    }


    calculateRemaining();

}


// ======================================================
// CALCULATE REMAINING
// ======================================================

function calculateRemaining() {


    let total = 0;


    if (finalTotal) {

        total =
            parseFloat(
                (
                    finalTotal.value ||
                    "0"
                ).replace(/,/g, "")
            ) || 0;

    }


    let advance = 0;


    if (advanceAmount) {

        advance =
            parseFloat(
                advanceAmount.value ||
                "0"
            ) || 0;

    }


    let remaining =
        total - advance;


    if (remaining < 0) {

        remaining = 0;

    }


    if (remainingAmount) {

        remainingAmount.value =
            remaining.toLocaleString(
                "en-PK"
            );

    }

}


// ======================================================
// ADVANCE AMOUNT CHANGE
// ======================================================

if (advanceAmount) {

    advanceAmount.addEventListener(
        "input",
        calculateRemaining
    );

}


// ======================================================
// PAYMENT CARD SELECTION
// ======================================================

paymentCards.forEach(
    function (card) {

        card.addEventListener(
            "click",
            function () {


                paymentCards.forEach(
                    function (item) {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                this.classList.add(
                    "active"
                );


                const radio =
                    this.querySelector(
                        ".paymentMethod"
                    );


                if (radio) {

                    radio.checked = true;


                    radio.dispatchEvent(
                        new Event("change")
                    );

                }


                if (paymentMethodError) {

                    paymentMethodError.style.display =
                        "none";

                }

            }
        );

    }
);


// ======================================================
// CONTACT METHOD CARD SELECTION
// ======================================================

contactCards.forEach(
    function (card) {

        card.addEventListener(
            "click",
            function () {


                contactCards.forEach(
                    function (item) {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                this.classList.add(
                    "active"
                );


                const radio =
                    this.querySelector(
                        ".contactMethod"
                    );


                if (radio) {

                    radio.checked = true;

                }


                if (contactMethodError) {

                    contactMethodError.style.display =
                        "none";

                }

            }
        );

    }
);


// ======================================================
// PAYMENT METHOD CHANGE
// ======================================================

paymentMethods.forEach(
    function (method) {

        method.addEventListener(
            "change",
            function () {


                if (qrSection) {

                    qrSection.style.display =
                        "none";

                }


                if (onlinePaymentSection) {

                    onlinePaymentSection.style.display =
                        "none";

                }


                // ==========================================
                // CASH
                // ==========================================

                if (this.value === "Cash") {

                    return;

                }


                // ==========================================
                // ONLINE PAYMENT
                // ==========================================

                if (qrSection) {

                    qrSection.style.display =
                        "block";

                }


                if (onlinePaymentSection) {

                    onlinePaymentSection.style.display =
                        "flex";

                }


                // ==========================================
                // JAZZCASH
                // ==========================================

                if (
                    this.value ===
                    "JazzCash"
                ) {

                    if (qrImage) {

                        qrImage.src =
                            "image/jazzcash-qr.png";

                    }


                    if (accountTitle) {

                        accountTitle.innerHTML =
                            "JazzCash";

                    }


                    if (accountNumber) {

                        accountNumber.innerHTML =
                            "0300-1234567";

                    }

                }


                // ==========================================
                // EASYPAISA
                // ==========================================

                else if (
                    this.value ===
                    "Easypaisa"
                ) {

                    if (qrImage) {

                        qrImage.src =
                            "image/easypaisa-qr.png";

                    }


                    if (accountTitle) {

                        accountTitle.innerHTML =
                            "Easypaisa";

                    }


                    if (accountNumber) {

                        accountNumber.innerHTML =
                            "0311-1234567";

                    }

                }


                // ==========================================
                // BANK
                // ==========================================

                else if (
                    this.value ===
                    "Bank"
                ) {

                    if (qrImage) {

                        qrImage.src =
                            "image/bank-qr.png";

                    }


                    if (accountTitle) {

                        accountTitle.innerHTML =
                            "Meezan Bank";

                    }


                    if (accountNumber) {

                        accountNumber.innerHTML =
                            "Account No: 123456789012";

                    }

                }

            }
        );

    }
);


// ======================================================
// SUBMIT PAYMENT TO BACKEND
// ======================================================

async function submitPayment(paymentData) {


    console.log(
        "================================="
    );


    console.log(
        "PAYMENT DATA BEING SENT:"
    );


    console.log(
        paymentData
    );


    console.log(
        "================================="
    );


    try {


        const response =
            await fetch(
                PAYMENT_BACKEND_URL,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            paymentData
                        )

                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "payment.php RAW RESPONSE:"
        );


        console.log(
            rawResponse
        );


        if (!response.ok) {

            let errorMessage =
                "Payment submission failed.";


            try {

                const errorResult =
                    JSON.parse(
                        rawResponse
                    );


                if (
                    errorResult.error
                ) {

                    errorMessage =
                        errorResult.error;

                }

            } catch (e) {

                // Keep default message

            }


            alert(
                "❌ " +
                errorMessage
            );


            return false;

        }


        let result;


        try {

            result =
                JSON.parse(
                    rawResponse
                );

        } catch (jsonError) {

            console.error(
                "Invalid JSON from payment.php:",
                rawResponse
            );


            alert(
                "❌ payment.php returned an invalid response."
            );


            return false;

        }


        console.log(
            "PAYMENT SERVER RESPONSE:",
            result
        );


        if (!result.success) {

            alert(
                "❌ Payment submission failed:\n" +
                (
                    result.error ||
                    "Unknown server error."
                )
            );


            return false;

        }


        console.log(
            "✅ PAYMENT SAVED SUCCESSFULLY"
        );


        console.log(
            "Payment ID:",
            result.payment_id
        );


        return true;


    } catch (error) {

        console.error(
            "Payment connection error:",
            error
        );


        alert(
            "❌ Unable to connect to the payment server.\n\n" +
            error.message
        );


        return false;

    }

}


// ======================================================
// PAGE LOAD
// ======================================================

console.log(
    "✅ Payment Module Loaded Successfully"
);


window.addEventListener(
    "load",
    function () {

        updateFinalTotal();

    }
);


// ======================================================
// CONFIRM BOOKING
// ======================================================

if (confirmBooking) {


    confirmBooking.addEventListener(
        "click",
        async function () {


            let isValid = true;


            // ==================================================
            // PAYMENT METHOD
            // ==================================================

            const selectedPayment =
                document.querySelector(
                    'input[name="paymentMethod"]:checked'
                );


            if (!selectedPayment) {

                if (paymentMethodError) {

                    paymentMethodError.style.display =
                        "block";

                }


                isValid = false;

            } else {

                if (paymentMethodError) {

                    paymentMethodError.style.display =
                        "none";

                }

            }


            // ==================================================
            // CONTACT METHOD
            // ==================================================

            const selectedContact =
                document.querySelector(
                    'input[name="contactMethod"]:checked'
                );


            if (!selectedContact) {

                if (contactMethodError) {

                    contactMethodError.style.display =
                        "block";

                }


                isValid = false;

            } else {

                if (contactMethodError) {

                    contactMethodError.style.display =
                        "none";

                }

            }


            // ==================================================
            // STOP IF INVALID
            // ==================================================

            if (!isValid) {

                const firstError =
                    document.querySelector(
                        '#paymentMethodError[style*="block"], #contactMethodError[style*="block"]'
                    );


                if (firstError) {

                    firstError.scrollIntoView({

                        behavior:
                            "smooth",

                        block:
                            "center"

                    });

                }


                console.log(
                    "❌ Payment validation failed."
                );


                return;

            }


            // ==================================================
            // GET TOTALS
            // ==================================================

            const bookingTotal =
                parseFloat(
                    (
                        localStorage.getItem(
                            "bookingTotal"
                        ) || "0"
                    ).replace(/,/g, "")
                ) || 0;


            const vehiclePrice =
                parseFloat(
                    localStorage.getItem(
                        "vehiclePrice"
                    ) || "0"
                ) || 0;


            const finalTotalValue =
                parseFloat(
                    (
                        localStorage.getItem(
                            "finalTotal"
                        ) || "0"
                    ).replace(/,/g, "")
                ) ||
                (
                    bookingTotal +
                    vehiclePrice
                );


            const advance =
                parseFloat(
                    (
                        advanceAmount
                            ? advanceAmount.value
                            : "0"
                    ).replace(/,/g, "")
                ) || 0;


            const remaining =
                Math.max(
                    0,
                    finalTotalValue -
                    advance
                );


            // ==================================================
            // TRANSACTION ID
            // ==================================================

            const transactionId =
                transactionIdField
                    ? transactionIdField.value.trim()
                    : "";


            // ==================================================
            // ONLINE PAYMENT TRANSACTION VALIDATION
            // ==================================================

            if (
                selectedPayment.value !== "Cash" &&
                transactionId === ""
            ) {

                alert(
                    "❌ Please enter your Transaction ID."
                );


                if (transactionIdField) {

                    transactionIdField.focus();

                }


                return;

            }


            // ==================================================
            // CUSTOMER CONTACT
            // ==================================================

            const customerPhone =
                localStorage.getItem(
                    "customerPhone"
                ) || "";


            const customerEmail =
                localStorage.getItem(
                    "customerEmail"
                ) || "";


            // ==================================================
            // OPTIONAL BOOKING ID
            // ==================================================

            const bookingId =
                localStorage.getItem(
                    "bookingId"
                ) || "";


            // ==================================================
            // BUILD PAYMENT DATA
            // ==================================================

            const paymentData = {

                booking_id:
                    bookingId,

                customer_phone:
                    customerPhone,

                customer_email:
                    customerEmail,

                booking_total:
                    bookingTotal,

                vehicle_price:
                    vehiclePrice,

                final_total:
                    finalTotalValue,

                advance_amount:
                    advance,

                remaining_amount:
                    remaining,

                payment_method:
                    selectedPayment.value,

                contact_method:
                    selectedContact.value,

                transaction_id:
                    transactionId

            };


            // ==================================================
            // DISABLE BUTTON WHILE SUBMITTING
            // ==================================================

            confirmBooking.disabled =
                true;


            const originalButtonText =
                confirmBooking.innerHTML;


            confirmBooking.innerHTML =
                "Submitting...";


            // ==================================================
            // SEND TO PHP
            // ==================================================

            const saved =
                await submitPayment(
                    paymentData
                );


            // ==================================================
            // RESTORE BUTTON
            // ==================================================

            confirmBooking.disabled =
                false;


            confirmBooking.innerHTML =
                originalButtonText;


            // ==================================================
            // STOP IF BACKEND FAILED
            // ==================================================

            if (!saved) {

                return;

            }


            // ==================================================
            // SAVE LOCAL STORAGE
            // ==================================================

            localStorage.setItem(
                "paymentMethod",
                selectedPayment.value
            );


            localStorage.setItem(
                "contactMethod",
                selectedContact.value
            );


            localStorage.setItem(
                "advanceAmount",
                advance
            );


            localStorage.setItem(
                "remainingAmount",
                remaining
            );


            if (transactionIdField) {

                localStorage.setItem(
                    "transactionId",
                    transactionId
                );

            }


            // ==================================================
            // SUCCESS MESSAGE
            // ==================================================

            alert(
                "✅ Payment details submitted successfully!"
            );


            // ==================================================
            // THANK YOU PAGE
            // ==================================================

            window.location.href =
                "thankyou.html";

        }
    );

}

