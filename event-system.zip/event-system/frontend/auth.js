// =========================================================
// AUTHENTICATION FRONTEND
// =========================================================


// =========================================================
// BACKEND URL
// =========================================================

const AUTH_BACKEND_URL =
    "http://localhost/event-system/backend/auth/";


// =========================================================
// ELEMENTS
// =========================================================

const loginForm =
    document.getElementById("loginForm");

const signupForm =
    document.getElementById("signupForm");

const loginTab =
    document.getElementById("loginTab");

const signupTab =
    document.getElementById("signupTab");

const goSignup =
    document.getElementById("goSignup");

const goLogin =
    document.getElementById("goLogin");


// =========================================================
// SWITCH TO LOGIN
// =========================================================

function showLogin() {

    loginForm.classList.remove("d-none");

    signupForm.classList.add("d-none");

    loginTab.classList.add("active");

    signupTab.classList.remove("active");

    clearMessages();
}


// =========================================================
// SWITCH TO SIGNUP
// =========================================================

function showSignup() {

    loginForm.classList.add("d-none");

    signupForm.classList.remove("d-none");

    loginTab.classList.remove("active");

    signupTab.classList.add("active");

    clearMessages();
}


// =========================================================
// TAB EVENTS
// =========================================================

loginTab.addEventListener(
    "click",
    showLogin
);

signupTab.addEventListener(
    "click",
    showSignup
);

goSignup.addEventListener(
    "click",
    showSignup
);

goLogin.addEventListener(
    "click",
    showLogin
);


// =========================================================
// MESSAGE
// =========================================================

function showMessage(
    element,
    message,
    type
) {

    element.textContent = message;

    element.className =
        "auth-message " + type;
}


function clearMessages() {

    const loginMessage =
        document.getElementById("loginMessage");

    const signupMessage =
        document.getElementById("signupMessage");


    loginMessage.className =
        "auth-message";

    signupMessage.className =
        "auth-message";

    loginMessage.textContent = "";

    signupMessage.textContent = "";
}


// =========================================================
// PASSWORD SHOW / HIDE
// =========================================================

document.querySelectorAll(
    ".password-toggle"
).forEach(function(button) {

    button.addEventListener(
        "click",
        function() {

            const targetId =
                this.dataset.target;

            const input =
                document.getElementById(targetId);

            const icon =
                this.querySelector("i");


            if (input.type === "password") {

                input.type = "text";

                icon.classList.remove(
                    "fa-eye"
                );

                icon.classList.add(
                    "fa-eye-slash"
                );

            } else {

                input.type = "password";

                icon.classList.remove(
                    "fa-eye-slash"
                );

                icon.classList.add(
                    "fa-eye"
                );

            }

        }
    );

});


// =========================================================
// PHONE INPUT
// =========================================================

const signupPhone =
    document.getElementById("signupPhone");

signupPhone.addEventListener(
    "input",
    function() {

        this.value =
            this.value.replace(
                /[^0-9]/g,
                ""
            );

    }
);


// =========================================================
// CNIC INPUT
// =========================================================

const signupCnic =
    document.getElementById("signupCnic");

signupCnic.addEventListener(
    "input",
    function() {

        let value =
            this.value.replace(
                /[^0-9]/g,
                ""
            );


        if (value.length > 5) {

            value =
                value.substring(0, 5)
                + "-"
                + value.substring(5);

        }


        if (value.length > 13) {

            value =
                value.substring(0, 13)
                + "-"
                + value.substring(13);

        }


        this.value =
            value.substring(0, 15);

    }
);


// =========================================================
// SIGNUP
// =========================================================

signupForm.addEventListener(
    "submit",
    async function(e) {

        e.preventDefault();


        const fullName =
            document.getElementById(
                "signupName"
            ).value.trim();


        const email =
            document.getElementById(
                "signupEmail"
            ).value.trim();


        const phone =
            document.getElementById(
                "signupPhone"
            ).value.trim();


        const cnic =
            document.getElementById(
                "signupCnic"
            ).value.trim();


        const password =
            document.getElementById(
                "signupPassword"
            ).value;


        const confirmPassword =
            document.getElementById(
                "signupConfirmPassword"
            ).value;


        const message =
            document.getElementById(
                "signupMessage"
            );


        // -----------------------------------------------------
        // VALIDATION
        // -----------------------------------------------------

        if (
            fullName === "" ||
            email === "" ||
            phone === "" ||
            password === "" ||
            confirmPassword === ""
        ) {

            showMessage(
                message,
                "Please fill all required fields.",
                "error"
            );

            return;
        }


        if (!/^03[0-9]{9}$/.test(phone)) {

            showMessage(
                message,
                "Please enter a valid Pakistani phone number.",
                "error"
            );

            return;
        }


        if (
            cnic !== "" &&
            !/^[0-9]{5}-[0-9]{7}-[0-9]$/.test(cnic)
        ) {

            showMessage(
                message,
                "Please enter a valid CNIC.",
                "error"
            );

            return;
        }


        if (password.length < 6) {

            showMessage(
                message,
                "Password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        if (password !== confirmPassword) {

            showMessage(
                message,
                "Passwords do not match.",
                "error"
            );

            return;
        }


        // -----------------------------------------------------
        // DISABLE BUTTON
        // -----------------------------------------------------

        const button =
            document.getElementById(
                "signupButton"
            );

        button.disabled = true;

        button.innerHTML =
            '<span class="spinner-border spinner-border-sm me-2"></span>' +
            'Creating Account...';


        // -----------------------------------------------------
        // SEND REQUEST
        // -----------------------------------------------------

        try {

            const response =
                await fetch(
                    AUTH_BACKEND_URL +
                    "signup.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            "Accept":
                                "application/json"
                        },

                        body: JSON.stringify({

                            full_name: fullName,

                            email: email,

                            phone: phone,

                            cnic: cnic,

                            password: password

                        })
                    }
                );


            const raw =
                await response.text();


            console.log(
                "SIGNUP RESPONSE:",
                raw
            );


            let result;


            try {

                result =
                    JSON.parse(raw);

            } catch (error) {

                showMessage(
                    message,
                    "Server returned an invalid response.",
                    "error"
                );

                return;
            }


            if (!result.success) {

                showMessage(
                    message,
                    result.error ||
                    "Account creation failed.",
                    "error"
                );

                return;
            }


            // -------------------------------------------------
            // SUCCESS
            // -------------------------------------------------

            showMessage(
                message,
                "Account created successfully!",
                "success"
            );


            const modalElement =
                document.getElementById(
                    "successModal"
                );


            const modal =
                new bootstrap.Modal(
                    modalElement
                );


            modal.show();


            signupForm.reset();

        } catch (error) {

            console.error(
                "Signup error:",
                error
            );


            showMessage(
                message,
                "Unable to connect to the server.",
                "error"
            );

        } finally {

            button.disabled = false;

            button.innerHTML =
                '<i class="fa-solid fa-user-plus me-2"></i>' +
                'Create Account';

        }

    }
);


// =========================================================
// LOGIN
// =========================================================

loginForm.addEventListener(
    "submit",
    async function(e) {

        e.preventDefault();


        const email =
            document.getElementById(
                "loginEmail"
            ).value.trim();


        const password =
            document.getElementById(
                "loginPassword"
            ).value;


        const message =
            document.getElementById(
                "loginMessage"
            );


        if (
            email === "" ||
            password === ""
        ) {

            showMessage(
                message,
                "Please enter your email and password.",
                "error"
            );

            return;
        }


        const button =
            document.getElementById(
                "loginButton"
            );


        button.disabled = true;

        button.innerHTML =
            '<span class="spinner-border spinner-border-sm me-2"></span>' +
            'Logging in...';


        try {

            const response =
                await fetch(
                    AUTH_BACKEND_URL +
                    "login.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            "Accept":
                                "application/json"
                        },

                        body: JSON.stringify({

                            email: email,

                            password: password

                        })
                    }
                );


            const raw =
                await response.text();


            console.log(
                "LOGIN RESPONSE:",
                raw
            );


            let result;


            try {

                result =
                    JSON.parse(raw);

            } catch (error) {

                showMessage(
                    message,
                    "Server returned an invalid response.",
                    "error"
                );

                return;
            }


            if (!result.success) {

                showMessage(
                    message,
                    result.error ||
                    "Login failed.",
                    "error"
                );

                return;
            }


            // -------------------------------------------------
            // STORE USER LOCALLY FOR UI
            // -------------------------------------------------

            localStorage.setItem(
                "eventSystemUser",
                JSON.stringify(
                    result.user
                )
            );


            showMessage(
                message,
                "Login successful! Redirecting...",
                "success"
            );


            // -------------------------------------------------
            // REDIRECT
            // -------------------------------------------------

            setTimeout(
                function() {

                    window.location.href =
                        "index.html";

                },
                800
            );


        } catch (error) {

            console.error(
                "Login error:",
                error
            );


            showMessage(
                message,
                "Unable to connect to the server.",
                "error"
            );

        } finally {

            button.disabled = false;

            button.innerHTML =
                '<i class="fa-solid fa-right-to-bracket me-2"></i>' +
                'Login';

        }

    }
);


// =========================================================
// SUCCESS MODAL CONTINUE
// =========================================================

document
    .getElementById("successContinue")
    .addEventListener(
        "click",
        function() {

            window.location.href =
                "index.html";

        }
    );