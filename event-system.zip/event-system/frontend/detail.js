// detail.js

document.addEventListener("DOMContentLoaded", function () {

    console.log("Detail Page Loaded Successfully");

});