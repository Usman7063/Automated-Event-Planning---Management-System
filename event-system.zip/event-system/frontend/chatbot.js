/* =====================================================================
   chatbot.js -- Hassan Tent Service: Retrieval-based Chatbot + Voice
   ---------------------------------------------------------------------
   THIS VERSION: the launcher only needs to be included on index.html.
   Include on index.html, in this order:

       <link rel="stylesheet" href="chatbot.css">
       ...
       <script src="translation.js"></script>
       <script src="language.js"></script>
       <script src="chatbot.js"></script>

   chatbot.html ALSO includes the same 4 tags -- it needs chatbot.js
   too, to build the actual chat UI (the retrieval engine + voice code
   below is shared by both roles).

   HOW IT DECIDES WHAT TO DO
   ---------------------------------------------------------------------
     - On chatbot.html there is a <div id="chatbotApp"></div> in the
       markup. When chatbot.js finds that element, it builds the full
       chat panel inside it (messages, quick replies, mic, speaker,
       minimize/close).
     - On any OTHER page that includes chatbot.js (in practice, just
       index.html) it instead builds:
         1. a small blinking "?" launcher button
         2. a hidden overlay box docked bottom-right
         3. an <iframe src="chatbot.html"> inside that overlay
       Clicking the launcher toggles the overlay open/closed -- so the
       chat "page" visually opens ON TOP of index.html (like a normal
       chat widget), instead of navigating away from it. The iframe is
       only given its src on first open (lazy-loaded).

   chatbot.html detects whether IT is running inside that iframe
   (window.self !== window.top). If so:
     - it fills the iframe completely (no page chrome, no duplicate
       EN/UR button -- see chatbot.css's ".htbot-embedded" rules)
     - its minimize/close buttons post a message to the parent window
       asking it to hide the overlay, instead of navigating away
   If chatbot.html is opened directly by URL (not embedded), it falls
   back to a normal standalone page with its own docked panel.

   ABOUT "RAG" HERE
   ---------------------------------------------------------------------
   True RAG (Retrieval-Augmented Generation) normally pairs a
   retriever with a hosted LLM on a backend/API. This project is a
   static front-end site with no server or paid API key, so this file
   implements the RETRIEVAL half fully (a knowledge base of the site's
   real content, chunked, searched with a weighted keyword + word-
   overlap scorer, bilingual) and answers using the best-matching
   pre-written chunk instead of free-form generation. Anything the
   retriever can't confidently match to a chunk about Hassan Tent
   Service is treated as OUT OF SCOPE and refused politely in the
   visitor's current language.
   ===================================================================== */

(function () {

  /* =====================================================================
     PART A -- SHARED HELPERS
  ===================================================================== */

  function currentLang() {
    return (window.getCurrentLang && window.getCurrentLang()) || "en";
  }

  function el(tag, className, html) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function normalize(text) {
    return (text || "")
      .toLowerCase()
      .replace(/[^\u0600-\u06FFa-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  var STOPWORDS = (
    "the a an is are was were be been to of for and or in on at with " +
    "do does did you your yours i me my we our can could would should " +
    "please tell what how where when why which about kindly need want " +
    "hai hain ka ki ke ko se mein men aur ap aap kya kia karo kare " +
    "kaise kahan kab kitna kitni kyun please plz batao bata dijiye " +
    "walay wala wali hy hoon hun hu tha thi the mera meri mere"
  ).split(" ");

  function tokenize(text) {
    return normalize(text)
      .split(" ")
      .filter(function (w) { return w.length > 1 && STOPWORDS.indexOf(w) === -1; });
  }

  // Cross-window language sync: if the visitor flips EN/اردو on the
  // parent page (index.html) while the chatbot iframe is already open,
  // localStorage fires a native "storage" event on the OTHER window
  // (the iframe) automatically -- no postMessage plumbing needed.
  window.addEventListener("storage", function (e) {
    if (e.key === "siteLang" && typeof window.applyLanguage === "function") {
      window.applyLanguage(e.newValue);
    }
  });

  /* =====================================================================
     PART B -- KNOWLEDGE BASE (retrieval chunks)
  ===================================================================== */

  var KB = [

    /* ---------- identity / greetings / small talk ---------- */
    {
      id: "greeting",
      phrases: ["hi", "hello", "hey there", "salam", "assalam", "asalam", "aoa", "السلام", "سلام علیکم", "ہیلو"],
      words: ["hi", "hello", "salam"],
      reply: {
        en: "Assalam-o-Alaikum! 👋 I'm the Hassan Tent Service assistant. Ask me anything about our tent, decoration or sound & lighting services -- packages, prices, booking, payment, gallery, feedback, or contact info.",
        ur: "السلام علیکم! 👋 میں حسن ٹینٹ سروس کا اسسٹنٹ ہوں۔ مجھ سے ہماری ٹینٹ، ڈیکوریشن یا ساؤنڈ اینڈ لائٹنگ سروسز کے بارے میں کچھ بھی پوچھیں -- پیکجز، قیمتیں، بکنگ، ادائیگی، گیلری، فیڈبیک یا رابطہ کی تفصیلات۔"
      }
    },
    {
      id: "thanks",
      phrases: ["thanks", "thank you", "shukriya", "shukria", "mehrbani", "شکریہ", "مہربانی"],
      words: ["thanks", "thank"],
      reply: { en: "You're most welcome! Anything else I can help with?", ur: "خوش آمدید! کیا کسی اور چیز میں مدد کر سکتا ہوں؟" }
    },
    {
      id: "bye",
      phrases: ["bye", "goodbye", "khuda hafiz", "allah hafiz", "خدا حافظ", "اللہ حافظ"],
      words: ["bye", "goodbye"],
      reply: { en: "Khuda Hafiz! Come back anytime you have a question. 🙏", ur: "خدا حافظ! جب بھی سوال ہو، واپس آ جائیں۔ 🙏" }
    },
    {
      id: "bot_identity",
      phrases: ["who are you", "what are you", "your name", "tum kon ho", "aap kon hain", "آپ کون ہیں", "تم کون ہو"],
      words: ["who", "name", "assistant", "bot"],
      reply: {
        en: "I'm an automated retrieval-based assistant for the Hassan Tent Service website. I only answer questions about this site and its services.",
        ur: "میں حسن ٹینٹ سروس کی ویب سائٹ کا ایک خودکار اسسٹنٹ ہوں۔ میں صرف اسی سائٹ اور اس کی سروسز سے متعلق سوالات کے جواب دیتا ہوں۔"
      }
    },
    {
      id: "human_agent",
      phrases: ["talk to human", "real person", "customer support agent", "insan se baat", "انسان سے بات", "کسٹمر سپورٹ"],
      words: ["human", "agent", "person", "support"],
      reply: {
        en: "For anything that needs a real person, call +92 300 1234567 or email info@hassantent.com -- our team will help directly.",
        ur: "کسی بھی ایسے معاملے کے لیے جس میں انسان کی ضرورت ہو، ‎+92 300 1234567 پر کال کریں یا info@hassantent.com پر ای میل کریں -- ہماری ٹیم براہِ راست مدد کرے گی۔"
      }
    },

    /* ---------- company / services overview ---------- */
    {
      id: "company_overview",
      phrases: ["about hassan tent", "what is hassan tent service", "tell me about your company", "hassan tent service kya hai", "کمپنی کے بارے میں"],
      words: ["about", "company", "who", "hassan", "tent", "service", "business"],
      reply: {
        en: "Hassan Tent Service is an event management company based in Abbottabad, Pakistan, providing premium Tent, Decoration, Lighting, Sound System and complete event services for Weddings, Mehndi, Walima, Birthday Parties and Corporate Events.",
        ur: "حسن ٹینٹ سروس ایبٹ آباد، پاکستان میں قائم ایک ایونٹ مینجمنٹ کمپنی ہے، جو شادی، مہندی، ولیمہ، سالگرہ اور کارپوریٹ ایونٹس کے لیے پریمیم ٹینٹ، ڈیکوریشن، لائٹنگ، ساؤنڈ سسٹم اور مکمل ایونٹ سروسز فراہم کرتی ہے۔"
      }
    },
    {
      id: "services_list",
      phrases: ["what services", "services do you offer", "list of services", "sroten", "kya kya service", "سروسز کیا ہیں", "خدمات کی فہرست"],
      words: ["services", "offer", "provide", "list"],
      reply: {
        en: "Our services: 🏕️ Tent & Seating, 🎈 Decoration, 🔊 Sound & Lighting -- all directly bookable online. We also offer Catering and extra Stage Setup as add-ons (contact us for those details).",
        ur: "ہماری سروسز: 🏕️ ٹینٹ اینڈ سیٹنگ، 🎈 ڈیکوریشن، 🔊 ساؤنڈ اینڈ لائٹنگ -- سب آن لائن براہِ راست بک ہو سکتی ہیں۔ ہم کیٹرنگ اور اضافی اسٹیج سیٹ اپ بھی بطور ایڈ-آن فراہم کرتے ہیں (تفصیل کے لیے رابطہ کریں)۔"
      }
    },
    {
      id: "events_supported",
      phrases: ["what events", "which occasions", "wedding mehndi walima", "kis kis event ke liye", "کن ایونٹس کے لیے"],
      words: ["wedding", "mehndi", "walima", "birthday", "corporate", "event", "occasion"],
      reply: {
        en: "We cater to Weddings, Mehndi, Walima, Birthday Parties and Corporate Events.",
        ur: "ہم شادی، مہندی، ولیمہ، سالگرہ کی تقریبات اور کارپوریٹ ایونٹس کے لیے خدمات فراہم کرتے ہیں۔"
      }
    },

    /* ---------- pricing: generic + per-service ---------- */
    {
      id: "pricing_overview",
      phrases: ["price", "prices", "cost", "how much", "rate list", "qeemat", "price list", "kitne paise", "kitna kharcha", "قیمت", "ریٹ لسٹ", "کتنے پیسے"],
      words: ["price", "cost", "rate"],
      reply: {
        en: "Quick price guide: 🏕️ Tent & Seating packages Rs. 10,000 - 48,550. 🎈 Decoration packages Rs. 40,000 - 200,000 (or build your own from individual items). 🔊 Sound packages Rs. 15,000 - 65,000. 💡 Lighting packages Rs. 12,000 - 55,000. Ask me about a specific service, package, or even a single item (like 'round table price' or 'DJ setup price') for exact numbers!",
        ur: "مختصر قیمتیں: 🏕️ ٹینٹ اینڈ سیٹنگ پیکجز Rs. 10,000 - 48,550۔ 🎈 ڈیکوریشن پیکجز Rs. 40,000 - 200,000 (یا اپنی مرضی کی آئٹمز سے کسٹم بنائیں)۔ 🔊 ساؤنڈ پیکجز Rs. 15,000 - 65,000۔ 💡 لائٹنگ پیکجز Rs. 12,000 - 55,000۔ کسی خاص سروس، پیکج، یا کسی ایک آئٹم کی قیمت (جیسے 'گول میز کی قیمت' یا 'ڈی جے سیٹ اپ کی قیمت') پوچھیں!"
      }
    },

    /* ===== TENT & SEATING (booking.html) ===== */
    {
      id: "tent_basic",
      phrases: ["tent basic package", "basic tent price", "ٹینٹ بیسک پیکج"],
      words: ["tent", "seating", "basic"],
      reply: {
        en: "Tent & Seating Basic package -- Rs. 10,000. Includes: 100 Chairs (Qaum), 10 Round Tables, 10 Table Covers, 100 Large Plates, 100 Food Spoons, 100 Steel Glasses.",
        ur: "ٹینٹ اینڈ سیٹنگ بیسک پیکج -- Rs. 10,000۔ شامل ہے: 100 چیئر (قوم)، 10 گول میزیں، 10 میز کے کور، 100 بڑی پلیٹیں، 100 کھانے کے چمچ، 100 سٹیل گلاس۔"
      }
    },
    {
      id: "tent_standard",
      phrases: ["tent standard package", "standard tent price", "ٹینٹ سٹینڈرڈ پیکج"],
      words: ["tent", "seating", "standard"],
      reply: {
        en: "Tent & Seating Standard package -- Rs. 18,700. Includes: 150 Parachute Chairs + Covers, 15 Round Tables + Covers, Dish & Donga sets (20/10), 150 Steel Glasses, 10 Steel Jugs.",
        ur: "ٹینٹ اینڈ سیٹنگ سٹینڈرڈ پیکج -- Rs. 18,700۔ شامل ہے: 150 پیراشوٹ چیئر + کور، 15 گول میزیں + کور، ڈش اور ڈونگا سیٹس (20/10)، 150 سٹیل گلاس، 10 سٹیل جگ۔"
      }
    },
    {
      id: "tent_premium",
      phrases: ["tent premium package", "premium tent price", "luxury tent", "ٹینٹ پریمیم پیکج"],
      words: ["tent", "premium", "luxury"],
      reply: {
        en: "Tent & Seating Premium package -- Rs. 48,550. Includes: 250 Parachute Chairs + Covers, 25 Round Tables + Covers, Dish/Donga/Parat sets, Glass Jugs & Tumblers, Canopy, Qanat, Carpet.",
        ur: "ٹینٹ اینڈ سیٹنگ پریمیم پیکج -- Rs. 48,550۔ شامل ہے: 250 پیراشوٹ چیئر + کور، 25 گول میزیں + کور، ڈش/ڈونگا/پرات سیٹس، گلاس جگ اور گلاس، کینوپی، قناط، قالین۔"
      }
    },
    {
      id: "tent_custom_items",
      phrases: ["custom tent items", "individual tent item price", "apni marzi ka tent samaan", "tent item rate", "ٹینٹ کا سامان الگ الگ"],
      words: ["tent", "custom", "items", "chair", "table", "dish"],
      reply: {
        en: "On the Tent & Seating booking page you can also skip the fixed packages and build your own from 30+ individual items (chairs, tables, dishes, canopy, qanat, carpet, etc.) -- each priced per unit. Ask me the price of any specific item!",
        ur: "ٹینٹ اینڈ سیٹنگ بکنگ پیج پر آپ فکسڈ پیکجز کی بجائے 30 سے زیادہ الگ الگ آئٹمز (چیئر، میز، ڈش، کینوپی، قناط، قالین وغیرہ) سے اپنی مرضی کا سیٹ بھی بنا سکتے ہیں -- ہر آئٹم کی فی یونٹ قیمت ہے۔ کسی بھی خاص آئٹم کی قیمت پوچھیں!"
      }
    },
    {
      id: "tent_transport",
      phrases: ["tent vehicle price", "tent transport charges", "ٹینٹ ٹرانسپورٹ چارجز"],
      words: ["tent", "transport", "vehicle", "suzuki", "jeep"],
      reply: {
        en: "Tent & Seating transport: Suzuki Pickup Rs. 3,000, or Jeep Rs. 5,000.",
        ur: "ٹینٹ اینڈ سیٹنگ ٹرانسپورٹ: سوزوکی پک اپ Rs. 3,000، یا جیپ Rs. 5,000۔"
      }
    },

    /* ===== DECORATION (booking1.html) ===== */
    {
      id: "decoration_wedding",
      phrases: ["wedding decoration package", "wedding decoration price", "شادی کی ڈیکوریشن"],
      words: ["wedding", "decoration", "silver", "gold", "platinum"],
      reply: {
        en: "Wedding Decoration packages: Silver Rs. 50,000, Gold Rs. 100,000, Platinum Rs. 200,000.",
        ur: "شادی کی ڈیکوریشن پیکجز: سلور Rs. 50,000، گولڈ Rs. 100,000، پلاٹینم Rs. 200,000۔"
      }
    },
    {
      id: "decoration_mehndi",
      phrases: ["mehndi decoration package", "mehndi decoration price", "مہندی کی ڈیکوریشن"],
      words: ["mehndi", "decoration", "simple", "royal"],
      reply: {
        en: "Mehndi Decoration packages: Simple Mehndi Rs. 40,000, Royal Mehndi Rs. 90,000.",
        ur: "مہندی کی ڈیکوریشن پیکجز: سادہ مہندی Rs. 40,000، رائل مہندی Rs. 90,000۔"
      }
    },
    {
      id: "decoration_general",
      phrases: ["decoration basic package", "decoration premium package", "decoration luxury package", "birthday decoration price", "corporate decoration price", "عام تقریب کی ڈیکوریشن"],
      words: ["decoration", "basic", "premium", "luxury", "birthday", "corporate"],
      reply: {
        en: "General event Decoration packages: Basic Rs. 50,000 (simple stage, artificial flowers, basic lights), Premium Rs. 100,000 (luxury stage, fresh flowers, LED lights, entrance decoration), Luxury Rs. 200,000 (complete venue decor, royal stage, photo booth).",
        ur: "عام تقریبات کی ڈیکوریشن پیکجز: بیسک Rs. 50,000 (سادہ اسٹیج، مصنوعی پھول، بنیادی لائٹس)، پریمیم Rs. 100,000 (لگژری اسٹیج، تازہ پھول، ایل ای ڈی لائٹس، انٹرینس ڈیکوریشن)، لگژری Rs. 200,000 (مکمل وینیو ڈیکور، رائل اسٹیج، فوٹو بوتھ)۔"
      }
    },
    {
      id: "decoration_custom",
      phrases: ["custom decoration", "build my own decoration", "apni marzi ki decoration", "decoration item price", "اپنی مرضی کی ڈیکوریشن"],
      words: ["custom", "checkbox", "stage", "flowers", "lighting", "extra"],
      reply: {
        en: "On the Decoration booking page you can also switch to 'Custom' mode -- pick individual items from Stage, Flowers, Lighting and Extra categories (each separately priced) instead of a fixed package. Ask me the price of any specific item, like 'entrance gate price'!",
        ur: "ڈیکوریشن بکنگ پیج پر آپ 'کسٹم' موڈ بھی منتخب کر سکتے ہیں -- اسٹیج، پھول، لائٹنگ اور ایکسٹرا کیٹیگریز سے اپنی پسند کی آئٹمز چنیں (ہر ایک کی الگ قیمت ہے)۔ کسی بھی خاص آئٹم کی قیمت پوچھیں، جیسے 'انٹرینس گیٹ کی قیمت'!"
      }
    },
    {
      id: "decoration_transport",
      phrases: ["decoration vehicle price", "decoration transport charges", "ڈیکوریشن ٹرانسپورٹ چارجز"],
      words: ["decoration", "transport", "vehicle", "suzuki", "jeep"],
      reply: {
        en: "Decoration transport: Suzuki Rs. 5,000, or Jeep Rs. 8,000.",
        ur: "ڈیکوریشن ٹرانسپورٹ: سوزوکی Rs. 5,000، یا جیپ Rs. 8,000۔"
      }
    },

    /* ===== SOUND (booking2.html) ===== */
    {
      id: "sound_basic",
      phrases: ["sound basic package", "basic sound price", "ساؤنڈ بیسک پیکج"],
      words: ["sound", "basic", "speaker", "mic"],
      reply: {
        en: "Sound Basic package -- Rs. 15,000. Includes: 2 Speakers, 1 Woofer, 1 Amplifier, 1 Mixer, 1 Wired Mic.",
        ur: "ساؤنڈ بیسک پیکج -- Rs. 15,000۔ شامل ہے: 2 سپیکر، 1 ووفر، 1 ایمپلی فائر، 1 مکسر، 1 وائرڈ مائیک۔"
      }
    },
    {
      id: "sound_standard",
      phrases: ["sound standard package", "standard sound price", "ساؤنڈ سٹینڈرڈ پیکج"],
      words: ["sound", "standard"],
      reply: {
        en: "Sound Standard package -- Rs. 25,000. Includes: 4 Speakers, 2 Woofers, 2 Amplifiers, 1 Mixer, 2 Wired Mics, 1 Wireless Mic.",
        ur: "ساؤنڈ سٹینڈرڈ پیکج -- Rs. 25,000۔ شامل ہے: 4 سپیکر، 2 ووفر، 2 ایمپلی فائر، 1 مکسر، 2 وائرڈ مائیک، 1 وائرلیس مائیک۔"
      }
    },
    {
      id: "sound_premium",
      phrases: ["sound premium package", "premium sound price", "ساؤنڈ پریمیم پیکج"],
      words: ["sound", "premium"],
      reply: {
        en: "Sound Premium package -- Rs. 40,000. Includes: 6 Speakers, 4 Woofers, 3 Amplifiers, 2 Mixers, 2 Wired + 2 Wireless Mics, and DJ Setup included.",
        ur: "ساؤنڈ پریمیم پیکج -- Rs. 40,000۔ شامل ہے: 6 سپیکر، 4 ووفر، 3 ایمپلی فائر، 2 مکسر، 2 وائرڈ + 2 وائرلیس مائیک، اور ڈی جے سیٹ اپ شامل ہے۔"
      }
    },
    {
      id: "sound_vip",
      phrases: ["sound vip package", "vip sound price", "ساؤنڈ وی آئی پی پیکج"],
      words: ["sound", "vip"],
      reply: {
        en: "Sound VIP package -- Rs. 65,000. Includes: 10 Speakers, 6 Woofers, 4 Amplifiers, 2 Mixers, 4 Wired + 4 Wireless Mics, DJ Setup included.",
        ur: "ساؤنڈ وی آئی پی پیکج -- Rs. 65,000۔ شامل ہے: 10 سپیکر، 6 ووفر، 4 ایمپلی فائر، 2 مکسر، 4 وائرڈ + 4 وائرلیس مائیک، ڈی جے سیٹ اپ شامل ہے۔"
      }
    },
    {
      id: "sound_custom",
      phrases: ["custom sound items", "add extra speaker", "sound item price", "ساؤنڈ کا سامان الگ الگ"],
      words: ["sound", "custom", "speaker", "woofer", "amplifier", "mixer"],
      reply: {
        en: "You can also add extra Sound items on top of any package (or build fully Custom): Speaker, Woofer, Amplifier, Mixer, Wired Mic, Wireless Mic, DJ Setup -- each priced per unit. Ask me the price of any specific item!",
        ur: "آپ کسی بھی پیکج کے ساتھ اضافی ساؤنڈ آئٹمز بھی شامل کر سکتے ہیں (یا مکمل کسٹم بنائیں): سپیکر، ووفر، ایمپلی فائر، مکسر، وائرڈ مائیک، وائرلیس مائیک، ڈی جے سیٹ اپ -- ہر ایک کی فی یونٹ قیمت ہے۔ کسی خاص آئٹم کی قیمت پوچھیں!"
      }
    },

    /* ===== LIGHTING (also on booking2.html, separate from Sound) ===== */
    {
      id: "lighting_basic",
      phrases: ["lighting basic package", "basic lighting price", "لائٹنگ بیسک پیکج"],
      words: ["lighting", "basic", "stage light", "flood"],
      reply: {
        en: "Lighting Basic package -- Rs. 12,000. Includes: 2 Stage Lights, 4 LED PARs, 2 Flood Lights.",
        ur: "لائٹنگ بیسک پیکج -- Rs. 12,000۔ شامل ہے: 2 اسٹیج لائٹس، 4 ایل ای ڈی پار، 2 فلڈ لائٹس۔"
      }
    },
    {
      id: "lighting_standard",
      phrases: ["lighting standard package", "standard lighting price", "لائٹنگ سٹینڈرڈ پیکج"],
      words: ["lighting", "standard"],
      reply: {
        en: "Lighting Standard package -- Rs. 20,000. Includes: 4 Stage Lights, 8 LED PARs, 2 Moving Heads, 4 Flood Lights.",
        ur: "لائٹنگ سٹینڈرڈ پیکج -- Rs. 20,000۔ شامل ہے: 4 اسٹیج لائٹس، 8 ایل ای ڈی پار، 2 موونگ ہیڈز، 4 فلڈ لائٹس۔"
      }
    },
    {
      id: "lighting_premium",
      phrases: ["lighting premium package", "premium lighting price", "لائٹنگ پریمیم پیکج"],
      words: ["lighting", "premium", "smoke"],
      reply: {
        en: "Lighting Premium package -- Rs. 35,000. Includes: 8 Stage Lights, 12 LED PARs, 4 Moving Heads, 6 Flood Lights, Smoke Machine.",
        ur: "لائٹنگ پریمیم پیکج -- Rs. 35,000۔ شامل ہے: 8 اسٹیج لائٹس، 12 ایل ای ڈی پار، 4 موونگ ہیڈز، 6 فلڈ لائٹس، سموک مشین۔"
      }
    },
    {
      id: "lighting_vip",
      phrases: ["lighting vip package", "vip lighting price", "لائٹنگ وی آئی پی پیکج"],
      words: ["lighting", "vip"],
      reply: {
        en: "Lighting VIP package -- Rs. 55,000. Includes: 12 Stage Lights, 20 LED PARs, 8 Moving Heads, 10 Flood Lights, Smoke Machine.",
        ur: "لائٹنگ وی آئی پی پیکج -- Rs. 55,000۔ شامل ہے: 12 اسٹیج لائٹس، 20 ایل ای ڈی پار، 8 موونگ ہیڈز، 10 فلڈ لائٹس، سموک مشین۔"
      }
    },
    {
      id: "soundlighting_transport",
      phrases: ["sound vehicle price", "lighting transport charges", "ساؤنڈ ٹرانسپورٹ چارجز"],
      words: ["sound", "lighting", "transport", "vehicle", "suzuki", "jeep"],
      reply: {
        en: "Sound & Lighting transport: Suzuki Pickup Rs. 3,000, or Jeep Rs. 5,000.",
        ur: "ساؤنڈ اینڈ لائٹنگ ٹرانسپورٹ: سوزوکی پک اپ Rs. 3,000، یا جیپ Rs. 5,000۔"
      }
    },
    {
      id: "generator_addon",
      phrases: ["generator price", "generator charges", "جنریٹر کی قیمت"],
      words: ["generator", "backup", "power"],
      reply: {
        en: "A backup Generator can be added on the Sound & Lighting booking page for Rs. 4,000.",
        ur: "ساؤنڈ اینڈ لائٹنگ بکنگ پیج پر بیک اپ جنریٹر Rs. 4,000 میں شامل کیا جا سکتا ہے۔"
      }
    },

    /* ---------- booking flow ---------- */
    {
      id: "how_to_book",
      phrases: ["how to book", "booking process", "book kaise karen", "reserve karna", "بکنگ کیسے کریں"],
      words: ["book", "booking", "reserve", "process", "steps"],
      reply: {
        en: "Booking steps: 1) Pick a service (Tent, Decoration or Sound & Lighting) 2) Choose a package or go Custom 3) Add transport if needed 4) Pick a payment method and pay any advance 5) Choose SMS or Email confirmation 6) Confirm -- you get a reference number on the Thank You page.",
        ur: "بکنگ کے مراحل: 1) سروس منتخب کریں (ٹینٹ، ڈیکوریشن یا ساؤنڈ اینڈ لائٹنگ) 2) پیکج منتخب کریں یا کسٹم بنائیں 3) ضرورت ہو تو ٹرانسپورٹ شامل کریں 4) ادائیگی کا طریقہ منتخب کریں اور ایڈوانس ادا کریں 5) SMS یا ای میل کنفرمیشن منتخب کریں 6) کنفرم کریں -- تھینک یو پیج پر ریفرنس نمبر ملے گا۔"
      }
    },
    {
      id: "transport_overview",
      phrases: ["transport charges", "delivery charges", "vehicle charges", "ٹرانسپورٹ چارجز"],
      words: ["transport", "delivery", "vehicle"],
      reply: {
        en: "A vehicle (Suzuki Pickup or Jeep) can be added while booking on every service page, with the exact price shown before you confirm. Ask me about transport for a specific service (Tent, Decoration, or Sound & Lighting) for the exact rate.",
        ur: "ہر سروس پیج پر بکنگ کے دوران گاڑی (سوزوکی پک اپ یا جیپ) شامل کی جا سکتی ہے، اور اصل قیمت کنفرم کرنے سے پہلے دکھائی جاتی ہے۔ کسی خاص سروس (ٹینٹ، ڈیکوریشن، یا ساؤنڈ اینڈ لائٹنگ) کے ٹرانسپورٹ ریٹ کے بارے میں پوچھیں۔"
      }
    },
    {
      id: "setup_time",
      phrases: ["setup time", "how long to setup", "kitna time lagta hai", "سیٹ اپ کا وقت"],
      words: ["setup", "time", "hours"],
      reply: {
        en: "Setup usually takes about 3 hours for Tent & Seating, and about 2 hours for Decoration or Sound & Lighting.",
        ur: "سیٹ اپ عام طور پر ٹینٹ اینڈ سیٹنگ کے لیے تقریباً 3 گھنٹے، اور ڈیکوریشن یا ساؤنڈ اینڈ لائٹنگ کے لیے تقریباً 2 گھنٹے میں مکمل ہو جاتا ہے۔"
      }
    },
    {
      id: "staff_support",
      phrases: ["professional staff", "emergency support", "پروفیشنل عملہ"],
      words: ["staff", "support", "team"],
      reply: {
        en: "All our services include professional trained staff for setup and event-day support.",
        ur: "ہماری تمام سروسز میں سیٹ اپ اور ایونٹ کے دن کی مدد کے لیے پروفیشنل تربیت یافتہ عملہ شامل ہے۔"
      }
    },

    /* ---------- payment ---------- */
    {
      id: "payment_methods",
      phrases: ["payment method", "how to pay", "jazzcash", "easypaisa", "bank transfer", "cash payment", "ادائیگی کا طریقہ", "جاز کیش", "ایزی پیسہ"],
      words: ["payment", "pay", "cash", "bank"],
      reply: {
        en: "We accept: 💵 Cash (pay at the event), 📱 JazzCash, 📱 Easypaisa, and 🏦 Bank Transfer. For online methods you'll scan a QR code, then enter a Transaction ID and upload a payment screenshot.",
        ur: "ہم یہ ادائیگی کے طریقے قبول کرتے ہیں: 💵 نقد (ایونٹ پر)، 📱 جاز کیش، 📱 ایزی پیسہ، اور 🏦 بینک ٹرانسفر۔ آن لائن طریقوں کے لیے QR کوڈ سکین کریں، پھر ٹرانزیکشن آئی ڈی درج کر کے اسکرین شاٹ اپ لوڈ کریں۔"
      }
    },
    {
      id: "advance_balance",
      phrases: ["advance amount", "deposit", "remaining balance", "ایڈوانس رقم", "بقایا رقم"],
      words: ["advance", "deposit", "remaining", "balance"],
      reply: {
        en: "You can pay any advance amount you choose at booking time; the remaining balance is calculated automatically and shown before you confirm.",
        ur: "بکنگ کے وقت آپ اپنی پسند کی کوئی بھی ایڈوانس رقم ادا کر سکتے ہیں؛ بقیہ رقم خودکار طور پر شمار ہو کر کنفرم کرنے سے پہلے دکھائی جاتی ہے۔"
      }
    },
    {
      id: "confirmation_method",
      phrases: ["sms or email confirmation", "how will i be confirmed", "booking confirmation method", "SMS یا ای میل"],
      words: ["confirmation", "sms", "email", "notify"],
      reply: {
        en: "After payment you choose how to receive your booking confirmation -- SMS to your phone or Email -- and we send it that way.",
        ur: "ادائیگی کے بعد آپ منتخب کرتے ہیں کہ بکنگ کنفرمیشن کیسے حاصل کرنی ہے -- SMS یا ای میل -- اور ہم اسی طریقے سے بھیج دیتے ہیں۔"
      }
    },

    /* ---------- thank you / after booking ---------- */
    {
      id: "thankyou_reference",
      phrases: ["reference number", "booking reference", "download statement", "print booking", "ریفرنس نمبر", "بکنگ کا ثبوت"],
      words: ["reference", "statement", "pdf", "print", "download"],
      reply: {
        en: "Once your booking is confirmed, the Thank You page shows a full summary with a booking reference number, which you can print or download as a PDF statement.",
        ur: "بکنگ کنفرم ہونے کے بعد، تھینک یو پیج پر مکمل خلاصہ اور بکنگ ریفرنس نمبر دکھایا جاتا ہے، جسے آپ پرنٹ یا PDF کی صورت میں ڈاؤن لوڈ کر سکتے ہیں۔"
      }
    },
    {
      id: "order_tracking",
      phrases: ["track my order", "booking status", "past bookings", "my account", "میری بکنگ کی صورتحال", "اکاؤنٹ"],
      words: ["track", "status", "account", "history"],
      reply: {
        en: "This site doesn't have a login/account system, so there's no order-history page -- but you'll get a printable/downloadable summary right after booking. For anything else, please contact us directly.",
        ur: "اس سائٹ پر لاگ اِن/اکاؤنٹ سسٹم موجود نہیں، اس لیے آرڈر ہسٹری پیج نہیں ہے -- لیکن بکنگ کے فوراً بعد آپ کو پرنٹ/ڈاؤن لوڈ کے قابل خلاصہ مل جاتا ہے۔ کسی اور معاملے کے لیے براہِ راست رابطہ کریں۔"
      }
    },

    /* ---------- gallery / feedback / comparison ---------- */
    {
      id: "gallery",
      phrases: ["gallery", "photos", "pictures of your work", "گیلری", "تصاویر دیکھیں"],
      words: ["gallery", "photos", "pictures", "images"],
      reply: {
        en: "See our past setups on the Gallery page, filterable by Tent, Decoration or Sound & Lighting -- click any photo to view it full-size.",
        ur: "ہماری پچھلی سیٹ اپس کی تصاویر گیلری پیج پر دیکھیں، جو ٹینٹ، ڈیکوریشن یا ساؤنڈ اینڈ لائٹنگ کے مطابق فلٹر ہو سکتی ہیں -- کسی بھی تصویر پر کلک کر کے بڑی دیکھیں۔"
      }
    },
    {
      id: "feedback",
      phrases: ["feedback", "leave a review", "rate your service", "شکایت", "رائے دیں", "ریٹنگ"],
      words: ["feedback", "review", "rating", "rate"],
      reply: {
        en: "We'd love your feedback -- the Feedback page lets you rate us 1-5 stars and leave a written review.",
        ur: "ہمیں آپ کی رائے کا انتظار رہے گا -- فیڈبیک پیج پر آپ ہمیں 1-5 ستارے دے سکتے ہیں اور تحریری رائے بھی دے سکتے ہیں۔"
      }
    },
    {
      id: "customer_rating",
      phrases: ["your rating", "how good are you", "customer rating", "کسٹمر ریٹنگ"],
      words: ["rating", "stars", "reviews"],
      reply: { en: "Our overall customer rating is ⭐ 4.9 / 5.", ur: "ہماری مجموعی کسٹمر ریٹنگ ⭐ 4.9 / 5 ہے۔" }
    },
    {
      id: "comparison",
      phrases: ["compare with other providers", "why choose you", "better than other tent service", "کیوں منتخب کریں", "مقابلہ"],
      words: ["compare", "comparison", "better", "why"],
      reply: {
        en: "Vs. other local providers we include more (free transport, generator backup, professional staff) at a lower price, with faster setup and fully transparent pricing -- see the Comparison page for the exact numbers.",
        ur: "دوسرے مقامی فراہم کنندگان کے مقابلے میں ہم کم قیمت میں زیادہ سہولیات دیتے ہیں (مفت ٹرانسپورٹ، جنریٹر بیک اپ، پروفیشنل عملہ)، تیز سیٹ اپ اور مکمل شفاف قیمتیں -- درست اعداد و شمار کے لیے کمپیرزن پیج دیکھیں۔"
      }
    },

    /* ---------- contact / location / language ---------- */
    {
      id: "contact_info",
      phrases: ["contact number", "phone number", "email address", "whatsapp number", "رابطہ نمبر", "فون نمبر", "ای میل"],
      words: ["contact", "phone", "call", "email", "whatsapp"],
      reply: {
        en: "📞 +92 300 1234567 | ✉️ info@hassantent.com -- there's also a contact form on the homepage, and Facebook/Instagram/WhatsApp/YouTube links in the footer.",
        ur: "📞 ‎+92 300 1234567 | ✉️ info@hassantent.com -- ہوم پیج پر ایک کانٹیکٹ فارم بھی ہے، اور فوٹر میں فیس بک/انسٹاگرام/واٹس ایپ/یوٹیوب کے لنکس بھی موجود ہیں۔"
      }
    },
    {
      id: "location",
      phrases: ["your location", "your address", "where are you located", "پتہ", "لوکیشن", "کہاں واقع ہیں"],
      words: ["location", "address", "where", "abbottabad"],
      reply: {
        en: "We're located at Village Maira Hasnal Seer Gharbi, Tehsil Lora, Abbottabad, Pakistan.",
        ur: "ہماری لوکیشن: ولیج میرا حسنال سیر غربی، تحصیل لورہ، ایبٹ آباد، پاکستان۔"
      }
    },
    {
      id: "language_support",
      phrases: ["urdu english support", "change language", "زبان تبدیل کریں", "اردو انگریزی"],
      words: ["language", "urdu", "english", "switch"],
      reply: {
        en: "The whole site (and I) support English and Urdu -- use the EN / اردو switch anywhere on the page, or just type your question in either language.",
        ur: "پوری ویب سائٹ (اور میں بھی) انگلش اور اردو سپورٹ کرتے ہیں -- پیج پر کہیں بھی EN / اردو سوئچ استعمال کریں، یا بس اپنی زبان میں سوال لکھیں۔"
      }
    }

  ];

  /* =====================================================================
     PART B2 -- INDIVIDUAL ITEM PRICE LOOKUP
     ---------------------------------------------------------------------
     Every single sellable item on the site (tent items, decoration
     add-ons, sound & lighting extras), pulled straight from the real
     booking.html / booking1.js / booking2.js pricing data -- so ANY
     one item's price can be answered on the fly, not just packages.
  ===================================================================== */

  var ITEM_PRICES = [
    // ----- Tent & Seating individual items (booking.html, per unit) -----
    { en: "Chair (Qaum)", ur: "چیئر (قوم)", terms: ["chair qaum", "qaum chair", "chair (qaum)"], price: 20, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Parachute Chair", ur: "پیراشوٹ چیئر", terms: ["parachute chair"], price: 30, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Chair Cover", ur: "چیئر کور", terms: ["chair cover"], price: 10, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Round Table", ur: "گول میز", terms: ["round table"], price: 300, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Square Table", ur: "چوکور میز", terms: ["square table"], price: 250, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Table Cover", ur: "میز کا کور", terms: ["table cover"], price: 150, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Large Plate", ur: "بڑی پلیٹ", terms: ["large plate", "big plate"], price: 15, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Small Plate", ur: "چھوٹی پلیٹ", terms: ["small plate"], price: 10, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Food Spoon", ur: "کھانے کا چمچ", terms: ["food spoon"], price: 5, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Dish", ur: "ڈش", terms: ["dish"], price: 30, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Donga", ur: "ڈونگا", terms: ["donga"], price: 100, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Dish Spoon", ur: "ڈش کا چمچ", terms: ["dish spoon"], price: 20, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Donga Spoon", ur: "ڈونگا کا چمچ", terms: ["donga spoon"], price: 20, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Steel Jug", ur: "سٹیل جگ", terms: ["steel jug"], price: 150, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Steel Glass", ur: "سٹیل گلاس", terms: ["steel glass"], price: 15, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Glass Jug", ur: "شیشے کا جگ", terms: ["glass jug"], price: 200, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Glass Tumbler", ur: "شیشے کا گلاس", terms: ["glass tumbler"], price: 20, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Parat", ur: "پرات", terms: ["parat"], price: 250, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Parat Spoon", ur: "پرات کا چمچ", terms: ["parat spoon"], price: 30, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Canopy", ur: "کینوپی", terms: ["canopy"], price: 3000, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Shamiana", ur: "شامیانہ", terms: ["shamiana"], price: 5000, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Qanat", ur: "قناط", terms: ["qanat"], price: 800, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Carpet", ur: "قالین", terms: ["carpet"], price: 700, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Tea Urn", ur: "چائے کی ٹینکی", terms: ["tea urn", "qahwa tanki"], price: 1500, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Hammam", ur: "حمام", terms: ["hammam"], price: 2500, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Tarpaulin", ur: "ترپال", terms: ["tarpaulin", "tarpaal"], price: 400, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Bamboo", ur: "بانس", terms: ["bamboo"], price: 150, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Rope", ur: "رسی", terms: ["rope"], price: 100, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Stakes", ur: "کیلیں", terms: ["stakes", "kali"], price: 50, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Pegs", ur: "چوے", terms: ["pegs", "choway"], price: 100, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Jazeer", ur: "زنجیر", terms: ["jazeer"], price: 500, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },
    { en: "Takht Posh", ur: "تخت پوش", terms: ["takht posh"], price: 300, cat: { en: "Tent item", ur: "ٹینٹ آئٹم" } },

    // ----- Decoration custom items (booking1.js) -----
    { en: "Simple Stage", ur: "سادہ اسٹیج", terms: ["simple stage"], price: 20000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Royal Stage", ur: "رائل اسٹیج", terms: ["royal stage"], price: 50000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "LED Stage", ur: "ایل ای ڈی اسٹیج", terms: ["led stage"], price: 70000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Fresh Flowers", ur: "تازہ پھول", terms: ["fresh flowers"], price: 30000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Artificial Flowers", ur: "مصنوعی پھول", terms: ["artificial flowers"], price: 15000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Fairy Lights", ur: "فیری لائٹس", terms: ["fairy lights"], price: 10000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "LED Lights", ur: "ایل ای ڈی لائٹس", terms: ["led lights"], price: 20000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Moving Lights", ur: "موونگ لائٹس", terms: ["moving lights"], price: 30000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Photo Booth", ur: "فوٹو بوتھ", terms: ["photo booth"], price: 15000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Dance Floor", ur: "ڈانس فلور", terms: ["dance floor"], price: 20000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },
    { en: "Entrance Gate", ur: "انٹرینس گیٹ", terms: ["entrance gate"], price: 25000, cat: { en: "Decoration item", ur: "ڈیکوریشن آئٹم" } },

    // ----- Sound extras (booking2.js, per unit) -----
    { en: "Speaker", ur: "سپیکر", terms: ["speaker"], price: 1500, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "Woofer", ur: "ووفر", terms: ["woofer"], price: 3000, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "Amplifier", ur: "ایمپلی فائر", terms: ["amplifier"], price: 2500, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "Mixer", ur: "مکسر", terms: ["mixer"], price: 2000, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "Wired Mic", ur: "وائرڈ مائیک", terms: ["wired mic"], price: 800, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "Wireless Mic", ur: "وائرلیس مائیک", terms: ["wireless mic"], price: 1500, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },
    { en: "DJ Setup", ur: "ڈی جے سیٹ اپ", terms: ["dj setup", "dj"], price: 8000, cat: { en: "Sound item", ur: "ساؤنڈ آئٹم" } },

    // ----- Lighting extras (booking2.js, per unit) -----
    { en: "Stage Light", ur: "اسٹیج لائٹ", terms: ["stage light"], price: 1000, cat: { en: "Lighting item", ur: "لائٹنگ آئٹم" } },
    { en: "LED PAR", ur: "ایل ای ڈی پار", terms: ["led par"], price: 500, cat: { en: "Lighting item", ur: "لائٹنگ آئٹم" } },
    { en: "Moving Head", ur: "موونگ ہیڈ", terms: ["moving head"], price: 2500, cat: { en: "Lighting item", ur: "لائٹنگ آئٹم" } },
    { en: "Flood Light", ur: "فلڈ لائٹ", terms: ["flood light"], price: 800, cat: { en: "Lighting item", ur: "لائٹنگ آئٹم" } },
    { en: "Smoke Machine", ur: "سموک مشین", terms: ["smoke machine"], price: 3000, cat: { en: "Lighting item", ur: "لائٹنگ آئٹم" } },

    // ----- Add-on -----
    { en: "Generator", ur: "جنریٹر", terms: ["generator"], price: 4000, cat: { en: "Sound & Lighting add-on", ur: "ساؤنڈ اینڈ لائٹنگ ایڈ-آن" } }
  ];

  var PRICE_SIGNAL_WORDS = ["price", "qeemat", "rate", "cost", "kitne", "kitna", "paise", "قیمت", "ریٹ", "کتنے", "کتنا"];

  // Finds the item whose name appears in the query -- picks the LONGEST
  // matching term so e.g. "wireless mic" wins over a looser "mic" match.
  // Only fires for short queries or ones that clearly ask about a price,
  // so a stray common word (like "table") inside an unrelated long
  // sentence doesn't hijack the answer.
  function lookupItem(userText) {
    var q = normalize(userText);
    if (!q) return null;
    var isShort = tokenize(userText).length <= 6;
    var hasPriceSignal = PRICE_SIGNAL_WORDS.some(function (w) { return q.indexOf(normalize(w)) !== -1; });
    if (!isShort && !hasPriceSignal) return null;

    var best = null, bestLen = 0;
    ITEM_PRICES.forEach(function (item) {
      item.terms.forEach(function (t) {
        var tNorm = normalize(t);
        if (q.indexOf(tNorm) !== -1 && tNorm.length > bestLen) {
          best = item; bestLen = tNorm.length;
        }
      });
    });
    return best;
  }

  function formatItemAnswer(item, lang) {
    var priceStr = "Rs. " + item.price.toLocaleString("en-PK");
    if (lang === "ur") {
      return (item.ur || item.en) + " کی قیمت " + priceStr + " ہے (" + (item.cat.ur || item.cat.en) + ")۔";
    }
    return (item.en) + " costs " + priceStr + " (" + item.cat.en + ").";
  }

  var OUT_OF_SCOPE = {
    en: "Sorry, that's outside what I can help with -- I can only answer questions about Hassan Tent Service (packages, pricing, booking, payments, gallery, feedback, or contact details). Try asking about one of those! 🙂",
    ur: "معذرت، یہ میری مدد کے دائرے سے باہر ہے -- میں صرف حسن ٹینٹ سروس سے متعلق سوالات کے جواب دے سکتا ہوں (پیکجز، قیمتیں، بکنگ، ادائیگی، گیلری، فیڈبیک یا رابطہ کی تفصیلات)۔ ان میں سے کسی موضوع پر سوال پوچھ کر دیکھیں! 🙂"
  };

  var QUICK_REPLIES = [
    { en: "Packages & Prices", ur: "پیکجز اور قیمتیں", query: "price list" },
    { en: "How to Book", ur: "بکنگ کیسے کریں", query: "how to book" },
    { en: "Payment Methods", ur: "ادائیگی کے طریقے", query: "payment method" },
    { en: "Contact Us", ur: "ہم سے رابطہ", query: "contact number" }
  ];

  /* =====================================================================
     PART C -- RETRIEVAL ENGINE
  ===================================================================== */

  function scoreChunk(queryNorm, queryTokens, chunk) {
    var score = 0;
    chunk.phrases.forEach(function (p) {
      if (queryNorm.indexOf(normalize(p)) !== -1) score += 3;
    });
    var chunkTokens = tokenize(chunk.phrases.join(" ") + " " + (chunk.words || []).join(" "));
    queryTokens.forEach(function (t) {
      if (chunkTokens.indexOf(t) !== -1) score += 1;
    });
    return score;
  }

  function retrieve(userText) {
    var queryNorm = normalize(userText);
    var queryTokens = tokenize(userText);
    if (!queryNorm) return null;

    var best = null, bestScore = 0;
    KB.forEach(function (chunk) {
      var s = scoreChunk(queryNorm, queryTokens, chunk);
      if (s > bestScore) { bestScore = s; best = chunk; }
    });

    if (best && bestScore >= 2) return best.reply;
    return null;
  }

  function answerFor(userText, lang) {
    // Check for a specific single item first (e.g. "round table price",
    // "DJ setup rate") -- this is more specific than any package chunk.
    var item = lookupItem(userText);
    if (item) return formatItemAnswer(item, lang);

    var reply = retrieve(userText);
    return reply ? (reply[lang] || reply.en) : (OUT_OF_SCOPE[lang] || OUT_OF_SCOPE.en);
  }

  /* =====================================================================
     PART D -- VOICE (Speech-to-Text + Text-to-Speech)
  ===================================================================== */

  var SpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
  var recognition = SpeechRecognitionCtor ? new SpeechRecognitionCtor() : null;
  if (recognition) { recognition.continuous = false; recognition.interimResults = false; }

  var listening = false;
  var speakerOn = false; // OFF by default -- only speaks once the user turns the speaker button on

  // getVoices() often returns an empty list the FIRST time it's called
  // (voices load asynchronously) -- cache them and refresh via the
  // "voiceschanged" event so speak() always has the real list to search.
  var cachedVoices = [];
  function refreshVoices() {
    if ("speechSynthesis" in window) cachedVoices = window.speechSynthesis.getVoices();
  }
  refreshVoices();
  if ("speechSynthesis" in window) window.speechSynthesis.onvoiceschanged = refreshVoices;

  function speak(text, lang) {
    if (!speakerOn || !("speechSynthesis" in window)) return;
    var voices = cachedVoices.length ? cachedVoices : window.speechSynthesis.getVoices();
    var match = voices.filter(function (v) {
      return v.lang && v.lang.toLowerCase().indexOf(lang === "ur" ? "ur" : "en") === 0;
    })[0];
    window.speechSynthesis.cancel();
    var clean = text.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, "");
    var utter = new SpeechSynthesisUtterance(clean);
    utter.lang = lang === "ur" ? "ur-PK" : "en-US";
    // If this device has no Urdu voice installed, we still speak using
    // the browser's default voice (pronunciation won't be perfect, but
    // the assistant always produces audio instead of staying silent).
    if (match) utter.voice = match;
    window.speechSynthesis.speak(utter);
  }

  /* =====================================================================
     PART E1 -- LAUNCHER + OVERLAY (index.html)
  ===================================================================== */

  function buildLauncher() {
    if (document.querySelector(".htbot-launcher")) return; // avoid duplicates

    var btn = el("button", "htbot-launcher", "?");
    btn.type = "button";
    btn.setAttribute("aria-label", "Chat with Hassan Tent Service assistant");
    var badge = el("span", "htbot-launcher-badge", "Ask");
    btn.appendChild(badge);

    var overlay = el("div", "htbot-overlay");
    var iframe = document.createElement("iframe");
    iframe.className = "htbot-iframe";
    iframe.title = "Hassan Tent Service Chat Assistant";
    overlay.appendChild(iframe);

    document.body.appendChild(btn);
    document.body.appendChild(overlay);

    var loaded = false;
    var open = false;

    function show() {
      if (!loaded) { iframe.src = "chatbot.html"; loaded = true; }
      overlay.classList.add("open");
      overlay.classList.remove("minimized");
      btn.classList.add("open");
      btn.innerHTML = "&times;";
      open = true;
    }
    function hide() {
      overlay.classList.remove("open");
      overlay.classList.remove("minimized");
      btn.classList.remove("open");
      btn.innerHTML = "?";
      open = false;
    }

    btn.addEventListener("click", function () {
      if (!open) { show(); return; }
      if (overlay.classList.contains("minimized")) {
        // panel is shrunk to just its header bar -- clicking the
        // launcher again restores it to full size rather than closing
        overlay.classList.remove("minimized");
        if (iframe.contentWindow) iframe.contentWindow.postMessage({ type: "htbot:restored" }, "*");
      } else {
        hide();
      }
    });

    // chatbot.html (inside the iframe) talks to us when its own
    // header buttons are clicked:
    //  - minimize shrinks the overlay down to just its header bar
    //    (the iframe keeps running underneath, conversation intact)
    //  - restore expands it back to full size
    //  - close fully hides it AND throws the iframe away, so
    //    reopening later starts a brand-new conversation
    window.addEventListener("message", function (e) {
      if (!e.data) return;
      if (e.data.type === "htbot:minimize") {
        overlay.classList.add("minimized");
      } else if (e.data.type === "htbot:restore") {
        overlay.classList.remove("minimized");
      } else if (e.data.type === "htbot:hide") {
        hide();
      } else if (e.data.type === "htbot:close") {
        hide();
        loaded = false;
        iframe.src = "about:blank";
      }

    });

    function syncBadge() {
      badge.textContent = currentLang() === "ur" ? "پوچھیں" : "Ask";
    }
    syncBadge();
    document.addEventListener("languagechange", syncBadge);
  }

  /* =====================================================================
     PART E2 -- FULL CHAT APP (chatbot.html)
  ===================================================================== */

  function buildChatApp(root) {
    var embedded = window.self !== window.top;
    if (embedded) document.body.classList.add("htbot-embedded");

    var panel = el("div", "htbot-panel");

    var header = el("div", "htbot-header");
    var title = el("div", "htbot-title",
      '<span class="htbot-avatar"><i class="fa-solid fa-robot"></i></span>' +
      '<span class="htbot-title-text"><span id="htbotTitleText">Hassan Tent Assistant</span>' +
      '<small id="htbotSubText">Online &middot; usually replies instantly</small></span>');

    var actions = el("div", "htbot-header-actions");
    var speakerBtn = el("button", "htbot-icon-btn", '<i class="fa-solid fa-volume-xmark"></i>');
    speakerBtn.type = "button"; speakerBtn.title = "Toggle voice replies";

    var minimizeBtn = el("button", "htbot-icon-btn", '<i class="fa-solid fa-minus"></i>');
    minimizeBtn.type = "button"; minimizeBtn.title = "Minimize";

    var closeBtn = el("button", "htbot-icon-btn", '<i class="fa-solid fa-xmark"></i>');
    closeBtn.type = "button"; closeBtn.title = "Close";

    actions.appendChild(speakerBtn);
    actions.appendChild(minimizeBtn);
    actions.appendChild(closeBtn);
    header.appendChild(title);
    header.appendChild(actions);

    var messagesEl = el("div", "htbot-messages");
    var quickWrap = el("div", "htbot-quick");
    var listeningBanner = el("div", "htbot-listening-banner");
    listeningBanner.style.display = "none";

    var inputBar = el("div", "htbot-inputbar");
    var inputEl = document.createElement("input");
    inputEl.type = "text";

    var micBtn = el("button", "htbot-mic", '<i class="fa-solid fa-microphone"></i>');
    micBtn.type = "button";
    if (!recognition) { micBtn.disabled = true; micBtn.title = "Voice input not supported in this browser"; }

    var sendBtn = el("button", "htbot-send", '<i class="fa-solid fa-paper-plane"></i>');
    sendBtn.type = "button";

    inputBar.appendChild(inputEl);
    inputBar.appendChild(micBtn);
    inputBar.appendChild(sendBtn);

    panel.appendChild(header);
    panel.appendChild(messagesEl);
    panel.appendChild(listeningBanner);
    panel.appendChild(quickWrap);
    panel.appendChild(inputBar);
    root.appendChild(panel);

    /* ---- message rendering ---- */
    function addMessage(text, who) {
      var lang = currentLang();
      var msg = el("div", "htbot-msg " + who + (lang === "ur" ? " rtl" : ""), text);
      messagesEl.appendChild(msg);
      messagesEl.scrollTop = messagesEl.scrollHeight;
      return msg;
    }

    function showTyping() {
      var t = el("div", "htbot-msg bot typing",
        '<span class="htbot-dot"></span><span class="htbot-dot"></span><span class="htbot-dot"></span>');
      messagesEl.appendChild(t);
      messagesEl.scrollTop = messagesEl.scrollHeight;
      return t;
    }

    function respond(userText) {
      var lang = currentLang();
      var typingEl = showTyping();
      setTimeout(function () {
        typingEl.remove();
        var replyText = answerFor(userText, lang);
        addMessage(replyText, "bot");
        speak(replyText, lang);
      }, 450);
    }

    function handleSend() {
      var text = inputEl.value.trim();
      if (!text) return;
      addMessage(text, "user");
      inputEl.value = "";
      respond(text);
    }

    function renderQuickReplies() {
      quickWrap.innerHTML = "";
      var lang = currentLang();
      QUICK_REPLIES.forEach(function (q) {
        var chip = el("button", "htbot-chip", q[lang] || q.en);
        chip.type = "button";
        chip.addEventListener("click", function () {
          addMessage(q[lang] || q.en, "user");
          respond(q.query);
        });
        quickWrap.appendChild(chip);
      });
    }

    function updateStaticText() {
      var lang = currentLang();
      var titleText = document.getElementById("htbotTitleText");
      var subText = document.getElementById("htbotSubText");
      if (titleText) titleText.textContent = lang === "ur" ? "حسن ٹینٹ اسسٹنٹ" : "Hassan Tent Assistant";
      if (subText) subText.textContent = lang === "ur" ? "آن لائن · فوری جواب" : "Online \u00B7 usually replies instantly";
      title.setAttribute("dir", lang === "ur" ? "rtl" : "ltr");
      inputEl.placeholder = lang === "ur" ? "اپنا سوال لکھیں..." : "Type your question...";
      inputEl.dir = lang === "ur" ? "rtl" : "ltr";
      renderQuickReplies();
    }

    /* ---- events ---- */
    sendBtn.addEventListener("click", handleSend);
    inputEl.addEventListener("keydown", function (e) { if (e.key === "Enter") handleSend(); });

    speakerBtn.addEventListener("click", function () {
      speakerOn = !speakerOn;
      speakerBtn.classList.toggle("active", speakerOn);
      speakerBtn.innerHTML = speakerOn
        ? '<i class="fa-solid fa-volume-high"></i>'
        : '<i class="fa-solid fa-volume-xmark"></i>';
      if (!speakerOn && "speechSynthesis" in window) window.speechSynthesis.cancel();
    });

    var minimized = false;

    function setMinimizeIcon() {
      minimizeBtn.innerHTML = minimized
        ? '<i class="fa-solid fa-chevron-up"></i>'
        : '<i class="fa-solid fa-minus"></i>';
      minimizeBtn.title = minimized ? "Reopen" : "Minimize";
    }

    function toggleMinimize() {
      minimized = !minimized;
      setMinimizeIcon();
      if (embedded) {
        // parent page owns the actual size change -- shrinking the
        // overlay down to just its header bar (or back to full size)
        window.parent.postMessage({ type: minimized ? "htbot:minimize" : "htbot:restore" }, "*");
      } else {
        panel.classList.toggle("htbot-minimized", minimized);
      }
    }

    function closeChat() {
      if (embedded) {
        window.parent.postMessage({ type: "htbot:close" }, "*");
      } else if (document.referrer && document.referrer.indexOf(window.location.host) !== -1) {
        window.history.back();
      } else {
        window.location.href = "index.html";
      }
    }
    minimizeBtn.addEventListener("click", toggleMinimize);
    closeBtn.addEventListener("click", closeChat);

    // while minimized, tapping anywhere on the header (but not its
    // action buttons) restores the panel too
    header.addEventListener("click", function (e) {
      if (!minimized || actions.contains(e.target)) return;
      toggleMinimize();
    });

    // parent page tells us if IT restored the panel (e.g. the visitor
    // clicked the launcher bubble again instead of the header) so our
    // own minimize/restore icon stays in sync
    window.addEventListener("message", function (e) {
      if (e.data && e.data.type === "htbot:restored" && minimized) {
        minimized = false;
        setMinimizeIcon();
      }
    });

    if (recognition) {
      micBtn.addEventListener("click", function () {
        if (listening) { recognition.stop(); return; }
        recognition.lang = currentLang() === "ur" ? "ur-PK" : "en-US";
        try { recognition.start(); } catch (e) { /* already listening */ }
      });
      recognition.addEventListener("start", function () {
        listening = true;
        micBtn.classList.add("listening");
        listeningBanner.style.display = "block";
        listeningBanner.textContent = currentLang() === "ur" ? "سن رہا ہوں..." : "Listening...";
      });
      recognition.addEventListener("end", function () {
        listening = false;
        micBtn.classList.remove("listening");
        listeningBanner.style.display = "none";
      });
      recognition.addEventListener("result", function (e) {
        inputEl.value = e.results[0][0].transcript;
        handleSend();
      });
      recognition.addEventListener("error", function () {
        listening = false;
        micBtn.classList.remove("listening");
        listeningBanner.style.display = "none";
      });
    }

    document.addEventListener("languagechange", updateStaticText);
    updateStaticText();

    var greetChunk = KB[0];
    var greetText = greetChunk.reply[currentLang()] || greetChunk.reply.en;
    addMessage(greetText, "bot"); // not spoken -- voice only plays once the user turns the speaker ON
  }

  /* =====================================================================
     PART F -- INIT (auto-detect page)
  ===================================================================== */

  function init() {
    var appRoot = document.getElementById("chatbotApp");
    if (appRoot) {
      buildChatApp(appRoot);
    } else {
      buildLauncher();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
console.log("🔥 chatbot.js reached the end successfully");
})();