// ============================================================
// USER PROFILE
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

    const profileBody =
        document.getElementById("profileBody");

    const loadingProfile =
        document.getElementById("loadingProfile");

    const profileForm =
        document.getElementById("profileForm");

    const profileMessage =
        document.getElementById("profileMessage");

    const profileName =
        document.getElementById("profileName");

    const fullName =
        document.getElementById("fullName");

    const email =
        document.getElementById("email");

    const phone =
        document.getElementById("phone");

    const cnic =
        document.getElementById("cnic");

    const saveProfileBtn =
        document.getElementById("saveProfileBtn");


    // ========================================================
    // SHOW MESSAGE
    // ========================================================

    function showMessage(message, type) {

        profileMessage.textContent =
            message;

        profileMessage.className =
            "alert alert-" + type;

        profileMessage.style.display =
            "block";
    }


    // ========================================================
    // LOAD PROFILE
    // ========================================================

    async function loadProfile() {

        try {

            const response =
                await fetch(
                    "http://localhost/event-system/backend/auth/profile.php",
                    {
                        method: "GET",

                        headers: {
                            "Accept":
                                "application/json"
                        },

                        credentials: "include"
                    }
                );


            const result =
                await response.json();


            console.log(
                "PROFILE RESPONSE:",
                result
            );


            if (!result.success) {

                window.location.href =
                    "login.html";

                return;
            }


            const user =
                result.user;


            // Fill fields

            fullName.value =
                user.full_name || "";

            email.value =
                user.email || "";

            phone.value =
                user.phone || "";

            cnic.value =
                user.cnic || "";


            // Header

            profileName.textContent =
                user.full_name;


            // Show profile

            loadingProfile.style.display =
                "none";

            profileBody.style.display =
                "block";


        } catch (error) {

            console.error(
                "PROFILE LOAD ERROR:",
                error
            );


            loadingProfile.innerHTML = `
                <div class="alert alert-danger">
                    Unable to load your profile.
                </div>
            `;

        }

    }


    // ========================================================
    // SAVE PROFILE
    // ========================================================

    profileForm.addEventListener(
        "submit",
        async function (e) {

            e.preventDefault();


            saveProfileBtn.disabled =
                true;

            saveProfileBtn.innerHTML = `
                <span
                    class="spinner-border spinner-border-sm me-2">
                </span>
                Saving...
            `;


            const data = {

                full_name:
                    fullName.value.trim(),

                email:
                    email.value.trim(),

                phone:
                    phone.value.trim(),

                cnic:
                    cnic.value.trim()

            };


            try {

                const response =
                    await fetch(
                        "http://localhost/event-system/backend/auth/profile.php",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json",

                                "Accept":
                                    "application/json"
                            },

                            credentials: "include",

                            body:
                                JSON.stringify(data)
                        }
                    );


                const result =
                    await response.json();


                console.log(
                    "PROFILE UPDATE:",
                    result
                );


                if (!result.success) {

                    showMessage(
                        result.error ||
                        "Profile update failed.",
                        "danger"
                    );

                    return;
                }


                // Update displayed name

                profileName.textContent =
                    result.user.full_name;


                // ------------------------------------------------
                // Keep localStorage synchronized
                // ------------------------------------------------

                const storedUser =
                    localStorage.getItem(
                        "loggedInUser"
                    );


                if (storedUser) {

                    try {

                        const localUser =
                            JSON.parse(
                                storedUser
                            );


                        localUser.full_name =
                            result.user.full_name;

                        localUser.email =
                            result.user.email;

                        localUser.phone =
                            result.user.phone;

                        localUser.cnic =
                            result.user.cnic;


                        localStorage.setItem(
                            "loggedInUser",
                            JSON.stringify(
                                localUser
                            )
                        );

                    } catch (error) {

                        console.error(
                            "Local user update failed:",
                            error
                        );

                    }

                }


                showMessage(
                    "Profile updated successfully!",
                    "success"
                );


            } catch (error) {

                console.error(
                    "PROFILE UPDATE ERROR:",
                    error
                );


                showMessage(
                    "Unable to connect to the server.",
                    "danger"
                );


            } finally {

                saveProfileBtn.disabled =
                    false;

                saveProfileBtn.innerHTML = `
                    <i class="fa-solid fa-save me-2"></i>
                    Save Changes
                `;

            }

        }
    );


    // ========================================================
    // START
    // ========================================================

    loadProfile();

});