// =====================================================================
// FEEDBACK SYSTEM
// =====================================================================
// Handles:
//
// 1. Star rating
// 2. Hover preview
// 3. Form validation
// 4. Backend submission
// 5. Thank You popup
// 6. Adding successful feedback to reviews
//
// Backend:
// http://localhost/event-system/backend/feedback.php
// =====================================================================


// =====================================================================
// BACKEND URL
// =====================================================================

const FEEDBACK_BACKEND_URL =
    "http://localhost/event-system/backend/feedback.php";


// =====================================================================
// 1. STAR RATING
// =====================================================================

const stars =
    document.querySelectorAll(".star");

const ratingText =
    document.getElementById("ratingText");

const ratingRow =
    document.getElementById("ratingRow");

const ratingError =
    document.getElementById("ratingError");


let selectedRating = 0;


// =====================================================================
// PAINT STARS
// =====================================================================

function paintStars(count) {

    stars.forEach(function (star) {

        const starValue =
            parseInt(
                star.dataset.rating,
                10
            );

        const isFilled =
            starValue <= count;


        star.classList.toggle(
            "fa-solid",
            isFilled
        );


        star.classList.toggle(
            "fa-regular",
            !isFilled
        );


        star.classList.toggle(
            "active",
            isFilled
        );

    });

}


// =====================================================================
// STAR EVENTS
// =====================================================================

stars.forEach(function (star) {


    // -------------------------------------------------------------
    // CLICK
    // -------------------------------------------------------------

    star.addEventListener(
        "click",
        function () {

            selectedRating =
                parseInt(
                    this.dataset.rating,
                    10
                );


            paintStars(
                selectedRating
            );


            if (ratingText) {

                ratingText.textContent =
                    `You rated us ${selectedRating} out of 5`;

            }


            if (ratingError) {

                ratingError.style.display =
                    "none";

            }

        }
    );


    // -------------------------------------------------------------
    // HOVER
    // -------------------------------------------------------------

    star.addEventListener(
        "mouseenter",
        function () {

            paintStars(
                parseInt(
                    this.dataset.rating,
                    10
                )
            );

        }
    );

});


// =====================================================================
// MOUSE LEAVE
// =====================================================================

if (ratingRow) {

    ratingRow.addEventListener(
        "mouseleave",
        function () {

            paintStars(
                selectedRating
            );

        }
    );

}


// =====================================================================
// 2. FORM VALIDATION
// =====================================================================

function showFieldError(
    inputElement,
    isInvalid
) {

    if (!inputElement) {
        return;
    }


    inputElement.classList.toggle(
        "is-invalid",
        isInvalid
    );

}


// =====================================================================
// VALIDATE FEEDBACK FORM
// =====================================================================

function validateFeedbackForm() {

    let isValid = true;


    const fullName =
        document.getElementById("fullName");


    const eventType =
        document.getElementById("eventType");


    const feedbackMessage =
        document.getElementById(
            "feedbackMessage"
        );


    // -------------------------------------------------------------
    // NAME
    // -------------------------------------------------------------

    const nameInvalid =
        !fullName ||
        fullName.value.trim() === "";


    showFieldError(
        fullName,
        nameInvalid
    );


    if (nameInvalid) {

        isValid = false;

    }


    // -------------------------------------------------------------
    // EVENT TYPE
    // -------------------------------------------------------------

    const eventInvalid =
        !eventType ||
        eventType.value.trim() === "";


    showFieldError(
        eventType,
        eventInvalid
    );


    if (eventInvalid) {

        isValid = false;

    }


    // -------------------------------------------------------------
    // MESSAGE
    // -------------------------------------------------------------

    const messageInvalid =
        !feedbackMessage ||
        feedbackMessage.value.trim() === "";


    showFieldError(
        feedbackMessage,
        messageInvalid
    );


    if (messageInvalid) {

        isValid = false;

    }


    // -------------------------------------------------------------
    // RATING
    // -------------------------------------------------------------

    const ratingInvalid =
        selectedRating === 0;


    if (ratingError) {

        ratingError.style.display =
            ratingInvalid
                ? "block"
                : "none";

    }


    if (ratingInvalid) {

        isValid = false;

    }


    return isValid;

}


// =====================================================================
// 3. STAR DISPLAY FOR REVIEW CARD
// =====================================================================

function starsAsText(rating) {

    return (
        "⭐".repeat(rating) +
        "☆".repeat(5 - rating)
    );

}


// =====================================================================
// 4. ADD REVIEW CARD
// =====================================================================

function addReviewCard(
    name,
    eventType,
    message,
    rating
) {

    const reviewsRow =
        document.getElementById(
            "reviewsRow"
        );


    if (!reviewsRow) {

        console.warn(
            "reviewsRow element was not found."
        );

        return;

    }


    // -------------------------------------------------------------
    // COLUMN
    // -------------------------------------------------------------

    const column =
        document.createElement("div");


    column.className =
        "col-lg-4 col-md-6";


    // -------------------------------------------------------------
    // REVIEW CARD
    // -------------------------------------------------------------

    const card =
        document.createElement("div");


    card.className =
        "review-card";


    // -------------------------------------------------------------
    // STARS
    // -------------------------------------------------------------

    const starsElement =
        document.createElement("div");


    starsElement.className =
        "review-stars";


    starsElement.textContent =
        starsAsText(rating);


    // -------------------------------------------------------------
    // MESSAGE
    // -------------------------------------------------------------

    const messageElement =
        document.createElement("p");


    messageElement.textContent =
        message;


    // -------------------------------------------------------------
    // NAME
    // -------------------------------------------------------------

    const nameElement =
        document.createElement("h5");


    nameElement.textContent =
        name;


    // -------------------------------------------------------------
    // EVENT TYPE
    // -------------------------------------------------------------

    const eventElement =
        document.createElement("small");


    eventElement.textContent =
        eventType;


    // -------------------------------------------------------------
    // BUILD CARD
    // -------------------------------------------------------------

    card.appendChild(
        starsElement
    );


    card.appendChild(
        messageElement
    );


    card.appendChild(
        nameElement
    );


    card.appendChild(
        eventElement
    );


    column.appendChild(
        card
    );


    // -------------------------------------------------------------
    // NEWEST REVIEW FIRST
    // -------------------------------------------------------------

    reviewsRow.prepend(
        column
    );

}


// =====================================================================
// 5. SUBMIT FEEDBACK TO BACKEND
// =====================================================================

async function submitFeedback(
    name,
    eventType,
    message,
    rating
) {

    console.log(
        "================================="
    );


    console.log(
        "FEEDBACK DATA BEING SENT:"
    );


    console.log({

        name: name,

        event_type: eventType,

        rating: rating,

        message: message

    });


    console.log(
        "================================="
    );


    try {

        // ---------------------------------------------------------
        // SEND REQUEST
        // ---------------------------------------------------------

        const response =
            await fetch(
                FEEDBACK_BACKEND_URL,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"

                    },

                    body: JSON.stringify({

                        name:
                            name,

                        event_type:
                            eventType,

                        rating:
                            rating,

                        message:
                            message

                    })

                }
            );


        // ---------------------------------------------------------
        // READ RAW RESPONSE
        // ---------------------------------------------------------

        const rawResponse =
            await response.text();


        console.log(
            "feedback.php RAW RESPONSE:"
        );


        console.log(
            rawResponse
        );


        // ---------------------------------------------------------
        // HTTP ERROR
        // ---------------------------------------------------------

        if (!response.ok) {

            console.error(
                "Feedback server returned:",
                response.status
            );


            let errorMessage =
                "Unable to submit feedback.";


            try {

                const errorResult =
                    JSON.parse(
                        rawResponse
                    );


                if (
                    errorResult.error
                ) {

                    errorMessage =
                        errorResult.error;

                }


            } catch (e) {

                // Keep default error message

            }


            alert(
                "❌ " +
                errorMessage
            );


            return false;

        }


        // ---------------------------------------------------------
        // PARSE JSON
        // ---------------------------------------------------------

        let result;


        try {

            result =
                JSON.parse(
                    rawResponse
                );

        } catch (jsonError) {

            console.error(
                "Invalid JSON from feedback.php:",
                rawResponse
            );


            alert(
                "❌ feedback.php returned an invalid response."
            );


            return false;

        }


        // ---------------------------------------------------------
        // BACKEND FAILURE
        // ---------------------------------------------------------

        if (!result.success) {

            console.error(
                "Feedback backend error:",
                result
            );


            alert(
                "❌ Feedback submission failed.\n\n" +
                (
                    result.error ||
                    "Unknown server error."
                )
            );


            return false;

        }


        // ---------------------------------------------------------
        // SUCCESS
        // ---------------------------------------------------------

        console.log(
            "✅ FEEDBACK SAVED SUCCESSFULLY"
        );


        console.log(
            "Feedback ID:",
            result.feedback_id
        );


        return true;

    } catch (error) {

        console.error(
            "Feedback connection error:",
            error
        );


        alert(
            "❌ Unable to connect to the feedback server.\n\n" +
            error.message
        );


        return false;

    }

}


// =====================================================================
// 6. FORM SUBMISSION
// =====================================================================

const feedbackForm =
    document.getElementById(
        "feedbackForm"
    );


const successPopup =
    document.getElementById(
        "successPopup"
    );


if (feedbackForm) {

    feedbackForm.addEventListener(
        "submit",
        async function (e) {

            e.preventDefault();


            // -----------------------------------------------------
            // VALIDATE
            // -----------------------------------------------------

            if (
                !validateFeedbackForm()
            ) {

                const firstInvalid =
                    document.querySelector(
                        ".is-invalid"
                    );


                if (firstInvalid) {

                    firstInvalid.scrollIntoView({

                        behavior: "smooth",

                        block: "center"

                    });

                }


                console.log(
                    "❌ Feedback validation failed."
                );


                return;

            }


            // -----------------------------------------------------
            // GET DATA
            // -----------------------------------------------------

            const name =
                document
                    .getElementById("fullName")
                    .value
                    .trim();


            const eventType =
                document
                    .getElementById("eventType")
                    .value
                    .trim();


            const message =
                document
                    .getElementById(
                        "feedbackMessage"
                    )
                    .value
                    .trim();


            const rating =
                selectedRating;


            // -----------------------------------------------------
            // SEND TO PHP
            // -----------------------------------------------------

            const saved =
                await submitFeedback(
                    name,
                    eventType,
                    message,
                    rating
                );


            // -----------------------------------------------------
            // STOP IF DATABASE SAVE FAILED
            // -----------------------------------------------------

            if (!saved) {

                return;

            }


            // -----------------------------------------------------
            // ADD REVIEW ONLY AFTER SUCCESS
            // -----------------------------------------------------

            addReviewCard(
                name,
                eventType,
                message,
                rating
            );


            // -----------------------------------------------------
            // SHOW SUCCESS POPUP
            // -----------------------------------------------------

            if (successPopup) {

                successPopup.style.display =
                    "flex";

            }


            // -----------------------------------------------------
            // RESET FORM
            // -----------------------------------------------------

            feedbackForm.reset();


            document
                .querySelectorAll(
                    ".is-invalid"
                )
                .forEach(
                    function (element) {

                        element.classList.remove(
                            "is-invalid"
                        );

                    }
                );


            selectedRating = 0;


            paintStars(
                0
            );


            if (ratingText) {

                ratingText.textContent =
                    "Click on the stars to rate us";

            }

        }
    );

}


// =====================================================================
// 7. CLOSE SUCCESS POPUP
// =====================================================================

const closePopup =
    document.getElementById(
        "closePopup"
    );


if (closePopup && successPopup) {

    closePopup.addEventListener(
        "click",
        function () {

            successPopup.style.display =
                "none";

        }
    );

}


// =====================================================================
// 8. CLOSE POPUP BY CLICKING OVERLAY
// =====================================================================

if (successPopup) {

    successPopup.addEventListener(
        "click",
        function (e) {

            if (
                e.target === successPopup
            ) {

                successPopup.style.display =
                    "none";

            }

        }
    );

}


// =====================================================================
// INITIAL STAR STATE
// =====================================================================

paintStars(
    0
);


console.log(
    "✅ feedback.js backend connector initialized."
);

