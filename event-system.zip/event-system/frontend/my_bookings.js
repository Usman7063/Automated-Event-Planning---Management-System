// =====================================================================
// MY BOOKINGS
// =====================================================================


// =========================================================
// CONFIGURATION
// =========================================================

const MY_BOOKINGS_API =
    "http://localhost/event-system/backend/my_bookings.php";


// =========================================================
// DOM ELEMENTS
// =========================================================

const loadingMessage =
    document.getElementById("loadingMessage");

const errorMessage =
    document.getElementById("errorMessage");

const noBookings =
    document.getElementById("noBookings");

const bookingsContainer =
    document.getElementById("bookingsContainer");

const bookingDetails =
    document.getElementById("bookingDetails");

const modalTitle =
    document.getElementById("modalTitle");


// =========================================================
// STORE BOOKINGS
// =========================================================

let bookings = [];


// =========================================================
// LOAD BOOKINGS
// =========================================================

async function loadBookings() {

    loadingMessage.classList.remove("d-none");

    errorMessage.classList.add("d-none");

    noBookings.classList.add("d-none");

    bookingsContainer.innerHTML = "";


    try {

        const response = await fetch(
            MY_BOOKINGS_API,
            {
                method: "GET",

                headers: {
                    "Accept": "application/json"
                },

                credentials: "include"
            }
        );


        const rawResponse =
            await response.text();


        console.log(
            "My Bookings RAW RESPONSE:",
            rawResponse
        );


        let result;


        try {

            result =
                JSON.parse(rawResponse);

        } catch (error) {

            throw new Error(
                "Server returned invalid JSON."
            );

        }


        console.log(
            "My Bookings RESPONSE:",
            result
        );


        if (!response.ok) {

            throw new Error(
                result.error ||
                "Unable to load bookings."
            );

        }


        if (!result.success) {

            throw new Error(
                result.error ||
                "Unable to load bookings."
            );

        }


        bookings =
            Array.isArray(result.bookings)
                ? result.bookings
                : [];


        loadingMessage.classList.add("d-none");


        if (bookings.length === 0) {

            noBookings.classList.remove("d-none");

            return;

        }


        displayBookings();


    } catch (error) {

        console.error(
            "My bookings error:",
            error
        );


        loadingMessage.classList.add("d-none");


        errorMessage.textContent =
            "❌ " + error.message;


        errorMessage.classList.remove(
            "d-none"
        );

    }

}


// =========================================================
// DISPLAY BOOKINGS
// =========================================================

function displayBookings() {

    bookingsContainer.innerHTML = "";


    bookings.forEach(
        function (booking, index) {

            const card =
                createBookingCard(
                    booking,
                    index
                );


            bookingsContainer.insertAdjacentHTML(
                "beforeend",
                card
            );

        }
    );

}


// =========================================================
// GET BOOKING TYPE LABEL
// =========================================================

function getBookingTypeLabel(type) {

    switch (type) {

        case "booking":

            return "General Event Booking";


        case "booking1":

            return "Transport Booking";


        case "booking2":

            return "Service Booking";


        default:

            return "Event Booking";

    }

}


// =========================================================
// GET BOOKING TYPE BADGE
// =========================================================

function getBookingTypeClass(type) {

    switch (type) {

        case "booking":

            return "bg-primary";


        case "booking1":

            return "bg-info text-dark";


        case "booking2":

            return "bg-success";


        default:

            return "bg-secondary";

    }

}


// =========================================================
// CREATE BOOKING CARD
// =========================================================

function createBookingCard(
    booking,
    index
) {

    const bookingType =
        booking.booking_type || "booking";


    const bookingTypeLabel =
        getBookingTypeLabel(
            bookingType
        );


    const bookingTypeClass =
        getBookingTypeClass(
            bookingType
        );


    const status =
        String(
            booking.status || "pending"
        ).toLowerCase();


    const statusClass =
        getStatusClass(status);


    const eventTitle =
        escapeHtml(
            booking.event_title ||
            booking.event_type ||
            "Event"
        );


    const eventType =
        escapeHtml(
            booking.event_type ||
            "N/A"
        );


    const date =
        formatDate(
            booking.event_date
        );


    const location =
        escapeHtml(
            booking.event_location ||
            "Not provided"
        );


    let extraInformation = "";


    // ---------------------------------------------------------
    // BOOKING2
    // ---------------------------------------------------------

    if (bookingType === "booking2") {

        extraInformation = `

            <p class="text-muted mb-2">

                <strong>Service:</strong>

                ${escapeHtml(
                    booking.service_type ||
                    "N/A"
                )}

            </p>


            <p class="text-muted mb-2">

                <strong>Package:</strong>

                ${escapeHtml(
                    booking.package_name ||
                    "N/A"
                )}

            </p>


            <p class="text-muted mb-2">

                <strong>Total:</strong>

                PKR ${formatCurrency(
                    booking.grand_total
                )}

            </p>

        `;

    }


    // ---------------------------------------------------------
    // BOOKING1
    // ---------------------------------------------------------

    else if (bookingType === "booking1") {

        extraInformation = `

            <p class="text-muted mb-2">

                <strong>Transport:</strong>

                ${escapeHtml(
                    booking.transport ||
                    "N/A"
                )}

            </p>


            <p class="text-muted mb-2">

                <strong>Start Time:</strong>

                ${formatTime(
                    booking.start_time
                )}

            </p>


            <p class="text-muted mb-2">

                <strong>End Time:</strong>

                ${formatTime(
                    booking.end_time
                )}

            </p>


            <p class="text-muted mb-2">

                <strong>Payment:</strong>

                ${escapeHtml(
                    booking.payment_method ||
                    "N/A"
                )}

            </p>

        `;

    }


    // ---------------------------------------------------------
    // NORMAL BOOKING
    // ---------------------------------------------------------

    else {

        extraInformation = `

            <p class="text-muted mb-2">

                <strong>Customer:</strong>

                ${escapeHtml(
                    booking.customer_name ||
                    "N/A"
                )}

            </p>

        `;

    }


    return `

        <div class="col-md-6 col-xl-4">

            <div class="card h-100 shadow-sm">


                <div class="card-body">


                    <!-- TYPE + STATUS -->

                    <div
                        class="d-flex justify-content-between align-items-start mb-3"
                    >

                        <span
                            class="badge ${bookingTypeClass}"
                        >

                            ${bookingTypeLabel}

                        </span>


                        <span
                            class="badge ${statusClass}"
                        >

                            ${escapeHtml(
                                capitalize(status)
                            )}

                        </span>

                    </div>


                    <!-- EVENT -->

                    <h5 class="card-title">

                        ${eventTitle}

                    </h5>


                    <p class="text-muted mb-2">

                        <strong>Event Type:</strong>

                        ${eventType}

                    </p>


                    <p class="text-muted mb-2">

                        <strong>Date:</strong>

                        ${date}

                    </p>


                    <p class="text-muted mb-2">

                        <strong>Location:</strong>

                        ${location}

                    </p>


                    ${extraInformation}


                </div>


                <!-- FOOTER -->

                <div
                    class="card-footer bg-white border-0 pb-3"
                >

                    <button
                        type="button"
                        class="btn btn-primary w-100"
                        onclick="showBookingDetails(${index})"
                    >

                        View Details

                    </button>

                </div>


            </div>

        </div>

    `;

}


// =========================================================
// SHOW BOOKING DETAILS
// =========================================================

function showBookingDetails(index) {

    const booking =
        bookings[index];


    if (!booking) {

        return;

    }


    const bookingType =
        booking.booking_type || "booking";


    modalTitle.textContent =
        capitalize(
            bookingType
        ) +
        " #" +
        booking.booking_id;


    let html = "";


    // =====================================================
    // COMMON INFORMATION
    // =====================================================

    html += `

        <div class="mb-4">

            <span class="text-muted">
                Booking Type
            </span>

            <br>

            <span class="badge ${getBookingTypeClass(bookingType)}">

                ${escapeHtml(
                    getBookingTypeLabel(
                        bookingType
                    )
                )}

            </span>

        </div>


        <div class="mb-4">

            <span class="text-muted">
                Status
            </span>

            <br>

            <span
                class="badge ${getStatusClass(
                    booking.status
                )}"
            >

                ${escapeHtml(
                    capitalize(
                        booking.status ||
                        "pending"
                    )
                )}

            </span>

        </div>


        <h5 class="mb-3">
            Event Information
        </h5>


        <div class="row g-3 mb-4">

            ${detailItem(
                "Event",
                booking.event_title
            )}

            ${detailItem(
                "Event Type",
                booking.event_type
            )}

            ${detailItem(
                "Event Date",
                formatDate(
                    booking.event_date
                )
            )}

            ${detailItem(
                "Location",
                booking.event_location
            )}

        </div>


        <h5 class="mb-3">
            Customer Information
        </h5>


        <div class="row g-3 mb-4">

            ${detailItem(
                "Customer Name",
                booking.customer_name
            )}

            ${detailItem(
                "Phone",
                booking.customer_phone
            )}

            ${detailItem(
                "Email",
                booking.email
            )}

            ${detailItem(
                "CNIC",
                booking.cnic
            )}

        </div>

    `;


    // =====================================================
    // BOOKING1
    // =====================================================

    if (bookingType === "booking1") {

        html += `

            <h5 class="mb-3">
                Transport Information
            </h5>


            <div class="row g-3 mb-4">

                ${detailItem(
                    "Start Time",
                    formatTime(
                        booking.start_time
                    )
                )}

                ${detailItem(
                    "End Time",
                    formatTime(
                        booking.end_time
                    )
                )}

                ${detailItem(
                    "Transport",
                    booking.transport
                )}

                ${detailItem(
                    "Payment Method",
                    booking.payment_method
                )}

            </div>

        `;

    }


    // =====================================================
    // BOOKING2
    // =====================================================

    if (bookingType === "booking2") {

        html += `

            <h5 class="mb-3">
                Service Information
            </h5>


            <div class="row g-3 mb-4">

                ${detailItem(
                    "Service",
                    booking.service_type
                )}

                ${detailItem(
                    "Start Time",
                    formatTime(
                        booking.start_time
                    )
                )}

                ${detailItem(
                    "End Time",
                    formatTime(
                        booking.end_time
                    )
                )}

                ${detailItem(
                    "Guests",
                    booking.guests
                )}

                ${detailItem(
                    "City",
                    booking.city
                )}

                ${detailItem(
                    "Area",
                    booking.area
                )}

                ${detailItem(
                    "Address",
                    booking.address
                )}

            </div>


            <h5 class="mb-3">
                Package & Extras
            </h5>


            <div class="row g-3 mb-4">

                ${detailItem(
                    "Package",
                    booking.package_name
                )}

                ${detailItem(
                    "Package Price",
                    "PKR " +
                    formatCurrency(
                        booking.package_price
                    )
                )}

                ${detailItem(
                    "Extra Price",
                    "PKR " +
                    formatCurrency(
                        booking.extra_price
                    )
                )}

                ${detailItem(
                    "Vehicle",
                    booking.vehicle
                )}

                ${detailItem(
                    "Vehicle Price",
                    "PKR " +
                    formatCurrency(
                        booking.vehicle_price
                    )
                )}

                ${detailItem(
                    "Generator",
                    booking.generator
                )}

                ${detailItem(
                    "Generator Price",
                    "PKR " +
                    formatCurrency(
                        booking.generator_price
                    )
                )}

            </div>


            <h5 class="mb-3">
                Payment
            </h5>


            <div class="row g-3 mb-4">

                ${detailItem(
                    "Grand Total",
                    "PKR " +
                    formatCurrency(
                        booking.grand_total
                    )
                )}

                ${detailItem(
                    "Advance Payment",
                    "PKR " +
                    formatCurrency(
                        booking.advance_payment
                    )
                )}

                ${detailItem(
                    "Remaining",
                    "PKR " +
                    formatCurrency(
                        booking.remaining_amount
                    )
                )}

                ${detailItem(
                    "Payment Method",
                    booking.payment_method
                )}

                ${detailItem(
                    "Confirmation Via",
                    booking.confirm_via
                )}

            </div>


            <h5 class="mb-3">
                Notes
            </h5>


            <div class="border rounded p-3 bg-light">

                ${escapeHtml(
                    booking.notes ||
                    "No additional notes."
                )}

            </div>

        `;

    }


    // =====================================================
    // NORMAL BOOKING
    // =====================================================

    if (bookingType === "booking") {

        html += `

            <h5 class="mb-3">
                Booking Information
            </h5>


            <div class="row g-3 mb-4">

                ${detailItem(
                    "Booking ID",
                    booking.booking_id
                )}

                ${detailItem(
                    "Event ID",
                    booking.event_id
                )}

                ${detailItem(
                    "Vendor ID",
                    booking.vendor_id
                )}

                ${detailItem(
                    "Event Date",
                    formatDate(
                        booking.event_date
                    )
                )}

            </div>

        `;

    }


    bookingDetails.innerHTML =
        html;


    // =====================================================
    // OPEN MODAL
    // =====================================================

    const modalElement =
        document.getElementById(
            "bookingModal"
        );


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


// =========================================================
// DETAIL ITEM
// =========================================================

function detailItem(
    label,
    value
) {

    let displayValue =
        value;


    if (
        displayValue === null ||
        displayValue === undefined ||
        displayValue === ""
    ) {

        displayValue = "N/A";

    }


    return `

        <div class="col-md-6">

            <div class="border rounded p-3 h-100">

                <small class="text-muted">

                    ${escapeHtml(label)}

                </small>


                <div class="fw-semibold mt-1">

                    ${escapeHtml(
                        displayValue
                    )}

                </div>

            </div>

        </div>

    `;

}


// =========================================================
// STATUS CLASS
// =========================================================

function getStatusClass(status) {

    switch (
        String(status || "").toLowerCase()
    ) {

        case "approved":

            return "bg-success";


        case "confirmed":

            return "bg-success";


        case "completed":

            return "bg-primary";


        case "rejected":

            return "bg-danger";


        case "cancelled":

            return "bg-danger";


        case "pending":

        default:

            return "bg-warning text-dark";

    }

}


// =========================================================
// FORMAT DATE
// =========================================================

function formatDate(dateString) {

    if (!dateString) {

        return "N/A";

    }


    const date =
        new Date(
            dateString + "T00:00:00"
        );


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return dateString;

    }


    return date.toLocaleDateString(
        "en-PK",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// =========================================================
// FORMAT TIME
// =========================================================

function formatTime(timeString) {

    if (!timeString) {

        return "N/A";

    }


    const parts =
        timeString.split(":");


    if (parts.length < 2) {

        return timeString;

    }


    let hour =
        parseInt(
            parts[0],
            10
        );


    const minute =
        parts[1];


    const period =
        hour >= 12
            ? "PM"
            : "AM";


    hour =
        hour % 12 || 12;


    return (
        hour +
        ":" +
        minute +
        " " +
        period
    );

}


// =========================================================
// FORMAT CURRENCY
// =========================================================

function formatCurrency(value) {

    const number =
        Number(value) || 0;


    return number.toLocaleString(
        "en-PK",
        {
            maximumFractionDigits: 2
        }
    );

}


// =========================================================
// CAPITALIZE
// =========================================================

function capitalize(value) {

    if (!value) {

        return "";

    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


// =========================================================
// HTML ESCAPE
// =========================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


// =========================================================
// LOAD WHEN PAGE OPENS
// =========================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadBookings();

    }
);
