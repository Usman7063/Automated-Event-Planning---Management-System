"use strict";

// =========================================================
// VENDOR MANAGEMENT
// =========================================================

// ---------------------------------------------------------
// API URLS
// ---------------------------------------------------------

const GET_VENDORS_API =
    "http://localhost/event-system/backend/admin/get_vendors.php";

const ADD_VENDOR_API =
    "http://localhost/event-system/backend/admin/add_vendor.php";

const UPDATE_VENDOR_API =
    "http://localhost/event-system/backend/admin/update_vendor.php";


// =========================================================
// GLOBAL DATA
// =========================================================

let allVendors = [];


// =========================================================
// INITIALIZE
// =========================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        setupVendorManagement();

    }
);


// =========================================================
// SETUP VENDOR MANAGEMENT
// =========================================================

function setupVendorManagement() {

    // -----------------------------------------------------
    // SEARCH
    // -----------------------------------------------------

    const searchInput =
        document.getElementById(
            "vendorSearch"
        );

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterVendors
        );

    }


    // -----------------------------------------------------
    // SERVICE FILTER
    // -----------------------------------------------------

    const serviceFilter =
        document.getElementById(
            "vendorServiceFilter"
        );

    if (serviceFilter) {

        serviceFilter.addEventListener(
            "change",
            filterVendors
        );

    }


    // -----------------------------------------------------
    // STATUS FILTER
    // -----------------------------------------------------

    const statusFilter =
        document.getElementById(
            "vendorStatusFilter"
        );

    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            filterVendors
        );

    }


    // -----------------------------------------------------
    // ADD VENDOR BUTTON
    // -----------------------------------------------------

    const addVendorBtn =
        document.getElementById(
            "addVendorBtn"
        );

    if (addVendorBtn) {

        addVendorBtn.addEventListener(
            "click",
            openAddVendorModal
        );

    }


    // -----------------------------------------------------
    // ADD VENDOR FORM
    // -----------------------------------------------------

    const addVendorForm =
        document.getElementById(
            "addVendorForm"
        );

    if (addVendorForm) {

        addVendorForm.addEventListener(
            "submit",
            submitAddVendor
        );

    }


    // -----------------------------------------------------
    // EDIT VENDOR FORM
    // -----------------------------------------------------

    const editVendorForm =
        document.getElementById(
            "editVendorForm"
        );

    if (editVendorForm) {

        editVendorForm.addEventListener(
            "submit",
            submitEditVendor
        );

    }


    // -----------------------------------------------------
    // LOAD VENDORS
    // -----------------------------------------------------

    loadVendors();

}


// =========================================================
// LOAD VENDORS
// =========================================================

async function loadVendors() {

    const tableBody =
        document.getElementById(
            "vendorsTableBody"
        );


    if (tableBody) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="8"
                    class="text-center py-5"
                >

                    <i
                        class="fa-solid fa-spinner fa-spin me-2"
                    ></i>

                    Loading vendors...

                </td>

            </tr>

        `;

    }


    try {

        const response =
            await fetch(
                GET_VENDORS_API,
                {
                    method: "GET",

                    credentials: "include",

                    headers: {
                        "Accept":
                            "application/json"
                    }

                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "GET VENDORS RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(
                    rawResponse
                );

        } catch (error) {

            throw new Error(
                "Vendors API returned invalid JSON."
            );

        }


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to load vendors."
            );

        }


        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to load vendors."
            );

        }


        // -------------------------------------------------
        // STORE VENDORS
        // -------------------------------------------------

        allVendors =
            Array.isArray(
                data.vendors
            )
                ? data.vendors
                : [];


        // -------------------------------------------------
        // STATISTICS
        // -------------------------------------------------

        updateVendorStatistics(
            data.statistics
        );


        // -------------------------------------------------
        // SERVICE FILTER
        // -------------------------------------------------

        populateServiceFilter(
            allVendors
        );


        // -------------------------------------------------
        // RENDER
        // -------------------------------------------------

        renderVendors(
            allVendors
        );


    } catch (error) {

        console.error(
            "LOAD VENDORS ERROR:",
            error
        );


        if (tableBody) {

            tableBody.innerHTML = `

                <tr>

                    <td
                        colspan="8"
                        class="text-center py-5 text-danger"
                    >

                        <i
                            class="fa-solid fa-circle-exclamation me-2"
                        ></i>

                        ${escapeVendorHtml(
                            error.message ||
                            "Unable to load vendors."
                        )}

                    </td>

                </tr>

            `;

        }


        if (
            typeof showToast ===
            "function"
        ) {

            showToast(
                error.message ||
                "Unable to load vendors.",
                "error"
            );

        }

    }

}


// =========================================================
// UPDATE STATISTICS
// =========================================================

function updateVendorStatistics(
    statistics
) {

    if (!statistics) {
        return;
    }


    setVendorText(
        "totalVendors",
        statistics.total ?? 0
    );


    setVendorText(
        "approvedVendorsCount",
        statistics.approved ?? 0
    );


    setVendorText(
        "pendingVendorsCount",
        statistics.pending ?? 0
    );


    setVendorText(
        "rejectedVendorsCount",
        statistics.rejected ?? 0
    );

}


// =========================================================
// POPULATE SERVICE FILTER
// =========================================================

function populateServiceFilter(
    vendors
) {

    const select =
        document.getElementById(
            "vendorServiceFilter"
        );


    if (!select) {
        return;
    }


    const currentValue =
        select.value;


    const services =
        [
            ...new Set(
                vendors
                    .map(
                        vendor =>
                            String(
                                vendor.service_type ||
                                ""
                            ).trim()
                    )
                    .filter(
                        service =>
                            service !== ""
                    )
            )
        ]
        .sort(
            (a, b) =>
                a.localeCompare(b)
        );


    select.innerHTML = `

        <option value="">
            All Services
        </option>

    `;


    services.forEach(
        service => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                service;


            option.textContent =
                service;


            select.appendChild(
                option
            );

        }
    );


    if (
        services.includes(
            currentValue
        )
    ) {

        select.value =
            currentValue;

    }

}


// =========================================================
// FILTER VENDORS
// =========================================================

function filterVendors() {

    const searchInput =
        document.getElementById(
            "vendorSearch"
        );


    const serviceFilter =
        document.getElementById(
            "vendorServiceFilter"
        );


    const statusFilter =
        document.getElementById(
            "vendorStatusFilter"
        );


    const search =
        (
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    const service =
        serviceFilter?.value ||
        "";


    const status =
        statusFilter?.value ||
        "";


    const filtered =
        allVendors.filter(
            vendor => {

                const name =
                    String(
                        vendor.name ||
                        ""
                    ).toLowerCase();


                const phone =
                    String(
                        vendor.phone ||
                        ""
                    ).toLowerCase();


                const email =
                    String(
                        vendor.email ||
                        ""
                    ).toLowerCase();


                const serviceType =
                    String(
                        vendor.service_type ||
                        ""
                    ).toLowerCase();


                const matchesSearch =
                    !search ||
                    name.includes(search) ||
                    phone.includes(search) ||
                    email.includes(search) ||
                    serviceType.includes(search);


                const matchesService =
                    !service ||
                    serviceType ===
                    service.toLowerCase();


                const matchesStatus =
                    !status ||
                    String(
                        vendor.status ||
                        ""
                    ).toLowerCase() ===
                    status.toLowerCase();


                return (
                    matchesSearch &&
                    matchesService &&
                    matchesStatus
                );

            }
        );


    renderVendors(
        filtered
    );

}


// =========================================================
// RENDER VENDORS
// =========================================================

function renderVendors(
    vendors
) {

    const tableBody =
        document.getElementById(
            "vendorsTableBody"
        );


    const emptyState =
        document.getElementById(
            "vendorsEmptyState"
        );


    if (!tableBody) {
        return;
    }


    // -----------------------------------------------------
    // EMPTY
    // -----------------------------------------------------

    if (
        !Array.isArray(vendors) ||
        vendors.length === 0
    ) {

        tableBody.innerHTML = "";


        if (emptyState) {

            emptyState.classList.remove(
                "d-none"
            );

        }


        return;

    }


    // -----------------------------------------------------
    // HIDE EMPTY STATE
    // -----------------------------------------------------

    if (emptyState) {

        emptyState.classList.add(
            "d-none"
        );

    }


    // -----------------------------------------------------
    // RENDER TABLE
    // -----------------------------------------------------

    tableBody.innerHTML =
        vendors
            .map(
                (
                    vendor,
                    index
                ) => {

                    return `

                        <tr>

                            <td>
                                ${index + 1}
                            </td>


                            <td>

                                <div class="fw-semibold">

                                    ${escapeVendorHtml(
                                        vendor.name ||
                                        "—"
                                    )}

                                </div>

                            </td>


                            <td>

                                ${escapeVendorHtml(
                                    vendor.service_type ||
                                    "—"
                                )}

                            </td>


                            <td>

                                ${escapeVendorHtml(
                                    vendor.phone ||
                                    "—"
                                )}

                            </td>


                            <td>

                                ${escapeVendorHtml(
                                    vendor.email ||
                                    "—"
                                )}

                            </td>


                            <td>

                                <span class="fw-semibold">

                                    ${formatVendorMoney(
                                        vendor.price
                                    )}

                                </span>

                            </td>


                            <td>

                                ${getVendorStatusBadge(
                                    vendor.status
                                )}

                            </td>


                            <td>

                                <div
                                    class="d-flex gap-1"
                                >

                                    <!-- VIEW -->
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-primary"
                                        onclick="viewVendor(${Number(vendor.id)})"
                                        title="View Vendor"
                                    >

                                        <i
                                            class="fa-solid fa-eye"
                                        ></i>

                                    </button>


                                    <!-- EDIT -->
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-warning"
                                        onclick="openEditVendorModal(${Number(vendor.id)})"
                                        title="Edit Vendor"
                                    >

                                        <i
                                            class="fa-solid fa-pen"
                                        ></i>

                                    </button>

                                </div>

                            </td>

                        </tr>

                    `;

                }
            )
            .join("");

}


// =========================================================
// STATUS BADGE
// =========================================================

function getVendorStatusBadge(
    status
) {

    const value =
        String(
            status ||
            "unknown"
        )
        .toLowerCase();


    let badgeClass =
        "bg-secondary";


    if (
        value === "approved"
    ) {

        badgeClass =
            "bg-success";

    } else if (
        value === "pending"
    ) {

        badgeClass =
            "bg-warning text-dark";

    } else if (
        value === "rejected"
    ) {

        badgeClass =
            "bg-danger";

    } else if (
        value === "inactive"
    ) {

        badgeClass =
            "bg-secondary";

    }


    return `

        <span class="badge ${badgeClass}">

            ${escapeVendorHtml(
                status ||
                "Unknown"
            )}

        </span>

    `;

}


// =========================================================
// FORMAT MONEY
// =========================================================

function formatVendorMoney(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "—";

    }


    const number =
        Number(value);


    if (
        Number.isNaN(number)
    ) {

        return "PKR " +
            escapeVendorHtml(
                value
            );

    }


    return (
        "PKR " +
        number.toLocaleString(
            "en-PK",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }
        )
    );

}


// =========================================================
// VIEW VENDOR
// =========================================================

function viewVendor(
    vendorId
) {

    console.log(
        "VIEW VENDOR CLICKED:",
        vendorId
    );


    const vendor =
        allVendors.find(
            item =>
                Number(item.id) ===
                Number(vendorId)
        );


    console.log(
        "VENDOR FOUND:",
        vendor
    );


    if (!vendor) {

        showVendorMessage(
            "Vendor could not be found.",
            "error"
        );

        return;

    }


    // -----------------------------------------------------
    // FILL VIEW MODAL
    // -----------------------------------------------------

    setVendorViewValue(
        "viewVendorName",
        vendor.name
    );


    setVendorViewValue(
        "viewVendorService",
        vendor.service_type
    );


    setVendorViewValue(
        "viewVendorDescription",
        vendor.description
    );


    setVendorViewValue(
        "viewVendorPhone",
        vendor.phone
    );


    setVendorViewValue(
        "viewVendorEmail",
        vendor.email
    );


    setVendorViewValue(
        "viewVendorPrice",
        formatVendorMoney(
            vendor.price
        )
    );


    setVendorViewValue(
        "viewVendorStatus",
        vendor.status
    );


    setVendorViewValue(
        "viewVendorId",
        vendor.id
    );


    setVendorViewValue(
        "viewVendorCreatedAt",
        vendor.created_at
    );


    // -----------------------------------------------------
    // MODAL
    // -----------------------------------------------------

    const modalElement =
        document.getElementById(
            "viewVendorModal"
        );


    if (!modalElement) {

        console.error(
            "viewVendorModal was not found."
        );

        return;

    }


    if (
        typeof bootstrap ===
        "undefined"
    ) {

        console.error(
            "Bootstrap JavaScript is not loaded."
        );

        return;

    }


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


// =========================================================
// SET VIEW VALUE
// =========================================================

function setVendorViewValue(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        console.warn(
            "View vendor element not found:",
            id
        );

        return;

    }


    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        element.textContent =
            "—";

        return;

    }


    element.textContent =
        value;

}


// =========================================================
// ADD VENDOR MODAL
// =========================================================

function openAddVendorModal() {

    console.log(
        "OPEN ADD VENDOR MODAL"
    );


    const modalElement =
        document.getElementById(
            "addVendorModal"
        );


    if (!modalElement) {

        console.error(
            "addVendorModal was not found."
        );

        return;

    }


    if (
        typeof bootstrap ===
        "undefined"
    ) {

        console.error(
            "Bootstrap JavaScript is not loaded."
        );

        return;

    }


    const form =
        document.getElementById(
            "addVendorForm"
        );


    if (form) {

        form.reset();

    }


    const status =
        document.getElementById(
            "vendorStatus"
        );


    if (status) {

        status.value =
            "pending";

    }


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


// =========================================================
// SUBMIT ADD VENDOR
// =========================================================

async function submitAddVendor(
    event
) {

    event.preventDefault();


    const form =
        event.currentTarget;


    if (!form) {
        return;
    }


    const saveButton =
        document.getElementById(
            "saveVendorBtn"
        );


    if (saveButton) {

        saveButton.disabled =
            true;


        saveButton.innerHTML = `

            <i
                class="fa-solid fa-spinner fa-spin me-1"
            ></i>

            Adding...

        `;

    }


    try {

        const formData =
            new FormData(
                form
            );


        const response =
            await fetch(
                ADD_VENDOR_API,
                {
                    method: "POST",

                    credentials: "include",

                    body: formData
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "ADD VENDOR RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(
                    rawResponse
                );

        } catch (error) {

            throw new Error(
                "Add Vendor API returned invalid JSON."
            );

        }


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to add vendor."
            );

        }


        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to add vendor."
            );

        }


        showVendorMessage(
            "Vendor added successfully.",
            "success"
        );


        // -------------------------------------------------
        // CLOSE MODAL
        // -------------------------------------------------

        const modalElement =
            document.getElementById(
                "addVendorModal"
            );


        if (
            modalElement &&
            typeof bootstrap !==
            "undefined"
        ) {

            const modal =
                bootstrap.Modal.getInstance(
                    modalElement
                );


            if (modal) {

                modal.hide();

            }

        }


        // -------------------------------------------------
        // RESET FORM
        // -------------------------------------------------

        form.reset();


        const status =
            document.getElementById(
                "vendorStatus"
            );


        if (status) {

            status.value =
                "pending";

        }


        // -------------------------------------------------
        // RELOAD
        // -------------------------------------------------

        await loadVendors();


    } catch (error) {

        console.error(
            "ADD VENDOR ERROR:",
            error
        );


        showVendorMessage(
            error.message ||
            "Unable to add vendor.",
            "error"
        );


    } finally {

        if (saveButton) {

            saveButton.disabled =
                false;


            saveButton.innerHTML = `

                <i
                    class="fa-solid fa-plus me-1"
                ></i>

                Add Vendor

            `;

        }

    }

}


// =========================================================
// OPEN EDIT VENDOR MODAL
// =========================================================

function openEditVendorModal(
    vendorId
) {

    console.log(
        "EDIT VENDOR CLICKED:",
        vendorId
    );


    const vendor =
        allVendors.find(
            item =>
                Number(item.id) ===
                Number(vendorId)
        );


    console.log(
        "EDIT VENDOR FOUND:",
        vendor
    );


    if (!vendor) {

        showVendorMessage(
            "Vendor could not be found.",
            "error"
        );

        return;

    }


    const modalElement =
        document.getElementById(
            "editVendorModal"
        );


    if (!modalElement) {

        console.error(
            "editVendorModal was not found."
        );

        return;

    }


    // -----------------------------------------------------
    // FILL FORM
    // -----------------------------------------------------

    const idInput =
        document.getElementById(
            "editVendorId"
        );


    const nameInput =
        document.getElementById(
            "editVendorName"
        );


    const serviceInput =
        document.getElementById(
            "editVendorServiceType"
        );


    const descriptionInput =
        document.getElementById(
            "editVendorDescription"
        );


    const phoneInput =
        document.getElementById(
            "editVendorPhone"
        );


    const emailInput =
        document.getElementById(
            "editVendorEmail"
        );


    const priceInput =
        document.getElementById(
            "editVendorPrice"
        );


    const statusInput =
        document.getElementById(
            "editVendorStatus"
        );


    if (idInput) {

        idInput.value =
            vendor.id ?? "";

    }


    if (nameInput) {

        nameInput.value =
            vendor.name ?? "";

    }


    if (serviceInput) {

        serviceInput.value =
            vendor.service_type ?? "";

    }


    if (descriptionInput) {

        descriptionInput.value =
            vendor.description ?? "";

    }


    if (phoneInput) {

        phoneInput.value =
            vendor.phone ?? "";

    }


    if (emailInput) {

        emailInput.value =
            vendor.email ?? "";

    }


    if (priceInput) {

        priceInput.value =
            vendor.price ?? "";

    }


    if (statusInput) {

        statusInput.value =
            String(
                vendor.status ||
                "pending"
            ).toLowerCase();

    }


    // -----------------------------------------------------
    // BOOTSTRAP
    // -----------------------------------------------------

    if (
        typeof bootstrap ===
        "undefined"
    ) {

        console.error(
            "Bootstrap JavaScript is not loaded."
        );

        return;

    }


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


// =========================================================
// SUBMIT EDIT VENDOR
// =========================================================

async function submitEditVendor(
    event
) {

    event.preventDefault();


    const form =
        event.currentTarget;


    if (!form) {
        return;
    }


    const updateButton =
        document.getElementById(
            "updateVendorBtn"
        );


    if (updateButton) {

        updateButton.disabled =
            true;


        updateButton.innerHTML = `

            <i
                class="fa-solid fa-spinner fa-spin me-1"
            ></i>

            Saving...

        `;

    }


    try {

        const vendorId =
            document.getElementById(
                "editVendorId"
            )?.value;


        if (!vendorId) {

            throw new Error(
                "Vendor ID is missing."
            );

        }


        const formData =
            new FormData(
                form
            );


        // -------------------------------------------------
        // REQUIRED API VALUES
        // -------------------------------------------------

        formData.set(
            "action",
            "edit"
        );


        formData.set(
            "vendor_id",
            vendorId
        );


        console.log(
            "EDIT VENDOR DATA:",
            Object.fromEntries(
                formData.entries()
            )
        );


        // -------------------------------------------------
        // REQUEST
        // -------------------------------------------------

        const response =
            await fetch(
                UPDATE_VENDOR_API,
                {
                    method: "POST",

                    credentials: "include",

                    body: formData
                }
            );


        const rawResponse =
            await response.text();


        console.log(
            "UPDATE VENDOR RESPONSE:",
            rawResponse
        );


        let data;


        try {

            data =
                JSON.parse(
                    rawResponse
                );

        } catch (error) {

            throw new Error(
                "Update Vendor API returned invalid JSON."
            );

        }


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to update vendor."
            );

        }


        if (!data.success) {

            throw new Error(
                data.error ||
                "Unable to update vendor."
            );

        }


        // -------------------------------------------------
        // SUCCESS
        // -------------------------------------------------

        showVendorMessage(
            "Vendor updated successfully.",
            "success"
        );


        // -------------------------------------------------
        // CLOSE MODAL
        // -------------------------------------------------

        const modalElement =
            document.getElementById(
                "editVendorModal"
            );


        if (
            modalElement &&
            typeof bootstrap !==
            "undefined"
        ) {

            const modal =
                bootstrap.Modal.getInstance(
                    modalElement
                );


            if (modal) {

                modal.hide();

            }

        }


        // -------------------------------------------------
        // RELOAD
        // -------------------------------------------------

        await loadVendors();


    } catch (error) {

        console.error(
            "UPDATE VENDOR ERROR:",
            error
        );


        showVendorMessage(
            error.message ||
            "Unable to update vendor.",
            "error"
        );


    } finally {

        if (updateButton) {

            updateButton.disabled =
                false;


            updateButton.innerHTML = `

                <i
                    class="fa-solid fa-save me-1"
                ></i>

                Save Changes

            `;

        }

    }

}


// =========================================================
// SET TEXT
// =========================================================

function setVendorText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {
        return;
    }


    element.textContent =
        value;

}


// =========================================================
// ESCAPE HTML
// =========================================================

function escapeVendorHtml(
    value
) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =========================================================
// SHOW MESSAGE / TOAST
// =========================================================

function showVendorMessage(
    message,
    type
) {

    if (
        typeof showToast ===
        "function"
    ) {

        showToast(
            message,
            type
        );

    } else {

        if (type === "error") {

            console.error(
                message
            );

        } else {

            console.log(
                message
            );

        }

    }

}


// =========================================================
// MAKE INLINE HTML FUNCTIONS AVAILABLE
// =========================================================
// Your table buttons use onclick="viewVendor(...)"
// and onclick="openEditVendorModal(...)".
// These assignments guarantee that the functions
// are available to inline HTML event handlers.
// =========================================================

window.viewVendor =
    viewVendor;


window.openEditVendorModal =
    openEditVendorModal;


window.openAddVendorModal =
    openAddVendorModal;


window.loadVendors =
    loadVendors;


window.filterVendors =
    filterVendors;