const galleryData = {

    tent: {

        title: {
            en: "🏕️ Tent & Seating Gallery",
            ur: "🏕️ ٹینٹ اور نشست کی گیلری"
        },

        images: [

            "image/gallery1.jpg",
            "image/gallery2.jpg",
            "image/gallery3.jpg",
            "image/gallery4.jpg",
            "image/gallery5.jpg",
            "image/gallery6.jpg"

        ]

    },


    decoration: {

        title: {
            en: "🎈 Decoration Gallery",
            ur: "🎈 ڈیکوریشن گیلری"
        },

        images: [

            "image/decoration-gallery1.jpg",
            "image/decoration-gallery2.jpg",
            "image/decoration-gallery3.jpg",
            "image/decoration-gallery4.jpg",
            "image/decoration-gallery5.jpg",
            "image/decoration-gallery6.jpg"

        ]

    },


    sound: {

        title: {
            en: "🔊 Sound & Lighting Gallery",
            ur: "🔊 ساؤنڈ اور لائٹنگ گیلری"
        },

        images: [

            "image/sound-gallery1.jpg",
            "image/sound-gallery2.jpg",
            "image/sound-gallery3.jpg",
            "image/3.jpg",
            "image/4.jpg",
            "image/5.jpg"

        ]

    }

    // NOTE: "catering" category yahan se poori tarah hata di gayi hai
    // (jaisa aapne request kiya). Agar zindagi mein kabhi wapas
    // chahiye ho to bas ek naya key "catering: { title, images }"
    // yahan add kar dein (title ab { en, ur } object hai).

};


// "View Complete Gallery" ke liye sab categories ki images ek sath jama karo
galleryData.all = {

    title: {
        en: "🖼️ Complete Gallery",
        ur: "🖼️ مکمل گیلری"
    },

    images: [].concat(
        galleryData.tent.images,
        galleryData.decoration.images,
        galleryData.sound.images
        // catering yahan se bhi hata diya gaya hai
    )

};


// Hash se category lena (agar hash na ho to "all" gallery dikhao)
const category = window.location.hash.substring(1) || "all";

// HTML Elements
const title = document.getElementById("galleryTitle");
const container = document.getElementById("galleryContainer");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const lightboxCounter = document.getElementById("lightboxCounter");

let currentImages = [];
let currentIndex = 0;

// Current language: language.js exposes window.getCurrentLang(); fall
// back to "en" if language.js hasn't loaded yet for any reason.
function currentLang() {
    return (window.getCurrentLang && window.getCurrentLang()) || "en";
}

// FIX: "No images found." bhi ab EN/Urdu dono mein hai, aur translation.js
// mein "gallery_3" key ke through bhi maujood hai taake dono jagah se
// consistent rahe.
const NO_IMAGES_TEXT = { en: "No images found.", ur: "کوئی تصویر نہیں ملی۔" };
const FALLBACK_TITLE = { en: "Gallery", ur: "گیلری" };

// Sirf title (aur "no images" message) ko current language mein render
// karta hai -- images khud kabhi translate nahi hoti, is liye unhe
// dobara load karne ki zaroorat nahi.
function renderGalleryTitle() {

    const lang = currentLang();

    if (galleryData[category]) {
        title.innerHTML = galleryData[category].title[lang] || galleryData[category].title.en;
    } else {
        title.innerHTML = FALLBACK_TITLE[lang] || FALLBACK_TITLE.en;
        const noImagesEl = container.querySelector("[data-no-images]");
        if (noImagesEl) {
            noImagesEl.textContent = NO_IMAGES_TEXT[lang] || NO_IMAGES_TEXT.en;
        }
    }

}

// Agar category mil gayi
if (galleryData[category]) {

    currentImages = galleryData[category].images;

    currentImages.forEach((img, index) => {

        container.innerHTML += `

            <div class="col-lg-4 col-md-6">

                <div class="gallery-image-card" data-index="${index}">

                    <img src="${img}" class="gallery-image" alt="Gallery Image" data-index="${index}"
                         onerror="this.closest('.col-lg-4').style.display='none'">

                    <div class="gallery-image-overlay">

                        <i class="fas fa-expand"></i>

                    </div>

                </div>

            </div>

        `;

    });

    // FIX: Pehle click listener sirf <img> par tha, lekin overlay div
    // image ke UPAR (z-order me) baithta hai isliye click overlay
    // "khaa" jata tha aur listener kabhi fire nahi hota tha.
    //
    // Ab hum "event delegation" use kar rahe hain: sirf ek listener
    // pure container (galleryContainer) par lagate hain, aur jahan
    // bhi click ho, uske sabse qareeb wala ".gallery-image-card"
    // dhoondh lete hain (chahe click image par lage, overlay par lage,
    // ya card ke kisi bhi hisse par). Ye zyada reliable hai aur
    // overlay/CSS badalne se bhi kabhi break nahi hoga.
    container.addEventListener("click", (e) => {

        const card = e.target.closest(".gallery-image-card");

        if (!card) return; // click gallery card se bahar hua, ignore karo

        openLightbox(parseInt(card.dataset.index, 10));

    });

} else {

    container.innerHTML = `
        <div class="col-12 text-center">
            <h4 data-no-images>No images found.</h4>
        </div>
    `;

}

// Title (aur "no images" message, agar applicable ho) ko sahi zaban mein render karo
renderGalleryTitle();

// FIX: jab bhi language switcher (EN/اردو) click hota hai, language.js
// ye event fire karta hai -- yahan sun kar title/"no images" message
// dobara sahi zaban mein render kar dete hain.
document.addEventListener("languagechange", renderGalleryTitle);


// Lightbox open karna
function openLightbox(index) {

    currentIndex = index;
    lightboxImg.src = currentImages[currentIndex];
    updateCounter();
    lightbox.classList.add("active");
    document.body.style.overflow = "hidden";

}

// Lightbox band karna
function closeLightbox() {

    lightbox.classList.remove("active");
    document.body.style.overflow = "";

}

// Agli image
function showNext() {

    currentIndex = (currentIndex + 1) % currentImages.length;
    lightboxImg.src = currentImages[currentIndex];
    updateCounter();

}

// Pichli image
function showPrev() {

    currentIndex = (currentIndex - 1 + currentImages.length) % currentImages.length;
    lightboxImg.src = currentImages[currentIndex];
    updateCounter();

}

// Counter update karna (e.g. 2 / 6)
function updateCounter() {

    if (lightboxCounter) {

        lightboxCounter.innerHTML = `${currentIndex + 1} / ${currentImages.length}`;

    }

}


// Lightbox ke buttons se events juraana
document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
document.getElementById("lightboxNext").addEventListener("click", showNext);
document.getElementById("lightboxPrev").addEventListener("click", showPrev);

// Bahar click karne se bhi band ho jaye
lightbox.addEventListener("click", (e) => {

    if (e.target === lightbox) {

        closeLightbox();

    }

});

// Keyboard se control (Escape, arrows)
document.addEventListener("keydown", (e) => {

    if (!lightbox.classList.contains("active")) return;

    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowRight") showNext();
    if (e.key === "ArrowLeft") showPrev();

});


// Back Button (agar history na ho to home page par bhej do)
function goBack() {

    if (document.referrer && document.referrer.indexOf(window.location.host) !== -1) {

        window.history.back();

    } else {

        window.location.href = "index.html";

    }

}