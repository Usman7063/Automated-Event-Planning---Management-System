// ==========================================
// Service Comparison Data
// ==========================================
// FIX: har text field ab { en: "...", ur: "..." } ke roop mein hai,
// is liye jab language.js "languagechange" event fire karta hai
// (EN/Urdu switch button se), ye poori table + title + description +
// "Why Choose Us" list bhi turant sahi zaban mein dobara render ho
// jati hai -- pehle ye sab hamesha hardcoded English rehta tha chahe
// switcher kuch bhi kaha jaye.

const comparisonData = {

    tent: {

        title: {
            en: "🏕️ Tent & Seating Comparison",
            ur: "🏕️ ٹینٹ اور نشست کا موازنہ"
        },

        description: {
            en: "Compare our tent packages with other local tent service providers.",
            ur: "ہمارے ٹینٹ پیکجز کا مقامی ٹینٹ سروس فراہم کنندگان سے موازنہ کریں۔"
        },

        bookingPage: "booking.html",

        ourPrice: "Rs.15,000",

        marketPrice: "Rs.17,000",

        savePrice: "Rs.2,000",

        table: [

            { en: ["Basic Package","Rs.15,000","Rs.17,000","Rs.18,500"], ur: ["بیسک پیکج","Rs.15,000","Rs.17,000","Rs.18,500"] },
            { en: ["Premium Package","Rs.35,000","Rs.39,000","Rs.42,000"], ur: ["پریمیم پیکج","Rs.35,000","Rs.39,000","Rs.42,000"] },
            { en: ["Chair Covers","✔ Included","Extra Charges","Extra Charges"], ur: ["کرسی کورز","✔ شامل","اضافی چارجز","اضافی چارجز"] },
            { en: ["Stage Setup","✔ Included","Limited","Limited"], ur: ["اسٹیج سیٹ اپ","✔ شامل","محدود","محدود"] },
            { en: ["Transport","✔ Free","Paid","Paid"], ur: ["ٹرانسپورٹ","✔ مفت","ادائیگی درکار","ادائیگی درکار"] },
            { en: ["Setup Time","3 Hours","4 Hours","5 Hours"], ur: ["سیٹ اپ کا وقت","3 گھنٹے","4 گھنٹے","5 گھنٹے"] },
            { en: ["Professional Staff","✔ Included","Limited","Limited"], ur: ["پروفیشنل عملہ","✔ شامل","محدود","محدود"] },
            { en: ["Generator Backup","✔ Included","Optional","Paid"], ur: ["جنریٹر بیک اپ","✔ شامل","اختیاری","ادائیگی درکار"] },
            { en: ["Emergency Support","24/7","Office Hours","Limited"], ur: ["ہنگامی مدد","24/7","دفتری اوقات","محدود"] },
            { en: ["Transparent Pricing","✔ Yes","Partial","No"], ur: ["شفاف قیمت","✔ جی ہاں","جزوی","نہیں"] }

        ],

        why: [

            { en: "Affordable pricing", ur: "مناسب قیمت" },
            { en: "Premium quality tents", ur: "اعلیٰ معیار کے ٹینٹ" },
            { en: "Professional staff", ur: "پروفیشنل عملہ" },
            { en: "Free transportation", ur: "مفت ٹرانسپورٹ" },
            { en: "Transparent pricing", ur: "شفاف قیمت" }

        ]

    },



    decoration: {

        title: {
            en: "🎈 Decoration Comparison",
            ur: "🎈 ڈیکوریشن کا موازنہ"
        },

        description: {
            en: "Compare decoration packages with local decorators.",
            ur: "ڈیکوریشن پیکجز کا مقامی ڈیکوریٹرز سے موازنہ کریں۔"
        },

        bookingPage: "booking1.html",

        ourPrice: "Rs.8,000",

        marketPrice: "Rs.10,000",

        savePrice: "Rs.2,000",

        table: [

            { en: ["Basic Decoration","Rs.8,000","Rs.10,000","Rs.11,500"], ur: ["بیسک ڈیکوریشن","Rs.8,000","Rs.10,000","Rs.11,500"] },
            { en: ["Premium Decoration","Rs.25,000","Rs.29,000","Rs.31,000"], ur: ["پریمیم ڈیکوریشن","Rs.25,000","Rs.29,000","Rs.31,000"] },
            { en: ["Fresh Flowers","✔ Included","Limited","Extra Charges"], ur: ["تازہ پھول","✔ شامل","محدود","اضافی چارجز"] },
            { en: ["Stage Decoration","✔ Included","Limited","Limited"], ur: ["اسٹیج ڈیکوریشن","✔ شامل","محدود","محدود"] },
            { en: ["Entrance Gate","✔ Included","Optional","Optional"], ur: ["انٹرینس گیٹ","✔ شامل","اختیاری","اختیاری"] },
            { en: ["LED Lighting","✔ Included","Limited","Limited"], ur: ["ایل ای ڈی لائٹنگ","✔ شامل","محدود","محدود"] },
            { en: ["Customization","Full","Partial","Partial"], ur: ["حسبِ منشا تبدیلی","مکمل","جزوی","جزوی"] },
            { en: ["Professional Team","✔ Included","Limited","Limited"], ur: ["پروفیشنل ٹیم","✔ شامل","محدود","محدود"] },
            { en: ["Setup Time","2 Hours","3 Hours","4 Hours"], ur: ["سیٹ اپ کا وقت","2 گھنٹے","3 گھنٹے","4 گھنٹے"] },
            { en: ["Transparent Pricing","✔ Yes","Partial","No"], ur: ["شفاف قیمت","✔ جی ہاں","جزوی","نہیں"] }

        ],

        why: [

            { en: "Premium decoration", ur: "پریمیم ڈیکوریشن" },
            { en: "Latest themes", ur: "جدید تھیمز" },
            { en: "Experienced decorators", ur: "تجربہ کار ڈیکوریٹرز" },
            { en: "Affordable packages", ur: "مناسب قیمت کے پیکجز" },
            { en: "Custom designs", ur: "اپنی مرضی کے ڈیزائن" }

        ]

    },



    sound: {

        title: {
            en: "🔊 Sound & Lighting Comparison",
            ur: "🔊 ساؤنڈ اور لائٹنگ کا موازنہ"
        },

        description: {
            en: "Compare sound & lighting services with local providers.",
            ur: "ساؤنڈ اور لائٹنگ سروسز کا مقامی فراہم کنندگان سے موازنہ کریں۔"
        },

        bookingPage: "booking2.html",

        ourPrice: "Rs.10,000",

        marketPrice: "Rs.12,000",

        savePrice: "Rs.2,000",

        table: [

            { en: ["Basic Package","Rs.10,000","Rs.12,000","Rs.13,500"], ur: ["بیسک پیکج","Rs.10,000","Rs.12,000","Rs.13,500"] },
            { en: ["Premium Package","Rs.28,000","Rs.32,000","Rs.35,000"], ur: ["پریمیم پیکج","Rs.28,000","Rs.32,000","Rs.35,000"] },
            { en: ["Wireless Mic","✔ Included","Extra Charges","Extra Charges"], ur: ["وائرلیس مائیک","✔ شامل","اضافی چارجز","اضافی چارجز"] },
            { en: ["DJ Console","✔ Included","Optional","Optional"], ur: ["ڈی جے کنسول","✔ شامل","اختیاری","اختیاری"] },
            { en: ["LED Lighting","✔ Included","Limited","Limited"], ur: ["ایل ای ڈی لائٹنگ","✔ شامل","محدود","محدود"] },
            { en: ["Generator Backup","✔ Included","Paid","Paid"], ur: ["جنریٹر بیک اپ","✔ شامل","ادائیگی درکار","ادائیگی درکار"] },
            { en: ["Sound Engineer","✔ Included","Limited","Limited"], ur: ["ساؤنڈ انجینئر","✔ شامل","محدود","محدود"] },
            { en: ["Setup Time","2 Hours","3 Hours","4 Hours"], ur: ["سیٹ اپ کا وقت","2 گھنٹے","3 گھنٹے","4 گھنٹے"] },
            { en: ["Technical Support","24/7","Office Hours","Limited"], ur: ["تکنیکی مدد","24/7","دفتری اوقات","محدود"] },
            { en: ["Transparent Pricing","✔ Yes","Partial","No"], ur: ["شفاف قیمت","✔ جی ہاں","جزوی","نہیں"] }

        ],

        why: [

            { en: "Latest sound equipment", ur: "جدید ساؤنڈ آلات" },
            { en: "Crystal clear audio", ur: "صاف و شفاف آواز" },
            { en: "Professional technicians", ur: "پروفیشنل تکنیکی ماہرین" },
            { en: "Generator backup", ur: "جنریٹر بیک اپ" },
            { en: "Affordable pricing", ur: "مناسب قیمت" }

        ]

    }

};


// ==========================================
// Detect Selected Service
// ==========================================

const service = window.location.hash.substring(1);

const data = comparisonData[service];


// Current language: language.js exposes window.getCurrentLang(); fall
// back to "en" if language.js hasn't loaded yet for any reason.
function currentLang() {
    return (window.getCurrentLang && window.getCurrentLang()) || "en";
}


function renderComparison() {

    if (!data) return;

    const lang = currentLang();

    document.getElementById("comparisonTitle").innerHTML = data.title[lang] || data.title.en;
    document.getElementById("comparisonDescription").innerHTML = data.description[lang] || data.description.en;
    document.getElementById("ourPrice").innerHTML = data.ourPrice;
    document.getElementById("marketPrice").innerHTML = data.marketPrice;
    document.getElementById("savePrice").innerHTML = data.savePrice;

    
// =====================================================================
// BOOK NOW BUTTON
// =====================================================================

const bookNowButton =
    getElement("bookNowBtn");


if (bookNowButton) {

    console.log(
        "Book Now button found:",
        bookNowButton
    );

    console.log(
        "Booking page:",
        data.bookingPage
    );


    // -------------------------------------------------------------
    // If the element is an <a>
    // -------------------------------------------------------------

    if (
        bookNowButton.tagName.toLowerCase() === "a"
    ) {

        bookNowButton.href =
            data.bookingPage;

    }


    // -------------------------------------------------------------
    // Handle click for BOTH <a> and <button>
    // -------------------------------------------------------------

    bookNowButton.onclick =
        function (event) {

            event.preventDefault();

            console.log(
                "Book Now clicked."
            );

            console.log(
                "Opening:",
                data.bookingPage
            );

            window.location.href =
                data.bookingPage;

        };

} else {

    console.error(
        "❌ Book Now button with ID 'bookNowBtn' was not found."
    );

}



    // Comparison Table
    const table = document.getElementById("comparisonTable");

    table.innerHTML = "";

    data.table.forEach(row => {

        const cells = row[lang] || row.en;

        table.innerHTML += `

        <tr>

            <td>${cells[0]}</td>

            <td>${cells[1]}</td>

            <td>${cells[2]}</td>

            <td>${cells[3]}</td>

        </tr>

        `;

    });

    // Why Choose Us
    const why = document.getElementById("whyChoose");

    why.innerHTML = "";

    data.why.forEach(item => {

        why.innerHTML += `<li>${item[lang] || item.en}</li>`;

    });

}


if (data) {

    renderComparison();

    // FIX: jab bhi language switcher (EN/اردو) click hota hai, language.js
    // ye event fire karta hai -- yahan sun kar poori table/title/description/
    // why-list dobara render kar dete hain nayi zaban mein.
    document.addEventListener("languagechange", renderComparison);

}